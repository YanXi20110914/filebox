# FileBox R8 裁剪规则：应用无反射，只需保留清单引用的组件入口
# （Activity / ContentProvider 由系统按清单实例化，其余代码静态可达自动保留）

-keep class com.filebox.collect.MainActivity { *; }
-keep class com.filebox.collect.SettingsActivity { *; }
-keep class com.filebox.collect.HistoryActivity { *; }
-keep class com.filebox.collect.FilesActivity { *; }
-keep class com.filebox.collect.BoxProvider { *; }

-dontwarn kotlin.**
-dontwarn java.lang.invoke.**
-dontwarn javax.annotation.**
-dontwarn org.jetbrains.annotations.**
-dontwarn org.jacoco.**
