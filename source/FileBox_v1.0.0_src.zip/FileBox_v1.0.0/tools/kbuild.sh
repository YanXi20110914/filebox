#!/usr/bin/env bash
# =====================================================================
# 文件收纳盒 - 一键构建脚本（不依赖 Gradle：aapt2 + kotlinc + R8 + apksigner）
# 用法：bash tools/build_apk.sh [版本名] [版本号]
#       例：bash tools/build_apk.sh 1.8.1 11   （在 FileBox/ 目录下执行）
# 产物：dist/FileBox-v{版本名}.apk（已签名，可直接安装）
# 说明：R8 裁剪 dex（keep 清单组件），APK ~127KB；坑清单见
#       /home/z/my-project/skills/SKILL-android-lean-apk-build/SKILL.md
# =====================================================================
set -euo pipefail

PROJ="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PROJ"

VER_NAME="${1:-1.8.1}"
VER_CODE="${2:-11}"
OUT="dist/FileBox-v${VER_NAME}.apk"

# ---------- 工具链路径 ----------
TOOLS=/home/z/my-project/tools
BT=$TOOLS/android-sdk/build-tools/34.0.0
AJ=$TOOLS/android-sdk/platforms/android-34/android.jar
KM=$TOOLS/kotlin-maven
# Kotlin 编译器（Maven 版 embeddable + 其依赖）
KCP="$KM/kotlin-compiler-embeddable.jar:$KM/kotlin-stdlib.jar:$KM/kotlin-script-runtime-2.0.21.jar:$KM/kotlin-reflect-1.6.10.jar:$KM/kotlin-daemon-embeddable-2.0.21.jar:$KM/trove4j-1.0.20200330.jar:$KM/kotlinx-coroutines-core-jvm-1.6.4.jar:$KM/annotations-13.0.jar"

echo "==> [1/8] 生成旧版密度图标"
python3 tools/gen_icons.py

echo "==> [2/8] aapt2 编译资源"
rm -rf build/gen build/gen_r build/classes build/dexout build/dexout_r8
mkdir -p build/gen build/gen_r build/classes build/dexout build/dexout_r8 dist
$BT/aapt2 compile --dir app/src/main/res -o build/res.zip

echo "==> [3/8] aapt2 链接（产出 fresh base.apk 骨架 + R.java）"
# 注意：base.apk 必须是本轮 fresh link 的产物，注入过 dex 的不能复用（会 Duplicate classes.dex）
$BT/aapt2 link -o build/base.apk -I "$AJ" \
    --manifest app/src/main/AndroidManifest.xml \
    --min-sdk-version 24 --target-sdk-version 34 \
    --version-code "$VER_CODE" --version-name "$VER_NAME" \
    --java build/gen \
    build/res.zip

echo "==> [4/8] R.java -> R.kt（保持资源 ID 一致）"
python3 tools/gen_r_kt.py build/gen/com/filebox/collect/R.java build/gen_r/R.kt

echo "==> [5/8] Kotlin 编译（全部源码，glob 防漏新文件）"
java -cp "$KCP" org.jetbrains.kotlin.cli.jvm.K2JVMCompiler \
    -cp "$AJ:$KM/kotlin-stdlib.jar" -d build/classes -nowarn \
    app/src/main/java/com/filebox/collect/*.kt \
    build/gen_r/R.kt

echo "==> [6/8] 打 jar + 裁剪 kotlin-stdlib + R8 裁剪转 dex"
python3 - <<'EOF'
import zipfile, os
with zipfile.ZipFile("build/app.jar", "w", zipfile.ZIP_DEFLATED) as z:
    n = 0
    for root, _, files in os.walk("build/classes"):
        for f in sorted(files):
            if f.endswith(".class"):
                p = os.path.join(root, f)
                z.write(p, os.path.relpath(p, "build/classes")); n += 1
    print(f"  app.jar: {n} classes")
src = "/home/z/my-project/tools/kotlin-maven/kotlin-stdlib.jar"
with zipfile.ZipFile(src) as zin, zipfile.ZipFile("build/kotlin-stdlib-trim.jar", "w", zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        if item.filename == "module-info.class" or item.filename.startswith("META-INF/versions/"):
            continue
        zout.writestr(item.filename, zin.read(item.filename))
print("  kotlin-stdlib-trim.jar OK")
EOF
# R8 裁剪：keep 清单组件（应用无反射）；坑：必须 -dontwarn org.jetbrains.annotations.**
java -Xmx2g -cp $BT/lib/d8.jar com.android.tools.r8.R8 --release --lib "$AJ" \
    --min-api 24 --pg-conf app/proguard.pro \
    --output build/dexout_r8 build/app.jar build/kotlin-stdlib-trim.jar

echo "==> [7/8] 注入 classes.dex（并确保 resources.arsc 未压缩存储）"
python3 - <<'EOF'
import zipfile, os
with open("build/dexout_r8/classes.dex", "rb") as f:
    dex = f.read()
with zipfile.ZipFile("build/base.apk") as zin, zipfile.ZipFile("build/base_tmp.apk", "w") as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename == "resources.arsc":
            zi = zipfile.ZipInfo(item.filename, date_time=item.date_time)
            zi.compress_type = zipfile.ZIP_STORED  # Android 11+ 硬性要求
            zout.writestr(zi, data)
        else:
            zout.writestr(item, data)
    zout.writestr("classes.dex", dex, compress_type=zipfile.ZIP_DEFLATED)
os.replace("build/base_tmp.apk", "build/base.apk")
print(f"  classes.dex({len(dex)//1024}KB) 注入完成")
EOF

echo "==> [8/8] 对齐 + 签名（v1+v2+v3 全代覆盖）"
$BT/zipalign -f -p 4 build/base.apk build/aligned.apk
if [ ! -f build/filebox.jks ]; then
    keytool -genkeypair -v -keystore build/filebox.jks -storetype PKCS12 \
        -alias filebox -keyalg RSA -keysize 2048 -validity 10950 \
        -storepass filebox2026 -keypass filebox2026 \
        -dname "CN=FileBox, OU=FileBox, O=FileBox, L=Beijing, C=CN" >/dev/null 2>&1
fi
$BT/apksigner sign --v1-signing-enabled true --v2-signing-enabled true \
    --v3-signing-enabled true --v4-signing-enabled false \
    --ks build/filebox.jks --ks-key-alias filebox \
    --ks-pass pass:filebox2026 --key-pass pass:filebox2026 \
    --out "$OUT" build/aligned.apk
$BT/apksigner verify "$OUT" && echo "  签名校验通过"

echo "==> 完成：$OUT（$(du -h "$OUT" | cut -f1)，dex $(du -h build/dexout_r8/classes.dex | cut -f1)）"
