package com.filebox.collect

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.net.Uri
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/**
 * 「选择打开方式」对话框（应用内自绘，风格与全局一致）
 *
 * 用途：
 *  · 长按菜单「选择打开方式」——主动指定某 App 打开
 *  · 直接打开失败（无应用响应精确 MIME）时的自动兜底
 *
 * 逻辑：
 *  1. 按精确 MIME 查询可处理的活动；为空则放宽到通配类型再查
 *    （配合 MimeKit，冷门文件也能列出全部可打开的应用强制打开）
 *  2. 按 packageName 去重，展示应用图标 + 名称 + 包名
 *  3. 点击后以显式组件启动（授予 Uri 临时读权限）
 *
 * 注意：targetSdk 30+ 包可见性过滤——AndroidManifest 已声明
 * queries（ACTION_VIEW + 通配 MIME），否则查询结果为空。
 */
object OpenWithKit {

    /** 入口：显示可打开该 Uri 的应用列表 */
    fun show(a: Activity, uri: Uri, displayName: String, mime: String) {
        val pm = a.packageManager

        fun query(m: String): List<ResolveInfo> = try {
            pm.queryIntentActivities(
                Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, m)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }, 0
            )
        } catch (_: Exception) {
            emptyList()
        }

        var usedMime = mime
        var infos = query(mime)
        if (infos.isEmpty() && mime != "*/*") {
            usedMime = "*/*"
            infos = query("*/*")
        }

        // 去重（同一应用多个入口只保留第一个）
        val seen = HashSet<String>()
        val items = infos.filter { ri ->
            ri.activityInfo != null && seen.add(ri.activityInfo.packageName)
        }

        if (items.isEmpty()) {
            Toast.makeText(a, a.getString(R.string.open_with_none), Toast.LENGTH_SHORT).show()
            return
        }

        val adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(position: Int) = items[position]
            override fun getItemId(position: Int) = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val row = (convertView as? LinearLayout) ?: LinearLayout(a).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(a, 20), dp(a, 10), dp(a, 20), dp(a, 10))
                }
                // 复用行时清空旧内容
                row.removeAllViews()

                val ri = items[position]
                val icon: Drawable? = try {
                    ri.loadIcon(pm)
                } catch (_: Exception) {
                    null
                }
                val iv = ImageView(a)
                if (icon != null) iv.setImageDrawable(icon)
                iv.layoutParams = LinearLayout.LayoutParams(dp(a, 38), dp(a, 38))
                row.addView(iv)

                val tv = LinearLayout(a).apply {
                    orientation = LinearLayout.VERTICAL
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                        leftMargin = dp(a, 14)
                    }
                }
                tv.addView(TextView(a).apply {
                    text = try {
                        ri.loadLabel(pm).toString()
                    } catch (_: Exception) {
                        ri.activityInfo.packageName
                    }
                    setTextColor(SkinKit.text(a))
                    textSize = 15f
                })
                tv.addView(TextView(a).apply {
                    text = ri.activityInfo.packageName
                    setTextColor(SkinKit.textSub(a))
                    textSize = 12f
                })
                row.addView(tv)
                return row
            }
        }

        val list = ListView(a).apply {
            divider = null
            this.adapter = adapter
        }

        DialogKit.show(a, displayName, list, listOf(Triple(a.getString(R.string.btn_close), false, null)))

        list.setOnItemClickListener { _, _, position, _ ->
            val ri = items[position]
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, usedMime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                component = ComponentName(ri.activityInfo.packageName, ri.activityInfo.name)
            }
            try {
                a.startActivity(intent)
            } catch (_: Exception) {
                Toast.makeText(a, a.getString(R.string.err_no_app), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun dp(a: Activity, v: Int): Int =
        (v * a.resources.displayMetrics.density + 0.5f).toInt()
}
