package com.filebox.collect

/**
 * 分类 → 线性图标映射（统一 2px 描边风格，着色由调用方通过 tint 控制）
 */
object CategoryIcons {

    fun forCategory(category: String): Int = when (category) {
        CategoryUtils.CAT_IMAGE -> R.drawable.ic_cat_image
        CategoryUtils.CAT_VIDEO -> R.drawable.ic_cat_video
        CategoryUtils.CAT_AUDIO -> R.drawable.ic_cat_audio
        CategoryUtils.CAT_DOC -> R.drawable.ic_cat_doc
        CategoryUtils.CAT_ARCHIVE -> R.drawable.ic_cat_archive
        CategoryUtils.CAT_APP -> R.drawable.ic_cat_app
        CategoryUtils.CAT_FONT -> R.drawable.ic_cat_font
        else -> R.drawable.ic_cat_other
    }
}
