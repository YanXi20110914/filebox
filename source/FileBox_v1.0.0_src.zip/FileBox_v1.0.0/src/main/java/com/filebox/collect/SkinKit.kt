package com.filebox.collect

import android.app.Activity
import android.content.Context

/**
 * 界面皮肤引擎（十种布局风格）
 *
 * 每种皮肤是一组主题属性叠加，语义令牌见 res/values/attrs.xml：
 *   表面 skinBg / skinBgAlt / skinCard / skinSunken
 *   圆角 skinRadius（卡片） / skinRadiusBtn（按钮） / skinRadiusField（输入框）
 *   描边 skinStroke / skinDivider / skinRowLine / skinFocus
 *   文字 skinText / skinTextSub / skinTextMuted / skinOnAccent
 *   图标 skinIcon / skinCheck    反馈 skinRipple / skinScrim
 *   阴影 skinElev（卡片）/ skinElevOverlay（浮层）
 *   节奏 skinRowPad（行密度）/ skinGutter（页面留白）
 * 切换 = theme.applyStyle 一次性生效，无任何运行时反射或资源替换。
 *
 * 设计约定（十套皮肤共同遵守）：
 *  · 圆角三层递减，扁平皮肤（终端/墨水屏/复古）全为 0
 *  · 扁平皮肤 skinElev = 0，靠描边分层；柔和皮肤（奶油/胶片/霓虹）才用投影
 *  · 深色档一律 skinElev = 0（投影在深底上发灰发脏）
 *  · skinOnAccent 必须与强调色对比 ≥ 4.5:1（品牌色叠加时会覆盖）
 *
 * 恒暗皮肤（终端/胶片/霓虹）浅色/深色模式同值；
 * 其余皮肤 values/skins.xml + values-night/skins.xml 双档自动切换。
 * 强调色（品牌色）与皮肤独立可叠加：applySkin 先、applyBrand 后。
 */
object SkinKit {

    val IDS = arrayOf(
        "minimal", "paper", "terminal", "eink", "retro",
        "zen", "film", "neon", "cream", "pro"
    )

    val NAMES = arrayOf(
        "经典白", "纸张", "终端", "墨水屏", "复古系统",
        "禅意", "胶片暗房", "霓虹", "奶油", "工作台"
    )

    val DESCS = arrayOf(
        "Minimal 原生 · 12dp 圆角轻投影",
        "书页印刷 · 米白直角墨棕",
        "黑底荧光绿 · 硬核极客",
        "高对比黑白 · 2dp 粗边零阴影",
        "Win95 灰阶 · 立体白边",
        "暖白大留白 · 朱砂一点",
        "恒暗暖灰 · 柔橙高光",
        "深蓝黑 · 青色荧光描边",
        "奶白 18dp 大圆角 · 焦糖点缀",
        "冷灰紧凑 · 钢蓝信息密度"
    )

    /** index → style（0 = 默认经典白，不需要叠加） */
    val STYLES = intArrayOf(
        0,
        R.style.SkinPaper, R.style.SkinTerminal, R.style.SkinEink,
        R.style.SkinRetro, R.style.SkinZen, R.style.SkinFilm,
        R.style.SkinNeon, R.style.SkinCream, R.style.SkinPro
    )

    /** 在 setContentView 之前调用（applyBrand 之前） */
    fun apply(a: Activity) {
        val idx = AppSettings.skinIdx(a)
        if (idx in 1..STYLES.lastIndex) {
            a.theme.applyStyle(STYLES[idx], true)
        }
    }

    // ==================== 布局 / 动效规格（v1.9.5：每皮肤独立排版与动画） ====================

    /**
     * 每款皮肤一个 UiSpec：组件位置 + 动效语言，流派决定一切。
     *
     * enterFrom: 0 底部上浮 / 1 左侧切入 / 2 右侧切入（胶片过片）
     *            3 顶部逐行下压（终端打印）/ 4 缩放弹出 / 5 直显（零位移）
     */
    data class UiSpec(
        val titleCenter: Boolean,   // 标题居中排版
        val titleMono: Boolean,     // 标题等宽字体
        val barLine: Boolean,       // 顶栏下方分隔线
        val listPadDp: Int,         // 列表左右边距
        val gridCols: Int,          // 网格列数
        val enterFrom: Int,
        val enterDur: Long,
        val enterStagger: Long,
        val enterOvershoot: Boolean,// 回弹过冲插值
        val pressScale: Float,      // 按压缩放（>=0.995 = 无按压动画）
        val pressSink: Boolean,     // 按压下沉 1.5dp（Win95 按钮手感）
        val homeWide: Boolean = false,  // 主页：四按钮全宽竖排（大气版）
        val homeLeft: Boolean = false   // 主页：内容左对齐（信息效率版）
    )

    private val SPECS = arrayOf(
        // 0 经典白 Minimal：全宽大按钮主页（大气版）
        UiSpec(false, false, false, 18, 3, 0, 240, 35, false, 0.98f, false, homeWide = true),
        // 1 纸张 书页：纸不动——只有左缓入与透明度
        UiSpec(false, false, true, 16, 3, 1, 320, 45, false, 0.995f, false),
        // 2 终端：紧凑四列、逐行打印式入场、主页左对齐
        UiSpec(false, true, true, 12, 4, 3, 170, 26, false, 0.97f, false, homeLeft = true),
        // 3 墨水屏：居中排版、刷新式直显、零按压动画
        UiSpec(true, false, true, 16, 3, 5, 90, 0, false, 0.995f, false),
        // 4 复古系统 Win95：无动画直显、按压整体下沉
        UiSpec(false, false, true, 12, 4, 5, 1, 0, false, 0.995f, true),
        // 5 禅意：居中细排版、大二列、主页全宽大按钮
        UiSpec(true, false, false, 22, 2, 0, 460, 65, false, 0.99f, false, homeWide = true),
        // 6 胶片暗房：右侧过片滑入
        UiSpec(false, false, false, 16, 3, 2, 280, 40, false, 0.97f, false),
        // 7 霓虹：缩放弹出带回弹、按压最弹
        UiSpec(false, false, true, 16, 3, 4, 340, 45, true, 0.95f, false),
        // 8 奶油：软弹上浮、主页全宽大按钮
        UiSpec(false, false, false, 18, 3, 0, 330, 48, true, 0.97f, false, homeWide = true),
        // 9 工作台 Pro：四列高密度、主页左对齐
        UiSpec(false, false, true, 14, 4, 1, 170, 16, false, 0.995f, false, homeLeft = true)
    )

    /** 当前皮肤的布局/动效规格 */
    fun uiSpec(ctx: Context): UiSpec = SPECS[AppSettings.skinIdx(ctx).coerceIn(0, SPECS.lastIndex)]

    /**
     * 解析某皮肤的预览三色（卡底/强调/描边）——用于选项卡色样点。
     * newTheme 副本上 applyStyle，不污染当前 Activity 主题。
     */
    fun previewColors(ctx: Context, idx: Int): IntArray {
        val tm = ctx.resources.newTheme()
        tm.setTo(ctx.theme)
        if (idx in 1..STYLES.lastIndex) tm.applyStyle(STYLES[idx], true)
        return try {
            val ta = tm.obtainStyledAttributes(
                intArrayOf(R.attr.skinCard, R.attr.skinAccent, R.attr.skinStroke)
            )
            intArrayOf(
                ta.getColor(0, 0xFFFFFFFF.toInt()),
                ta.getColor(1, 0xFF3B82F6.toInt()),
                ta.getColor(2, 0xFFE5E6EB.toInt())
            )
        } catch (_: Exception) {
            intArrayOf(0xFFFFFFFF.toInt(), 0xFF3B82F6.toInt(), 0xFFE5E6EB.toInt())
        }
    }

    // ==================== 代码侧 Drawable 工厂 ====================
    // shape XML 的 ?attr 在部分系统版本上不可靠，代码里 obtainStyledAttributes
    // 永远带 theme，任何 API 行为一致 —— 统一走这里，不再 getDrawable。

    /** 读主题 attr 颜色（fallback 保底） */
    fun attrColor(ctx: Context, attr: Int, fallback: Int): Int = try {
        val ta = ctx.theme.obtainStyledAttributes(intArrayOf(attr))
        val c = ta.getColor(0, fallback); ta.recycle(); c
    } catch (_: Exception) {
        fallback
    }

    private fun attrDimenPx(ctx: Context, attr: Int, fallbackDp: Int): Int = try {
        val ta = ctx.theme.obtainStyledAttributes(intArrayOf(attr))
        val v = ta.getDimensionPixelSize(0, -1); ta.recycle()
        if (v >= 0) v else (fallbackDp * ctx.resources.displayMetrics.density + 0.5f).toInt()
    } catch (_: Exception) {
        (fallbackDp * ctx.resources.displayMetrics.density + 0.5f).toInt()
    }

    // ==================== 令牌快捷读取 ====================
    // 代码侧统一入口：布局用 ?attr/skinXxx，代码用这里的 xxx(ctx)，两侧同源

    /** 主文字色 */
    fun text(ctx: Context): Int = attrColor(ctx, R.attr.skinText, 0xFF1D2129.toInt())

    /** 次级文字色 */
    fun textSub(ctx: Context): Int = attrColor(ctx, R.attr.skinTextSub, 0xFF61697A.toInt())

    /** 弱化文字色 */
    fun textMuted(ctx: Context): Int = attrColor(ctx, R.attr.skinTextMuted, 0xFF8A929E.toInt())

    /** 强调色之上的文字/图标色（转发 BrandKit，含 WCAG 自动推导） */
    fun onAccent(ctx: Context): Int = BrandKit.onAccent(ctx)

    /** 涟漪色 */
    fun ripple(ctx: Context): Int = attrColor(ctx, R.attr.skinRipple, 0x14000000)

    /** 分隔线色 */
    fun divider(ctx: Context): Int = attrColor(ctx, R.attr.skinDivider, 0xFFE5E6EB.toInt())

    /** 线性图标色 */
    fun icon(ctx: Context): Int = attrColor(ctx, R.attr.skinIcon, 0xFF61697A.toInt())

    /** 卡片阴影高度（扁平皮肤为 0） */
    fun cardElev(ctx: Context): Int = attrDimenPx(ctx, R.attr.skinElev, 1)

    /** 浮层阴影高度 */
    fun overlayElev(ctx: Context): Int = attrDimenPx(ctx, R.attr.skinElevOverlay, 6)

    /** 卡片圆角（px） */
    fun cardRadius(ctx: Context): Float =
        attrDimenPx(ctx, R.attr.skinRadius, 12).toFloat()

    /** 按钮圆角（px） */
    fun btnRadius(ctx: Context): Float =
        attrDimenPx(ctx, R.attr.skinRadiusBtn, 10).toFloat()

    /** 输入框圆角（px） */
    fun fieldRadius(ctx: Context): Float =
        attrDimenPx(ctx, R.attr.skinRadiusField, 10).toFloat()

    /** 卡片底：皮肤卡色 + 描边 + 皮肤圆角（不带涟漪） */
    fun card(ctx: Context): android.graphics.drawable.Drawable {
        val g = android.graphics.drawable.GradientDrawable()
        g.shape = android.graphics.drawable.GradientDrawable.RECTANGLE
        g.setColor(attrColor(ctx, R.attr.skinCard, 0xFFFFFFFF.toInt()))
        val sw = attrDimenPx(ctx, R.attr.skinStrokeW, 1)
        val sc = attrColor(ctx, R.attr.skinStroke, 0xFFE5E6EB.toInt())
        if (sw > 0) g.setStroke(sw, sc)
        g.cornerRadius = cardRadius(ctx)
        return g
    }

    /** 主按钮：强调色实心 + 按钮圆角 + 涟漪 */
    fun primaryBtn(ctx: Context): android.graphics.drawable.Drawable {
        val content = android.graphics.drawable.GradientDrawable().apply {
            shape = android.graphics.drawable.GradientDrawable.RECTANGLE
            setColor(BrandKit.accent(ctx))
            cornerRadius = btnRadius(ctx)
        }
        return android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(0x40FFFFFF),
            content, null
        )
    }

    /** 次按钮：卡片形 + 皮肤涟漪色 */
    fun secondaryBtn(ctx: Context): android.graphics.drawable.Drawable =
        android.graphics.drawable.RippleDrawable(
            android.content.res.ColorStateList.valueOf(ripple(ctx)),
            card(ctx), null
        )

    /** 输入框：聚焦强调色边 / 静默细边（StateListDrawable 等价 bg_input） */
    fun input(ctx: Context): android.graphics.drawable.Drawable {
        val radius = fieldRadius(ctx)
        val sunken = attrColor(ctx, R.attr.skinSunken, 0xFFF2F3F5.toInt())
        val dividerC = divider(ctx)
        val focus = attrColor(ctx, R.attr.skinFocus, BrandKit.accent(ctx))

        fun shape(strokeColor: Int): android.graphics.drawable.GradientDrawable =
            android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.RECTANGLE
                setColor(sunken)
                setStroke(1, strokeColor)
                cornerRadius = radius
            }

        val states = android.graphics.drawable.StateListDrawable()
        states.addState(intArrayOf(android.R.attr.state_focused), shape(focus))
        states.addState(intArrayOf(), shape(dividerC))
        return states
    }

    /**
     * 分类图标圆底（层次版）：外环强调色 12% 光晕 + 内圆强调色实心，
     * 白色分类图标落在内圆上，双环拉开层次。
     */
    /** 图标 tint：随皮肤感知（墨水屏用深墨色黑白对比，其余跟品牌强调色） */
    fun iconTint(ctx: Context): Int =
        if (AppSettings.skinIdx(ctx) == 3) attrColor(ctx, R.attr.skinText, 0xFF222222.toInt())
        else BrandKit.accent(ctx)

    /** 图标底形状随皮肤：终端/复古/纸张走方角，其余圆形 */
    private fun sharpIcon(ctx: Context): Boolean =
        AppSettings.skinIdx(ctx) in intArrayOf(1, 2, 4)

    fun badgeCat(ctx: Context): android.graphics.drawable.Drawable {
        val inset = (2.5f * ctx.resources.displayMetrics.density + 0.5f).toInt()
        val shape = if (sharpIcon(ctx)) RECT else android.graphics.drawable.GradientDrawable.OVAL
        val radius = if (sharpIcon(ctx)) 3f * ctx.resources.displayMetrics.density else 0f
        val outer = android.graphics.drawable.GradientDrawable().apply {
            this.shape = shape
            setColor(BrandKit.accentBg(ctx))
            if (radius > 0) cornerRadius = radius
        }
        val inner = android.graphics.drawable.GradientDrawable().apply {
            this.shape = shape
            setColor(iconTint(ctx))
            if (radius > 0) cornerRadius = radius
            setStroke(1, shade(iconTint(ctx), 0.82f))
        }
        return android.graphics.drawable.LayerDrawable(
            arrayOf(outer, inner)
        ).apply { setLayerInset(1, inset, inset, inset, inset) }
    }

    /**
     * 文件夹圆底（层次版）：外环强调色 12% 光晕 + 内圆同色浅底带细描边，
     * 文件夹线性图标浮在双圈之上。
     */
    fun badgeFolder(ctx: Context): android.graphics.drawable.Drawable {
        val inset = (2.5f * ctx.resources.displayMetrics.density + 0.5f).toInt()
        val shape = if (sharpIcon(ctx)) RECT else android.graphics.drawable.GradientDrawable.OVAL
        val radius = if (sharpIcon(ctx)) 3f * ctx.resources.displayMetrics.density else 0f
        val outer = android.graphics.drawable.GradientDrawable().apply {
            this.shape = shape
            setColor(BrandKit.accentBg(ctx))
            if (radius > 0) cornerRadius = radius
        }
        val inner = android.graphics.drawable.GradientDrawable().apply {
            this.shape = shape
            setColor(BrandKit.accentBg(ctx))
            if (radius > 0) cornerRadius = radius
            setStroke(1, icon(ctx))
        }
        // 右下强调角标点（文件夹身份识别，v1.10.2）
        val dot = android.graphics.drawable.GradientDrawable().apply {
            this.shape = shape
            setColor(iconTint(ctx))
            cornerRadius = if (sharpIcon(ctx)) 1f * ctx.resources.displayMetrics.density
            else dpOf(ctx, 2).toFloat()
        }
        val dotSize = dpOf(ctx, 5)
        return android.graphics.drawable.LayerDrawable(
            arrayOf(outer, inner, dot)
        ).apply {
            setLayerInset(1, inset, inset, inset, inset)
            setLayerInset(2, inset + dotSize * 3, inset + dotSize * 3, inset, inset)
            setLayerSize(2, dotSize, dotSize)
        }
    }

    /** 颜色加深（0-1，<1 变暗） */
    private fun shade(color: Int, f: Float): Int {
        val r = ((color shr 16 and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = ((color shr 8 and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((color and 0xFF) * f).toInt().coerceIn(0, 255)
        return 0xFF000000.toInt() or (r shl 16) or (g shl 8) or b
    }

    private fun dpOf(ctx: Context, v: Int): Int =
        (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    private const val RECT = android.graphics.drawable.GradientDrawable.RECTANGLE
}
