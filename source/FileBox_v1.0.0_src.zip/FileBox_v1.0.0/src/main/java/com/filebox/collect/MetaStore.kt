package com.filebox.collect

import android.content.Context
import org.json.JSONObject

/**
 * 文件元数据（收藏星标 + 备注）
 *
 * 存储独立于文件系统（SharedPreferences），key = 文件绝对路径（根目录引擎）
 * 或 document uri（SAF 引擎）。文件被重命名/删除后条目由清理逻辑移除。
 */
object MetaStore {

    private const val PREFS = "filebox_meta"
    private const val KEY_STARS = "stars"
    private const val KEY_NOTES = "notes_json"

    // ==================== 收藏 ====================

    fun isStarred(ctx: Context, key: String): Boolean =
        prefs(ctx).getStringSet(KEY_STARS, emptySet())?.contains(key) == true

    fun toggleStar(ctx: Context, key: String): Boolean {
        val cur = HashSet(prefs(ctx).getStringSet(KEY_STARS, emptySet()) ?: emptySet())
        val added = if (cur.contains(key)) {
            cur.remove(key); false
        } else {
            cur.add(key); true
        }
        prefs(ctx).edit().putStringSet(KEY_STARS, cur).apply()
        return added
    }

    fun starKeys(ctx: Context): Set<String> =
        HashSet(prefs(ctx).getStringSet(KEY_STARS, emptySet()) ?: emptySet())

    // ==================== 备注 ====================

    /** 返回该文件的备注（无则 null） */
    fun noteFor(ctx: Context, key: String): String? {
        val json = prefs(ctx).getString(KEY_NOTES, null) ?: return null
        return try {
            JSONObject(json).optString(key).ifBlank { null }
        } catch (_: Exception) {
            null
        }
    }

    fun setNote(ctx: Context, key: String, note: String?) {
        val map = notesMap(ctx)
        if (note.isNullOrBlank()) map.remove(key) else map[key] = note
        prefs(ctx).edit().putString(KEY_NOTES, JSONObject(map).toString()).apply()
    }

    /** 批量移除失效条目（路径前缀匹配，删除/重命名后调用） */
    fun cleanupPrefix(ctx: Context, prefix: String) {
        val stars = starKeys(ctx)
        val dead = stars.filter { it.startsWith(prefix) }
        if (dead.isNotEmpty()) {
            val cur = HashSet(stars); cur.removeAll(dead.toSet())
            prefs(ctx).edit().putStringSet(KEY_STARS, cur).apply()
        }
        val map = notesMap(ctx)
        val deadKeys = map.keys.filter { it.startsWith(prefix) }
        if (deadKeys.isNotEmpty()) {
            deadKeys.forEach { map.remove(it) }
            prefs(ctx).edit().putString(KEY_NOTES, JSONObject(map).toString()).apply()
        }
    }

    private fun notesMap(ctx: Context): HashMap<String, String> {
        val json = prefs(ctx).getString(KEY_NOTES, null) ?: return HashMap()
        return try {
            val out = HashMap<String, String>()
            JSONObject(json).keys().forEach { k -> out[k] = JSONObject(json).optString(k) }
            out
        } catch (_: Exception) {
            HashMap()
        }
    }

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
