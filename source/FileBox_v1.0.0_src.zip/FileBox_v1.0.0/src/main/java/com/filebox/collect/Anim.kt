package com.filebox.collect

import android.content.Context
import android.provider.Settings
import android.view.MotionEvent
import android.view.View
import android.view.animation.Interpolator
import android.view.animation.PathInterpolator
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * 动画规范（非线性动画）
 *
 *  - 禁用 linear 与默认 ease，统一：
 *    · 入场/弹出（回弹感）：cubic-bezier(0.34, 1.56, 0.64, 1)  → [ENTER]
 *    · 退场/移出（加速离场）：cubic-bezier(0.4, 0, 1, 1)        → [EXIT]
 *    · 位移/交错入场：弹簧物理（欠阻尼，stiffness≈260 damping≈20）→ [SPRING]
 *  - 时长标准：微交互 175ms / 组件级 275ms / 页面级 350ms
 *  - 列表交错入场：每项延迟 48ms
 *  - 所有动画基于 ViewPropertyAnimator / ValueAnimator，可中断、可交互动
 *  - 遵循系统「移除动画」偏好（动画时长缩放为 0 时降级为直接切换）
 */
object Anim {

    /** 入场/弹出：带回弹感 */
    val ENTER: Interpolator = PathInterpolator(0.34f, 1.56f, 0.64f, 1f)

    /** 退场/移出：加速离场 */
    val EXIT: Interpolator = PathInterpolator(0.4f, 0f, 1f, 1f)

    /** 位移类：欠阻尼弹簧（stiffness 260 / damping 20 的近似解析解） */
    class Spring : Interpolator {
        override fun getInterpolation(t: Float): Float {
            val w = 16.2f      // 角频率（对应 stiffness 260）
            val z = 0.62f      // 阻尼比（对应 damping 20）
            val wd = w * sqrt(1f - z * z)
            val tau = t * 0.72f
            val e = exp(-z * w * tau)
            val v = 1f - e * (cos(wd * tau) + (z * w / wd) * sin(wd * tau))
            return if (v < 0f) 0f else v
        }
    }

    val SPRING: Spring = Spring()

    // ---- 时长标准 ----
    const val DUR_MICRO = 175L      // 微交互（按压缩放等）
    const val DUR_COMPONENT = 275L  // 组件级（弹窗、卡片入场）
    const val DUR_PAGE = 350L       // 页面级
    const val STAGGER_MS = 48L      // 列表交错延迟

    /** 用户关闭动画偏好（动画时长缩放为 0）时降级为直接切换 */
    fun reducedMotion(ctx: Context): Boolean = try {
        Settings.Global.getFloat(
            ctx.contentResolver,
            Settings.Global.ANIMATOR_DURATION_SCALE, 1f
        ) <= 0f
    } catch (_: Exception) {
        false
    }

    fun dp(ctx: Context, v: Int): Int =
        (v * ctx.resources.displayMetrics.density + 0.5f).toInt()

    /** 骨架屏脉冲：透明度呼吸循环（视图离开窗口后自动停止） */
    fun pulse(v: View) {
        v.animate().cancel()
        v.animate()
            .alpha(1f)
            .setDuration(650L)
            .setInterpolator(EXIT)
            .withEndAction {
                v.animate()
                    .alpha(0.55f)
                    .setDuration(650L)
                    .setInterpolator(ENTER)
                    .withEndAction { if (v.isAttachedToWindow) pulse(v) }
                    .start()
            }
            .start()
    }

    /**
     * 按压反馈：手感跟皮肤走（v1.9.5）——
     *  · 标准：按下缩放至 spec.pressScale，抬起弹回；
     *  · pressSink（复古系统）：整体下沉 1.5dp（Win95 按钮手感）；
     *  · pressScale >= 0.995（纸张/墨水屏/工作台）：无按压动画。
     */
    fun pressable(view: View) {
        val spec = SkinKit.uiSpec(view.context)
        if (spec.pressScale >= 0.995f && !spec.pressSink) return
        view.setOnTouchListener { v, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    if (spec.pressSink) {
                        v.animate().translationY(v.context.resources.displayMetrics.density * 1.5f)
                            .setDuration(DUR_MICRO).setInterpolator(EXIT).start()
                    } else {
                        v.animate().scaleX(spec.pressScale).scaleY(spec.pressScale)
                            .setDuration(DUR_MICRO).setInterpolator(EXIT).start()
                    }
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> v.animate()
                    .scaleX(1f).scaleY(1f).translationY(0f)
                    .setDuration(DUR_MICRO).setInterpolator(ENTER).start()
            }
            false // 不消费事件，保证点击正常分发
        }
    }

    /**
     * 列表/卡片交错入场 —— 动效语言跟皮肤走（v1.9.5）：
     *  · 经典白/禅意/奶油：底部上浮（禅意极缓、奶油带软弹）
     *  · 纸张/工作台：左侧切入（书页翻动 / 效率快切）
     *  · 胶片暗房：右侧滑入（胶片过片方向）
     *  · 终端：顶部逐行下压（打印输出感）
     *  · 霓虹：缩放弹出带过冲
     *  · 墨水屏/复古：直显（墨水屏刷新感 / Win95 无动画）
     * 再次调用会先取消旧动画（可中断、可交互动）。
     */
    fun staggerIn(views: List<View>, reduced: Boolean) {
        val spec = views.firstOrNull()?.let { SkinKit.uiSpec(it.context) }
            ?: SkinKit.UiSpec(false, false, false, 18, 3, 0, 240, 35, false, 0.98f, false)
        val from = spec.enterFrom
        if (reduced || (from == 5 && spec.enterDur <= 1L)) {
            // 关动画偏好 / 复古零动画：直接归位
            views.forEach {
                it.animate().cancel()
                it.alpha = 1f
                it.translationY = 0f
                it.translationX = 0f
                it.scaleX = 1f
                it.scaleY = 1f
            }
            return
        }
        views.forEachIndexed { i, v ->
            v.animate().cancel()
            when (from) {
                0 -> v.translationY = dp(v.context, 14).toFloat()
                1 -> v.translationX = dp(v.context, -20).toFloat()
                2 -> v.translationX = dp(v.context, 20).toFloat()
                3 -> v.translationY = dp(v.context, -8).toFloat()
                4 -> { v.scaleX = 0.9f; v.scaleY = 0.9f }
            }
            v.alpha = 0f
            v.animate()
                .alpha(1f).translationY(0f).translationX(0f)
                .scaleX(1f).scaleY(1f)
                .setStartDelay(minOf(i, 10) * spec.enterStagger)
                .setDuration(spec.enterDur)
                .setInterpolator(
                    when {
                        spec.enterOvershoot -> android.view.animation.OvershootInterpolator(1.25f)
                        from == 5 -> android.view.animation.DecelerateInterpolator(2f)
                        else -> SPRING
                    }
                )
                .start()
        }
    }
}
