package com.filebox.collect

import android.app.Activity
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import android.view.View
import android.widget.FrameLayout
import android.view.Gravity

/**
 * 主题引擎（深色模式 + 强调色支持，无 AppCompat 依赖）
 *
 * 原理：Activity 重写 attachBaseContext 时用 [wrap] 包装基础 Context——
 * 强制浅色/深色时覆写 Configuration 的夜间模式标记，
 * 这样所有资源解析（values-night 色板、drawable 引用）自动切换，
 * 跟随系统时原样返回（系统切换夜间模式时 Activity 自动重建）。
 *
 * [apply] 负责修正状态栏颜色与图标明暗（强制模式下主题资源不会自动跟随）。
 * [applyBrand] 在 setContentView 前叠加用户选择的强调色主题包
 * （XML 中 ?android:attr/colorAccent 引用处全部联动）。
 */
object ThemeKit {

    /** 最近一次由设置页写入的主题（供主页 onResume 检测变化后重建） */
    @JvmField
    var stampFromSettings: String? = null

    /** 强调色主题包（index 对应设置页圆点；0=默认蓝不叠加） */
    private val BRAND_STYLES = intArrayOf(
        0,
        R.style.BrandGreen, R.style.BrandOrange,
        R.style.BrandRed, R.style.BrandPurple, R.style.BrandCyan
    )

    /** 按设置包装 Context */
    fun wrap(base: Context): Context {
        val mode = AppSettings.themeMode(base)
        val cur = base.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK
        var target = when (mode) {
            AppSettings.THEME_LIGHT -> Configuration.UI_MODE_NIGHT_NO
            AppSettings.THEME_DARK -> Configuration.UI_MODE_NIGHT_YES
            else -> cur
        }
        // 恒暗皮肤（终端/胶片/霓虹）：任何模式下强制夜色，
        // 否则黑底 + 白天档黑字 = 全页不可辨（v1.9.3 根修）
        if (AppSettings.skinIdx(base) in ALWAYS_DARK_SKINS) {
            target = Configuration.UI_MODE_NIGHT_YES
        }
        // 字体大小（v1.9.7）：全局 sp 缩放
        val fs = AppSettings.fontScaleFactor(base)
        val curFs = base.resources.configuration.fontScale
        if (target == cur && fs == curFs) return base
        val cfg = Configuration(base.resources.configuration)
        cfg.uiMode = target or (cfg.uiMode and Configuration.UI_MODE_NIGHT_MASK.inv())
        cfg.fontScale = fs
        return base.createConfigurationContext(cfg)
    }

    /** 恒暗皮肤序号（SkinKit.IDS 对应：2 终端 / 6 胶片暗房 / 7 霓虹） */
    private val ALWAYS_DARK_SKINS = intArrayOf(2, 6, 7)

    /** 状态栏/导航栏颜色与图标明暗：读皮肤属性（须在 SkinKit.apply 之后调用） */
    fun apply(a: Activity) {
        val ta = a.theme.obtainStyledAttributes(
            intArrayOf(R.attr.skinBg, android.R.attr.windowLightStatusBar)
        )
        val bg = ta.getColor(0, a.getColor(R.color.bg_page))
        val lightIcons = ta.getBoolean(1, true)
        ta.recycle()
        a.window.statusBarColor = bg
        a.window.navigationBarColor = bg
        if (Build.VERSION.SDK_INT >= 23) {
            val decor = a.window.decorView
            var flags = decor.systemUiVisibility
            flags = if (lightIcons) flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            else flags and View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR.inv()
            decor.systemUiVisibility = flags
        }
    }

    /** 叠加用户选择的强调色（onCreate、setContentView 之前调用） */
    fun applyBrand(a: Activity) {
        // v1.11.8：强调色并入皮肤（skinAccent 直通），品牌叠加不再需要
        if (true) return
        val idx = AppSettings.brandIdx(a)
        if (idx in 1 until BRAND_STYLES.size) {
            try {
                a.theme.applyStyle(BRAND_STYLES[idx], true)
            } catch (_: Exception) {
            }
        }
    }

    /**
     * 大屏 / 分屏 / 横屏适配：把内容列宽度限制在 maxDp 以内并保持水平居中。
     * 手机竖屏（可用宽 < maxDp）完全无感知；平板、分屏、横屏时内容不再拉满全宽。
     * 保留原 layout_gravity 的垂直分量（保存面板等垂直居中场景不受影响）。
     */
    fun capWidth(v: View, maxDp: Int = 640) {
        v.post {
            val maxPx = (maxDp * v.resources.displayMetrics.density + 0.5f).toInt()
            val target = minOf(v.width, maxPx)
            val lp = v.layoutParams as? FrameLayout.LayoutParams ?: return@post
            if (lp.width != target) {
                lp.width = target
                val vGrav = lp.gravity and Gravity.VERTICAL_GRAVITY_MASK
                lp.gravity = Gravity.CENTER_HORIZONTAL or vGrav
                v.layoutParams = lp
            }
        }
    }
}

/** 强调色取值（代码侧统一入口，替代 getColor(R.color.brand)） */
object BrandKit {

    /** 可选强调色（设置页圆点顺序；0 = 默认蓝） */
    val PALETTE = intArrayOf(
        0xFF165DFF.toInt(), 0xFF00B42A.toInt(), 0xFFFF7D00.toInt(),
        0xFFF53F3F.toInt(), 0xFF722ED1.toInt(), 0xFF0FA8A8.toInt()
    )

    /** 当前生效强调色：直通当前皮肤 skinAccent（主题色设定已随皮肤走，v1.11.8） */
    fun accent(ctx: Context): Int {
        val fallback = PALETTE[0]
        return try {
            val ta = ctx.theme.obtainStyledAttributes(intArrayOf(R.attr.skinAccent))
            val c = ta.getColor(0, fallback); ta.recycle(); c
        } catch (_: Exception) {
            fallback
        }
    }

    /** 强调色浅淡背景（徽章底）：由 accent 派生 12% 透明度 */
    fun accentBg(ctx: Context): Int =
        (accent(ctx) and 0x00FFFFFF) or 0x1F000000

    /**
     * 强调色之上的文字/图标色：优先读皮肤/品牌令牌 skinOnAccent；
     * 令牌缺失时按 WCAG 相对亮度自动选黑或白，保证任意强调色下按钮文字都可读。
     */
    fun onAccent(ctx: Context): Int {
        val a = accent(ctx)
        return try {
            val ta = ctx.theme.obtainStyledAttributes(intArrayOf(R.attr.skinOnAccent))
            val has = ta.hasValue(0)
            val c = ta.getColor(0, 0); ta.recycle()
            if (has) c else autoOnAccent(a)
        } catch (_: Exception) {
            autoOnAccent(a)
        }
    }

    /** WCAG 相对亮度 > 0.55 视为亮底 → 用深色字 */
    private fun autoOnAccent(accent: Int): Int {
        fun lin(c: Int): Double {
            val s = c / 255.0
            return if (s <= 0.03928) s / 12.92
            else Math.pow((s + 0.055) / 1.055, 2.4)
        }
        val lum = 0.2126 * lin((accent shr 16) and 0xFF) +
                0.7152 * lin((accent shr 8) and 0xFF) +
                0.0722 * lin(accent and 0xFF)
        return if (lum > 0.55) 0xFF1A1A1A.toInt() else 0xFFFFFFFF.toInt()
    }

    /** 白色（按钮文字等常量） */
    val WHITE = Color.WHITE
}
