package com.filebox.collect

import android.app.Activity
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Build
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * APK 直装（v1.9.6）
 *
 * 收纳的应用文件一键进系统安装器：
 *  · 文件页 / 网格：点 APK 行 → 安装确认卡（应用图标 + 名称 + 包名 + 大小）
 *  · 历史页：单击卡片或长按菜单同样直达
 *
 * 实现：BoxProvider content Uri + ACTION_VIEW（application/vnd.android.package-archive）
 * 交给系统包安装器——不声明 REQUEST_INSTALL_PACKAGES（避免商店审查标记），
 * 「允许安装未知应用」由系统安装器引导用户授权，零权限负担。
 */
object InstallKit {

    fun isApk(name: String): Boolean = name.endsWith(".apk", ignoreCase = true)

    /** 读取 APK 元信息：应用名 + 图标（失败返回 null，界面回退文件名） */
    fun appInfo(ctx: android.content.Context, f: File): Pair<String, Drawable?>? = try {
        val pm = ctx.packageManager
        val info = pm.getPackageArchiveInfo(f.absolutePath, 0) ?: return null
        val ai = info.applicationInfo ?: return null
        ai.sourceDir = f.absolutePath
        ai.publicSourceDir = f.absolutePath
        Pair(ai.loadLabel(pm).toString(), ai.loadIcon(pm) as? Drawable)
    } catch (_: Exception) {
        null
    }

    /** 拉起系统安装器：先 ACTION_VIEW，失败走 PackageInstaller 会话直装（Android 14+ 兜底） */
    fun install(ctx: android.content.Context, f: File): Boolean {
        // 路径一：系统安装器（Android 13- 标准路径）
        val viewOk = try {
            val i = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(BoxProvider.uriFor(f), "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            ctx.startActivity(i)
            true
        } catch (_: Exception) {
            false
        }
        if (viewOk) return true

        // 路径二：PackageInstaller 流式会话（Android 14+ 可用，同样由系统引导授权）
        if (Build.VERSION.SDK_INT < 24) return false
        return try {
            val pi = ctx.packageManager.packageInstaller
            val params = android.content.pm.PackageInstaller.SessionParams(
                android.content.pm.PackageInstaller.SessionParams.MODE_FULL_INSTALL
            )
            val size = f.length()
            params.setSize(size)
            val sessionId = pi.createSession(params)
            val session = pi.openSession(sessionId)
            session.openWrite("apk", 0, size).use { out ->
                f.inputStream().use { it.copyTo(out) }
                session.fsync(out)
            }
            // 安装结果回执
            val status = Intent("com.filebox.collect.INSTALL_RESULT")
            val piSender = android.app.PendingIntent.getBroadcast(
                ctx, sessionId, status,
                android.app.PendingIntent.FLAG_UPDATE_CURRENT or
                    (if (Build.VERSION.SDK_INT >= 31)
                        android.app.PendingIntent.FLAG_MUTABLE
                    else 0)
            )
            session.commit(piSender.intentSender)
            session.close()
            true
        } catch (_: Exception) {
            false
        }
    }

    /** 安装确认卡：应用图标 + 名称 + 包名 + 大小（内置弹窗） */
    fun confirm(a: Activity, f: File) {
        val ctx = a
        val info = appInfo(ctx, f)
        val name = info?.first ?: f.name
        val icon: Drawable? = info?.second
        val pkg: String? = try {
            ctx.packageManager.getPackageArchiveInfo(f.absolutePath, 0)?.packageName
        } catch (_: Exception) {
            null
        }
        val subColor = (SkinKit.text(ctx) and 0x00FFFFFF) or 0x99000000.toInt()

        val row = LinearLayout(ctx).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, ctx.resources.displayMetrics.density.toInt() * 4, 0, 0)
        }
        val iconView = ImageView(ctx).apply {
            if (icon != null) setImageDrawable(icon) else setImageResource(R.drawable.ic_cat_app)
            background = SkinKit.badgeCat(ctx)
            setPadding(
                ctx.resources.displayMetrics.density.toInt() * 8,
                ctx.resources.displayMetrics.density.toInt() * 8,
                ctx.resources.displayMetrics.density.toInt() * 8,
                ctx.resources.displayMetrics.density.toInt() * 8
            )
        }
        row.addView(
            iconView, LinearLayout.LayoutParams(ctx.resources.displayMetrics.density.toInt() * 46, ctx.resources.displayMetrics.density.toInt() * 46)
        )
        val col = LinearLayout(ctx).apply { orientation = LinearLayout.VERTICAL }
        col.addView(
            TextView(ctx).apply {
                text = name
                textSize = 15f
                setTextColor(SkinKit.text(ctx))
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
            }
        )
        col.addView(
            TextView(ctx).apply {
                text = HistoryStore.fmtSize(f.length())
                textSize = 12f
                setTextColor(subColor)
            }
        )
        if (pkg != null) {
            col.addView(
                TextView(ctx).apply {
                    text = pkg
                    textSize = 11f
                    setTextColor(subColor)
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                }
            )
        }
        row.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        DialogKit.show(
            a, a.getString(R.string.install_title), row,
            listOf(
                Triple(a.getString(R.string.btn_close), false, null),
                Triple(a.getString(R.string.install_btn), true) {
                    if (!install(ctx, f)) {
                        Toast.makeText(ctx, R.string.install_fail, Toast.LENGTH_SHORT).show()
                    }
                    Unit
                }
            )
        )
    }
}
