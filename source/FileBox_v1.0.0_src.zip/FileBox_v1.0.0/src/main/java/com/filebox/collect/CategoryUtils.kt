package com.filebox.collect

import android.content.ContentResolver
import android.net.Uri

/**
 * 文件分类工具类
 *
 * 职责：把一个文件名（或 Uri）映射到「我的文件」下的目标子文件夹。
 *
 * 匹配顺序（严格按需求实现）：
 *  1. 复合扩展名特判：以 tar.gz / tar.bz2 / tar.xz / tar.zst / tar.lzma 结尾 → 压缩包
 *  2. 扩展名查表：filename.substringAfterLast('.', "").lowercase() 后查 [EXT_MAP]
 *  3. MIME 兜底：用 ContentResolver 读取 Uri 的 MIME 类型判断
 *     image 开头 → 图片；video 开头 → 视频；audio 开头 → 音频；
 *     application/pdf → 文档；application/vnd.android.package-archive → 应用；
 *     zip/rar/7z 等压缩 MIME → 压缩包
 *  4. 仍无法识别 / 无扩展名 → 其他
 *
 * 所有扩展名 → 分类的映射集中在 [EXT_MAP]（HashMap），便于日后增删。
 */
object CategoryUtils {

    // ==================== 分类目录名（「我的文件」下的子文件夹） ====================

    const val CAT_IMAGE = "图片"
    const val CAT_VIDEO = "视频"
    const val CAT_AUDIO = "音频"
    const val CAT_DOC = "文档"
    const val CAT_APP = "应用"
    const val CAT_ARCHIVE = "压缩包"
    const val CAT_FONT = "字体"
    const val CAT_OTHER = "其他"

    /** 全部分类（设置页规则选择 / 历史筛选用） */
    val ALL_CATS = listOf(
        CAT_IMAGE, CAT_VIDEO, CAT_AUDIO, CAT_DOC,
        CAT_APP, CAT_ARCHIVE, CAT_FONT, CAT_OTHER
    )

    /** 复合扩展名：命中即直接归入压缩包（大小写不敏感） */
    private val COMPOUND_ARCHIVE_EXTS = arrayOf(
        "tar.gz", "tar.bz2", "tar.xz", "tar.zst", "tar.lzma"
    )

    /**
     * 核心映射表：扩展名(小写) → 分类目录
     * 集中定义，方便日后增删条目
     */
    private val EXT_MAP: HashMap<String, String> = HashMap()

    /** 辅助注册：把一串空格分隔的扩展名批量注册到某个分类 */
    private fun register(exts: String, category: String) {
        exts.trim().split(Regex("\\s+")).forEach { EXT_MAP[it.lowercase()] = category }
    }

    init {
        // ==================== 图片 ====================
        // 常见格式
        register(
            "jpg jpeg jpe jfif jif png apng gif webp bmp dib heic heif avif jxl " +
                "tiff tif svg svgz ico icns cur mng wbmp", CAT_IMAGE
        )
        // 专业 / 高清格式
        register(
            "jp2 j2k jpf jpx jpm mj2 exr hdr rgbe pic tga icb pcx wdp hdp jxr qoi " +
                "pict pct pbm pgm ppm pnm pfm", CAT_IMAGE
        )
        // 设计源文件
        register("psd psb ai eps xcf cdr", CAT_IMAGE)
        // 相机 RAW
        register(
            "dng raw crw cr2 cr3 nef nrw arw srf sr2 srw orf rw2 raf pef ptx " +
                "erf x3f mrw kdc k25 dcr 3fr fff iiq rwl mef mos", CAT_IMAGE
        )

        // ==================== 视频 ====================
        // 常见格式
        register(
            "mp4 m4v mov qt avi wmv mkv webm flv f4v f4p 3gp 3g2 3gpp 3gp2 " +
                "mpg mpeg mpe ogv ogm asf", CAT_VIDEO
        )
        // 冷门格式
        register(
            "m1v m2v mpv2 mp4v vob rm rmvb mts m2ts m2t ts tp trp mxf divx dv " +
                "amv nsv wtv dvr-ms bik smk ivf y4m yuv mjpg mjpeg", CAT_VIDEO
        )

        // ==================== 音频 ====================
        // 常见格式
        register(
            "mp3 mp2 mp1 wav wave flac aac m4a m4b m4r ogg oga opus wma amr " +
                "aiff aif aifc au snd mid midi", CAT_AUDIO
        )
        // 无损 / 冷门格式
        register(
            "ape wv tta ac3 eac3 ec3 dts caf mka mpc mp+ ra ram voc 8svx " +
                "dsf dff spx gsm aax aa cda rmi kar awb", CAT_AUDIO
        )
        // 芯片音乐 / Tracker
        register(
            "mod mo3 it xm s3m mtm stm far 669 ult sid nsf nsfe spc vgm gym " +
                "ay hes gbs kss sap", CAT_AUDIO
        )

        // ==================== 文档 ====================
        // 办公
        register(
            "pdf doc docx dot dotx docm dotm rtf xls xlsx xlsm xlt xltx xltm " +
                "xlsb xlam csv tsv ppt pptx pot potx potm pps ppsx ppsm pptm " +
                "odp ods odt odg ott ots otp wps et dps wpd abw zabw", CAT_DOC
        )
        // Apple 办公
        register("pages numbers key", CAT_DOC)
        // 电子书 / 漫画
        register("epub mobi azw azw3 azw4 prc lit fb2 ibooks cbr cbz cb7 cbt cba djvu djv pdg", CAT_DOC)
        // 文本 / 标记
        register("txt text log md markdown rst tex bib nfo xps oxps", CAT_DOC)
        // 代码 / 配置 / 数据交换（v1.11.3 补齐）
        register(
            "json jsonl json5 xml xhtml html htm css scss sass less yaml yml toml ini " +
                "conf cfg properties env gradle kts diff patch puml mermaid",
            CAT_DOC
        )
        register(
            "java kt kts scala groovy py pyw js mjs cjs ts tsx jsx vue svelte dart " +
                "swift m mm h cpp cxx cc hpp hh cs go rs rb rake php pl pm lua r jl " +
                "sql prc trigger bat cmd ps1 ps2 sh bash zsh fish awk sed makefile mk " +
                "cmake dockerfile vuec class asm s",
            CAT_DOC
        )
        // 中文文献（冷门）
        register("caj nh kdh", CAT_DOC)

        // ==================== 压缩包 ====================
        // 常见
        register(
            "zip zipx rar 7z tar gz gzip bz2 bzip2 xz zst tgz tbz tbz2 txz tzst tlz",
            CAT_ARCHIVE
        )
        // 冷门
        register(
            "lz lzma lz4 br lzh lha arj ace arc pak zoo sit sitx sea dgc cab wim " +
                "cpio squashfs sfs uue uu xar crx", CAT_ARCHIVE
        )
        // 磁盘镜像
        register("iso img vhd vhdx", CAT_ARCHIVE)

        // ==================== 应用 / 安装包 ====================
        // Android
        register("apk xapk apks apkm aab ap_", CAT_APP)
        // Windows
        register("exe msi msp msix msixbundle appx appxbundle", CAT_APP)
        // Linux / macOS
        register("deb rpm appimage snap pkg dmg", CAT_APP)
        // Java
        register("jar jad war ear", CAT_APP)
        // 冷门平台
        register("ipa sis sisx xpi", CAT_APP)

        // ==================== 字体 ====================
        register("ttf otf ttc otc woff woff2 eot fon pfb pfm pfa bdf pcf sfd ufo dfont", CAT_FONT)

        // 其余一切扩展名、无扩展名文件（torrent / part / crdownload 等下载临时文件）
        // 均落入「其他」，无需注册
    }

    /** 内置扩展名映射的只读视图（设置页提示用，v1.11.1） */
    val CAT_OF: Map<String, String> get() = EXT_MAP

    /** 压缩类 MIME 集合（用于 MIME 兜底判断） */
    private val ARCHIVE_MIMES = setOf(
        "application/zip", "application/x-zip", "application/x-zip-compressed",
        "application/rar", "application/x-rar", "application/x-rar-compressed",
        "application/x-7z-compressed", "application/x-compressed",
        "application/gzip", "application/x-gzip",
        "application/x-tar", "application/x-bzip2", "application/x-xz",
        "application/x-lzma", "application/x-zstandard"
    )

    /**
     * 对外主入口：判断文件应归入的分类目录名
     *
     * @param fileName 原始文件名（如 "照片.JPG"、"备份.tar.gz"、"download.part"）
     * @param uri      分享过来的内容 Uri（可为 null，如本地测试）
     * @param resolver ContentResolver，用于 MIME 兜底（可为 null）
     * @return 分类目录名，如 "图片" / "压缩包" / "其他"
     */
    /**
     * 归类入口。
     *
     * @param rules 用户自定义规则（扩展名 → 分类），优先级最高；
     *              调用方传 AppSettings.customRules(ctx)
     */
    fun categorize(
        fileName: String, uri: Uri? = null, resolver: ContentResolver? = null,
        rules: Map<String, String> = emptyMap()
    ): String {
        // ---------- 0. 用户自定义规则（显式意图，最高优先级） ----------
        val ruleExt = fileName.substringAfterLast('.', "").lowercase()
        if (ruleExt.isNotBlank()) rules[ruleExt]?.let { return it }
        // ---------- 1. 复合扩展名特判（不区分大小写） ----------
        val lower = fileName.lowercase()
        for (compound in COMPOUND_ARCHIVE_EXTS) {
            if (lower.endsWith(compound)) return CAT_ARCHIVE
        }

        // ---------- 2. 普通扩展名查表 ----------
        // substringAfterLast('.', "")：取最后一个点之后的部分；没有点则返回 ""（无扩展名）
        val ext = fileName.substringAfterLast('.', "").lowercase()
        if (ext.isNotEmpty()) {
            EXT_MAP[ext]?.let { return it }
        }

        // ---------- 3. MIME 类型兜底 ----------
        if (uri != null && resolver != null) {
            val mime = try {
                resolver.getType(uri) // 读取系统对该 Uri 的 MIME 判定
            } catch (_: Exception) {
                null
            }
            if (!mime.isNullOrBlank()) {
                return categorizeByMime(mime)
            }
        }

        // ---------- 4. 无法识别 / 无扩展名 → 其他 ----------
        return CAT_OTHER
    }

    /** 按 MIME 类型归类（兜底策略） */
    private fun categorizeByMime(mime: String): String = when {
        mime.startsWith("image/") -> CAT_IMAGE                      // image/png、image/jpeg ...
        mime.startsWith("video/") -> CAT_VIDEO                      // video/mp4 ...
        mime.startsWith("audio/") -> CAT_AUDIO                      // audio/mpeg ...
        mime == "application/pdf" -> CAT_DOC                        // PDF 文档
        mime == "application/vnd.android.package-archive" -> CAT_APP // APK 安装包
        mime in ARCHIVE_MIMES -> CAT_ARCHIVE                        // zip / rar / 7z ...
        else -> CAT_OTHER                                           // 其余 → 其他
    }
}
