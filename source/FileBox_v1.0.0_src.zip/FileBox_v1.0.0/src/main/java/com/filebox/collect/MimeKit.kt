package com.filebox.collect

import android.webkit.MimeTypeMap
import java.io.File
import java.util.Locale

/**
 * MIME 解析（修复「部分文件打不开」）
 *
 * 系统MimeTypeMap 对大量常见扩展名（md/log/json/csv/mkv/flac/heic…）
 * 返回 null，导致 ACTION_VIEW 落到 octet-stream 无人响应。
 *
 * 解析顺序：
 *  1. 系统 MimeTypeMap（设备原生结果最准，如 heic→image/heic）
 *  2. 内置映射表（~120 个常用扩展名，覆盖文本/文档/媒体/压缩/字体/字幕）
 *  3. [forFile] 专属：读文件头 8KB 嗅探——无 \0 且可打印 → text/plain
 *  4. 兜底 application/octet-stream
 *
 * 配合 OpenWithKit（选择打开方式的通配兜底），任何文件都能被强制打开。
 */
object MimeKit {

    /** 内置扩展名 → MIME（系统查不到时兜底） */
    private val MAP = mapOf(
        // ---- 纯文本 / 代码 ----
        "txt" to "text/plain", "log" to "text/plain", "md" to "text/markdown",
        "markdown" to "text/markdown", "csv" to "text/csv", "tsv" to "text/tab-separated-values",
        "json" to "application/json", "xml" to "text/xml", "html" to "text/html",
        "htm" to "text/html", "ini" to "text/plain", "cfg" to "text/plain",
        "conf" to "text/plain", "properties" to "text/plain", "yml" to "text/yaml",
        "yaml" to "text/yaml", "toml" to "text/plain", "rtf" to "application/rtf",
        "js" to "text/javascript", "mjs" to "text/javascript", "ts" to "text/plain",
        "css" to "text/css", "java" to "text/x-java-source", "kt" to "text/plain",
        "py" to "text/x-python", "rb" to "text/plain", "go" to "text/plain",
        "rs" to "text/plain", "c" to "text/plain", "h" to "text/plain",
        "cpp" to "text/plain", "hpp" to "text/plain", "cs" to "text/plain",
        "php" to "text/plain", "swift" to "text/plain", "sql" to "text/plain",
        "sh" to "text/x-sh", "bash" to "text/x-sh", "bat" to "text/plain",
        "lua" to "text/plain", "pl" to "text/plain", "vim" to "text/plain",
        "lrc" to "text/plain",
        // ---- 文档 ----
        "pdf" to "application/pdf",
        "doc" to "application/msword",
        "docx" to "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        "ppt" to "application/vnd.ms-powerpoint",
        "pptx" to "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        "xls" to "application/vnd.ms-excel",
        "xlsx" to "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "odt" to "application/vnd.oasis.opendocument.text",
        "ods" to "application/vnd.oasis.opendocument.spreadsheet",
        "odp" to "application/vnd.oasis.opendocument.presentation",
        "epub" to "application/epub+zip",
        "mobi" to "application/x-mobipocket-ebook",
        "wps" to "application/vnd.ms-works",
        "et" to "application/vnd.ms-excel",
        "dps" to "application/vnd.ms-powerpoint",
        // ---- 图片 ----
        "jpg" to "image/jpeg", "jpeg" to "image/jpeg", "png" to "image/png",
        "gif" to "image/gif", "webp" to "image/webp", "bmp" to "image/bmp",
        "heic" to "image/heic", "heif" to "image/heif", "avif" to "image/avif",
        "svg" to "image/svg+xml", "ico" to "image/x-icon",
        "tif" to "image/tiff", "tiff" to "image/tiff", "dng" to "image/x-adobe-dng",
        "raw" to "image/x-raw", "psd" to "image/vnd.adobe.photoshop",
        // ---- 音频 ----
        "mp3" to "audio/mpeg", "wav" to "audio/x-wav", "flac" to "audio/flac",
        "aac" to "audio/aac", "ogg" to "audio/ogg", "oga" to "audio/ogg",
        "opus" to "audio/opus", "m4a" to "audio/mp4", "m4b" to "audio/mp4",
        "wma" to "audio/x-ms-wma", "mid" to "audio/midi", "midi" to "audio/midi",
        "amr" to "audio/amr", "ape" to "audio/x-ape", "aiff" to "audio/x-aiff",
        // ---- 视频 ----
        "mp4" to "video/mp4", "m4v" to "video/mp4", "mkv" to "video/x-matroska",
        "avi" to "video/x-msvideo", "mov" to "video/quicktime",
        "wmv" to "video/x-ms-wmv", "flv" to "video/x-flv", "webm" to "video/webm",
        "ts" to "video/mp2t", "m2ts" to "video/mp2t", "mts" to "video/mp2t",
        "3gp" to "video/3gpp", "3g2" to "video/3gpp2",
        "mpg" to "video/mpeg", "mpeg" to "video/mpeg", "rm" to "video/x-pn-realvideo",
        "rmvb" to "video/x-pn-realvideo",
        // ---- 压缩 / 镜像 ----
        "zip" to "application/zip", "rar" to "application/x-rar-compressed",
        "7z" to "application/x-7z-compressed", "tar" to "application/x-tar",
        "gz" to "application/gzip", "bz2" to "application/x-bzip2",
        "xz" to "application/x-xz", "zst" to "application/zstd",
        "iso" to "application/x-iso9660-image", "cab" to "application/vnd.ms-cab-compressed",
        "jar" to "application/java-archive",
        // ---- 应用 / 字体 ----
        "apk" to "application/vnd.android.package-archive",
        "xapk" to "application/vnd.android.package-archive",
        "apks" to "application/vnd.android.package-archive",
        "ttf" to "application/x-font-ttf", "otf" to "application/x-font-opentype",
        "ttc" to "application/x-font-ttf", "woff" to "font/woff",
        "woff2" to "font/woff2",
        // ---- 其他 ----
        "vcf" to "text/vcard", "ics" to "text/calendar",
        "eml" to "message/rfc822",
        "srt" to "application/x-subrip", "ass" to "text/x-ssa", "ssa" to "text/x-ssa",
        "swf" to "application/x-shockwave-flash"
    )

    const val OCTET = "application/octet-stream"

    /** 扩展名（小写，无点） */
    fun extOf(name: String): String =
        name.substringAfterLast('.', "").lowercase(Locale.US)

    /** 按名称解析（系统 → 内置表 → octet-stream，不读文件） */
    fun forName(name: String): String {
        val ext = extOf(name)
        if (ext.isNotBlank()) {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { return it }
            MAP[ext]?.let { return it }
        }
        return OCTET
    }

    /** 按文件解析：映射查不到时嗅探文件头，纯文本 → text/plain */
    fun forFile(f: File): String {
        val ext = extOf(f.name)
        if (ext.isNotBlank()) {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)?.let { return it }
            MAP[ext]?.let { return it }
        }
        return if (isTextFile(f)) "text/plain" else OCTET
    }

    /**
     * 文本嗅探：读前 8KB，无 \0 且无非常规控制符 → 视为纯文本。
     * （覆盖无扩展名/冷门扩展名的日志、代码、配置文件）
     */
    private fun isTextFile(f: File): Boolean {
        if (!f.isFile || f.length() == 0L) return false
        return try {
            val buf = ByteArray(8192)
            f.inputStream().use { ins ->
                val n = ins.read(buf)
                if (n <= 0) return false
                for (i in 0 until n) {
                    val b = buf[i].toInt() and 0xFF
                    if (b == 0) return false
                    if (b < 0x20 && b != 0x09 && b != 0x0A && b != 0x0D && b != 0x0C) return false
                }
            }
            true
        } catch (_: Exception) {
            false
        }
    }
}
