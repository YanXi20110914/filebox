package com.filebox.collect

import android.app.Activity
import android.os.Build
import android.view.View
import android.view.WindowInsets

/**
 * Edge-to-edge 适配（Android 15 / targetSdk 35）
 *
 * 35 起系统强制透明系统栏 + 内容绘制到全窗口：
 *  · [edge] —— 关闭 decor 内容自适应（30+）或老版本等效 layout flag
 *  · [padRoot] —— 给根视图加 insets 内边距（状态栏 / 导航栏 / 输入法），
 *    背景（bg_page）仍然铺满全屏，视觉上系统栏与页面同色无缝
 */
object InsetsKit {

    fun edge(a: Activity) {
        if (Build.VERSION.SDK_INT >= 30) {
            a.window.setDecorFitsSystemWindows(false)
        } else {
            @Suppress("DEPRECATION")
            a.window.decorView.systemUiVisibility =
                a.window.decorView.systemUiVisibility or
                        View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                        View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                        View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
    }

    /**
     * 根视图插边：top = 状态栏，bottom = max(导航栏, 输入法)
     * 须在 setContentView 之后调用（传入根 View）。
     */
    fun padRoot(root: View) {
        root.setOnApplyWindowInsetsListener { v, insets ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val sys = insets.getInsets(WindowInsets.Type.systemBars())
                val ime = insets.getInsets(WindowInsets.Type.ime())
                top = sys.top
                bottom = maxOf(sys.bottom, ime.bottom)
            } else {
                @Suppress("DEPRECATION")
                top = insets.systemWindowInsetTop
                @Suppress("DEPRECATION")
                bottom = maxOf(insets.systemWindowInsetBottom, insets.systemWindowInsetBottom)
            }
            v.setPadding(v.paddingLeft, top, v.paddingRight, bottom)
            insets
        }
    }
}
