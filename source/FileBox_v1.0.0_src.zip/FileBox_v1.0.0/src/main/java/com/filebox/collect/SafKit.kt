package com.filebox.collect

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract

/**
 * SAF 存储引擎（系统授权目录）
 *
 * 用户在设置里通过 ACTION_OPEN_DOCUMENT_TREE 授权一个目录后，
 * 无需「所有文件访问」权限即可读写该目录树。
 * 文档操作全部走 DocumentsContract / ContentResolver。
 */
object SafKit {

    const val MIME_DIR = DocumentsContract.Document.MIME_TYPE_DIR

    /** 子项（一次 children 查询的产物） */
    data class Child(
        val docId: String,
        val name: String,
        val isDir: Boolean,
        val size: Long,
        val modified: Long
    )

    /** 已授权的树 uri（未配置返回 null） */
    fun tree(ctx: Context): Uri? =
        AppSettings.safTree(ctx)?.let { Uri.parse(it) }

    /** 树根 document id */
    fun rootDocId(tree: Uri): String =
        DocumentsContract.getTreeDocumentId(tree)

    /** docId → 可读写的 document uri */
    fun docUri(tree: Uri, docId: String): Uri =
        DocumentsContract.buildDocumentUriUsingTree(tree, docId)

    /** 列出某目录的全部子项 */
    fun children(ctx: Context, dirDocId: String): List<Child> {
        val tree = tree(ctx) ?: return emptyList()
        val out = ArrayList<Child>()
        try {
            val childrenUri =
                DocumentsContract.buildChildDocumentsUriUsingTree(tree, dirDocId)
            ctx.contentResolver.query(
                childrenUri,
                arrayOf(
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_MIME_TYPE,
                    DocumentsContract.Document.COLUMN_SIZE,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
                ),
                null, null, null
            )?.use { c ->
                while (c.moveToNext()) {
                    val mime = c.getString(2)
                    out.add(
                        Child(
                            c.getString(0), c.getString(1),
                            mime == MIME_DIR, c.getLong(3), c.getLong(4)
                        )
                    )
                }
            }
        } catch (_: Exception) {
        }
        return out.sortedBy { it.name.lowercase() }
    }

    /** 在某目录下按名查找子项 */
    fun findChild(ctx: Context, dirDocId: String, name: String): Child? =
        children(ctx, dirDocId).firstOrNull { it.name == name }

    /** 在某目录下创建文件夹，返回其 docId（失败 null；已存在则返回已有） */
    fun ensureDir(ctx: Context, dirDocId: String, name: String): String? {
        findChild(ctx, dirDocId, name)?.let { if (it.isDir) return it.docId }
        return try {
            val tree = tree(ctx) ?: return null
            val uri = DocumentsContract.createDocument(
                ctx.contentResolver, docUri(tree, dirDocId), MIME_DIR, name
            ) ?: return null
            DocumentsContract.getDocumentId(uri)
        } catch (_: Exception) {
            null
        }
    }

    /** 在某目录下创建文件，返回其 document uri（失败 null） */
    fun createFile(ctx: Context, dirDocId: String, mime: String, name: String): Uri? {
        val tree = tree(ctx) ?: return null
        return try {
            DocumentsContract.createDocument(
                ctx.contentResolver, docUri(tree, dirDocId), mime, name
            )
        } catch (_: Exception) {
            null
        }
    }

    /** 删除（目录递归由系统处理） */
    fun delete(ctx: Context, docUri: Uri): Boolean = try {
        DocumentsContract.deleteDocument(ctx.contentResolver, docUri)
    } catch (_: Exception) {
        false
    }

    /** 重命名，返回新 uri（失败 null） */
    fun rename(ctx: Context, docUri: Uri, newName: String): Uri? = try {
        DocumentsContract.renameDocument(ctx.contentResolver, docUri, newName)
    } catch (_: Exception) {
        null
    }

    /** docId 的父 docId（根则返回自身） */
    fun parentDocId(docId: String): String {
        val idx = docId.lastIndexOf('/')
        return if (idx <= 0) docId else docId.substring(0, idx)
    }

    /** 展示用路径：externalstorage 的 primary:FileBox/图片 → FileBox/图片 */
    fun displayPath(tree: Uri, docId: String): String {
        val treeRoot = rootDocId(tree)
        return if (docId == treeRoot) docId.substringAfter(':')
        else treeRoot.substringAfter(':') + "/" + docId.removePrefix("$treeRoot/")
    }
}
