package com.filebox.collect

import android.content.Context

/**
 * 应用设置（SharedPreferences 轻量封装，改动即时生效）
 *
 * 设置项：
 *  1. 重名处理 dupMode：
 *     smart —— 智能链式命名（默认，见 SmartNamer：年份→月日→月日时分→秒数/序号）
 *     skip  —— 跳过重复（同名文件不保存）
 *  2. 保存前编辑文件名 editBeforeSave（默认开）
 *  3. 根文件夹名 rootName：默认「我的文件」，自动过滤非法字符
 *  4. 平铺模式 flat：所有文件放同一文件夹（默认关）
 *  5. 保存后自动退出 autoExit（默认开）
 *  6. 外观 themeMode：system 跟随系统 / light 浅色 / dark 深色（默认跟随系统）
 *  7. 来源记忆 sourceMemoryEnabled（默认开）+ silentSources 静默来源包名集合：
 *     在保存面板勾选「记住」后，来自该 App 的分享跳过确认直接保存
 */
object AppSettings {

    // ---- 字体大小（v1.9.7：全局 sp 缩放，四档） ----
    private const val KEY_FONT = "font_scale_idx"
    val FONT_FACTORS = floatArrayOf(0.9f, 1.0f, 1.15f, 1.3f)

    fun fontScaleIdx(ctx: android.content.Context): Int =
        prefs(ctx).getInt(KEY_FONT, 1)

    fun setFontScaleIdx(ctx: android.content.Context, idx: Int) {
        prefs(ctx).edit().putInt(KEY_FONT, idx.coerceIn(0, 3)).commit()
    }

    fun fontScaleFactor(ctx: android.content.Context): Float =
        FONT_FACTORS[fontScaleIdx(ctx).coerceIn(0, 3)]

    // ---- 首启引导 / 开场动画（v1.10.1） ----
    private const val KEY_FIRST = "onboarding_done"
    private const val KEY_INTRO = "intro_anim_on"

    fun onboardingDone(ctx: android.content.Context): Boolean =
        prefs(ctx).getBoolean(KEY_FIRST, false)

    fun setOnboardingDone(ctx: android.content.Context) {
        prefs(ctx).edit().putBoolean(KEY_FIRST, true).commit()
    }

    /** 开场动画开关（默认开；关闭则页面直接呈现） */
    fun introAnimOn(ctx: android.content.Context): Boolean =
        prefs(ctx).getBoolean(KEY_INTRO, true)

    fun setIntroAnimOn(ctx: android.content.Context, on: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_INTRO, on).commit()
    }

    // ---- 细分文件夹（v1.11.2）：分类目录下按月份再分一层 ----
    private const val KEY_SUBMONTH = "sub_month"

    fun subMonth(ctx: android.content.Context): Boolean =
        prefs(ctx).getBoolean(KEY_SUBMONTH, false)

    fun setSubMonth(ctx: android.content.Context, on: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_SUBMONTH, on).commit()
    }

    const val DUP_SMART = "smart"
    const val DUP_SKIP = "skip"

    const val THEME_SYSTEM = "system"
    const val THEME_LIGHT = "light"
    const val THEME_DARK = "dark"

    private const val PREFS = "filebox_settings"
    private const val KEY_DUP = "dup_mode"
    private const val KEY_ROOT = "root_name_raw"
    private const val KEY_FLAT = "flat_mode"
    private const val KEY_AUTO = "auto_exit"
    private const val KEY_EDIT = "edit_before_save"
    private const val KEY_THEME = "theme_mode"
    private const val KEY_SOURCE = "source_memory"
    private const val KEY_SILENT = "silent_sources"
    private const val KEY_SORT = "files_sort"
    private const val KEY_SAF = "saf_engine"
    private const val KEY_SAF_TREE = "saf_tree"
    private const val KEY_VIEW = "files_view"
    private const val KEY_BRAND = "brand_idx"
    private const val KEY_SKIN = "skin_idx"
    private const val KEY_RULES = "cat_rules"
    private const val KEY_CLIP = "clip_hash"
    private const val KEY_NOTIF_ASKED = "notif_asked"

    private fun prefs(ctx: Context) =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    // ---- 重名处理 ----
    fun dupMode(ctx: Context): String =
        prefs(ctx).getString(KEY_DUP, DUP_SMART) ?: DUP_SMART

    fun setDupMode(ctx: Context, mode: String) {
        prefs(ctx).edit().putString(KEY_DUP, mode).apply()
    }

    fun skipDuplicates(ctx: Context): Boolean = dupMode(ctx) == DUP_SKIP

    // ---- 保存前编辑 ----
    fun editBeforeSave(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_EDIT, true)

    fun setEditBeforeSave(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_EDIT, v).apply()
    }

    // ---- 根文件夹名 ----
    fun rawRootName(ctx: Context): String =
        prefs(ctx).getString(KEY_ROOT, "") ?: ""

    fun setRawRootName(ctx: Context, name: String?) {
        prefs(ctx).edit().putString(KEY_ROOT, name ?: "").apply()
    }

    fun rootName(ctx: Context): String {
        val raw = rawRootName(ctx).trim()
        val cleaned = raw.replace(Regex("[\\\\/:*?\"<>|]"), "").trim('.').trim()
        return cleaned.ifBlank { "我的文件" }
    }

    // ---- 平铺模式 ----
    fun flat(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_FLAT, false)

    fun setFlat(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_FLAT, v).apply()
    }

    // ---- 自动退出 ----
    fun autoExit(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_AUTO, true)

    fun setAutoExit(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_AUTO, v).apply()
    }

    // ---- 外观主题 ----
    fun themeMode(ctx: Context): String =
        prefs(ctx).getString(KEY_THEME, THEME_SYSTEM) ?: THEME_SYSTEM

    fun setThemeMode(ctx: Context, mode: String) {
        prefs(ctx).edit().putString(KEY_THEME, mode).apply()
    }

    // ---- 来源记忆 ----
    fun sourceMemoryEnabled(ctx: Context): Boolean =
        prefs(ctx).getBoolean(KEY_SOURCE, true)

    fun setSourceMemoryEnabled(ctx: Context, v: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_SOURCE, v).apply()
    }

    /** 已记住的静默来源（包名集合） */
    fun silentSources(ctx: Context): Set<String> =
        prefs(ctx).getStringSet(KEY_SILENT, emptySet()) ?: emptySet()

    /** 该来源是否静默保存（总开关关闭时一律否） */
    fun isSilentSource(ctx: Context, pkg: String): Boolean =
        sourceMemoryEnabled(ctx) && silentSources(ctx).contains(pkg)

    fun setSilentSource(ctx: Context, pkg: String) {
        val set = HashSet(silentSources(ctx))
        set.add(pkg)
        prefs(ctx).edit().putStringSet(KEY_SILENT, set).apply()
    }

    fun removeSilentSource(ctx: Context, pkg: String) {
        val set = HashSet(silentSources(ctx))
        set.remove(pkg)
        prefs(ctx).edit().putStringSet(KEY_SILENT, set).apply()
    }

    // ---- 文件管理器排序 ----

    /** 排序模式：0 名称 / 1 修改时间 / 2 大小 / 3 类型（默认名称） */
    fun filesSort(ctx: Context): Int =
        prefs(ctx).getInt(KEY_SORT, 0)

    fun setFilesSort(ctx: Context, mode: Int) {
        prefs(ctx).edit().putInt(KEY_SORT, mode).apply()
    }

    // ---- v1.9 新增 ----

    /** 存储引擎：saf = 系统授权目录（默认 auto：根目录/媒体库） */
    fun useSafEngine(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_SAF, false)

    fun setSafEngine(ctx: Context, on: Boolean) {
        prefs(ctx).edit().putBoolean(KEY_SAF, on).apply()
    }

    /** SAF 授权树 uri（未配置 null） */
    fun safTree(ctx: Context): String? =
        prefs(ctx).getString(KEY_SAF_TREE, null)?.ifBlank { null }

    fun setSafTree(ctx: Context, uri: String?) {
        prefs(ctx).edit().putString(KEY_SAF_TREE, uri).apply()
    }

    /** 文件页视图：0 列表（默认）/ 1 网格 */
    fun filesGrid(ctx: Context): Boolean = prefs(ctx).getInt(KEY_VIEW, 0) == 1

    fun setFilesGrid(ctx: Context, grid: Boolean) {
        prefs(ctx).edit().putInt(KEY_VIEW, if (grid) 1 else 0).apply()
    }

    /** 强调色序号：0 默认蓝（见 BrandKit.PALETTE） */
    fun brandIdx(ctx: Context): Int = prefs(ctx).getInt(KEY_BRAND, 0)

    fun setBrandIdx(ctx: Context, idx: Int) {
        prefs(ctx).edit().putInt(KEY_BRAND, idx).apply()
    }

    /** 界面皮肤序号：0 经典白（见 SkinKit.IDS / NAMES） */
    fun skinIdx(ctx: Context): Int = prefs(ctx).getInt(KEY_SKIN, 0)

    fun setSkinIdx(ctx: Context, idx: Int) {
        prefs(ctx).edit().putInt(KEY_SKIN, idx).apply()
    }

    /** 自定义分类规则：扩展名 → 分类（JSON） */
    fun customRules(ctx: Context): Map<String, String> {
        val json = prefs(ctx).getString(KEY_RULES, null) ?: return emptyMap()
        return try {
            val obj = org.json.JSONObject(json)
            val out = HashMap<String, String>()
            obj.keys().forEach { k -> out[k] = obj.optString(k) }
            out
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun setCustomRules(ctx: Context, rules: Map<String, String>) {
        prefs(ctx).edit()
            .putString(KEY_RULES, org.json.JSONObject(rules).toString())
            .apply()
    }

    /** 上次处理过的剪贴板内容指纹（不再重复提示） */
    fun clipHash(ctx: Context): String? =
        prefs(ctx).getString(KEY_CLIP, null)

    fun setClipHash(ctx: Context, hash: String) {
        prefs(ctx).edit().putString(KEY_CLIP, hash).apply()
    }

    /** 33+ 通知权限是否已请求过（一次性） */
    fun notifAsked(ctx: Context): Boolean = prefs(ctx).getBoolean(KEY_NOTIF_ASKED, false)

    fun setNotifAsked(ctx: Context) {
        prefs(ctx).edit().putBoolean(KEY_NOTIF_ASKED, true).apply()
    }
}
