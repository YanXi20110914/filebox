package com.filebox.collect

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/**
 * 收纳历史（JSON 文件持久化，filesDir/history.json，最多保留 1000 条）
 *
 * 记录每次成功收纳的文件：名称、分类、保存位置、来源 App、时间、大小；
 * 供「收纳历史」页浏览 / 打开 / 重新分享 / 删除，以及主页统计面板汇总。
 */
object HistoryStore {

    /** 一条收纳记录 */
    data class Rec(
        val id: Long,           // 唯一 id（时间戳衍生）
        val fileName: String,   // 保存后的文件名
        val category: String,   // 归入分类
        val pathDisplay: String,// 展示用相对路径（如 我的文件/图片/）
        val absPath: String,    // 绝对路径（根目录引擎）
        val contentUri: String?,// MediaStore 引擎的 content uri
        val source: String,     // 来源 App 名称
        val time: Long,         // 收纳时间
        val size: Long,         // 文件大小（字节）
        val isText: Boolean     // 是否为文本收集
    )

    /** 统计汇总 */
    data class Stats(
        val total: Int,
        val week: Int,
        val bytes: Long,
        val byCat: Map<String, Int>
    )

    private const val MAX = 1000

    private fun file(ctx: Context): File = File(ctx.filesDir, "history.json")

    // 内存缓存（v1.0.1 优化：all() 高频调用免重复 JSON parse；写点失效换新实例）
    @Volatile
    private var cache: MutableList<Rec>? = null

    private fun invalidate() {
        cache = null
    }

    fun add(ctx: Context, recs: List<Rec>) {
        if (recs.isEmpty()) return
        val list = readAll(ctx)
        list.addAll(0, recs)                 // 新记录在最前
        while (list.size > MAX) list.removeAt(list.size - 1)
        writeAll(ctx, list)
    }

    /** 唯一落盘点（v1.0.1 优化点）：写盘后刷新内存缓存 */

    @Synchronized
    fun all(ctx: Context): MutableList<Rec> =
        cache ?: readAll(ctx).also { cache = it }

    @Synchronized
    fun delete(ctx: Context, id: Long) {
        val list = readAll(ctx)
        list.removeAll { it.id == id }
        writeAll(ctx, list)
    }

    /** 按绝对路径删除记录（文件管理器删除文件/文件夹时同步清理历史） */
    @Synchronized
    fun removeByPathPrefix(ctx: Context, pathPrefix: String) {
        if (pathPrefix.isBlank()) return
        val list = readAll(ctx)
        // 前缀匹配：文件本身或其所在文件夹整棵子树
        list.removeAll { it.contentUri == null && it.absPath.startsWith(pathPrefix) }
        writeAll(ctx, list)
    }

    @Synchronized
    fun clear(ctx: Context) {
        file(ctx).delete()
    }

    /** 汇总统计：总数 / 近7天 / 累计大小 / 分类分布 */
    fun stats(ctx: Context): Stats {
        val list = all(ctx)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -7)
        val weekStart = cal.timeInMillis
        var week = 0
        var bytes = 0L
        val byCat = LinkedHashMap<String, Int>()
        list.forEach { r ->
            if (r.time >= weekStart) week++
            bytes += r.size
            byCat[r.category] = (byCat[r.category] ?: 0) + 1
        }
        return Stats(list.size, week, bytes, byCat)
    }

    // ==================== JSON 读写 ====================

    private fun readAll(ctx: Context): MutableList<Rec> {
        val out = ArrayList<Rec>()
        val f = file(ctx)
        if (!f.exists()) return out
        return try {
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(
                    Rec(
                        id = o.getLong("id"),
                        fileName = o.optString("n"),
                        category = o.optString("c"),
                        pathDisplay = o.optString("d"),
                        absPath = o.optString("p"),
                        contentUri = if (o.has("u")) o.optString("u") else null,
                        source = o.optString("s"),
                        time = o.optLong("t"),
                        size = o.optLong("z"),
                        isText = o.optBoolean("x", false)
                    )
                )
            }
            out
        } catch (_: Exception) {
            out
        }
    }

    private fun writeAll(ctx: Context, list: List<Rec>) {
        try {
            val arr = JSONArray()
            list.forEach { r ->
                arr.put(JSONObject().apply {
                    put("id", r.id)
                    put("n", r.fileName)
                    put("c", r.category)
                    put("d", r.pathDisplay)
                    put("p", r.absPath)
                    if (r.contentUri != null) put("u", r.contentUri)
                    put("s", r.source)
                    put("t", r.time)
                    put("z", r.size)
                    put("x", r.isText)
                })
            }
            file(ctx).writeText(arr.toString())
        } catch (_: Exception) {
        }
    }

    // ==================== 展示工具 ====================

    fun fmtSize(bytes: Long): String = when {
        bytes < 1024 -> "$bytes B"
        bytes < 1024 * 1024 -> "%.1f KB".format(bytes / 1024f)
        bytes < 1024L * 1024 * 1024 -> "%.1f MB".format(bytes / 1024f / 1024f)
        else -> "%.2f GB".format(bytes / 1024f / 1024f / 1024f)
    }

    fun fmtTime(time: Long): String {
        val cal = Calendar.getInstance()
        val nowYear = cal.get(Calendar.YEAR)
        cal.timeInMillis = time
        return if (cal.get(Calendar.YEAR) == nowYear)
            SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(time))
        else
            SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(time))
    }
}
