package com.filebox.collect

import android.content.ContentProvider
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.DocumentsContract
import android.provider.OpenableColumns
import java.io.File
import java.io.FileNotFoundException

/**
 * 轻量文件提供器（自实现，替代 androidx FileProvider）
 *
 * 用途：把收纳的文件以 content Uri 形式提供给系统——
 *  · 历史页「打开」（ACTION_VIEW）
 *  · 历史页「重新分享」（ACTION_SEND）
 *  · 主页「打开收纳文件夹」（目录 + MIME_DIR，尽力直达系统文件管理器）
 *
 * 安全：只允许访问「我的文件」相关目录（存储根目录与系统标准目录下
 * 的同名文件夹），其余路径一律拒绝。
 */
class BoxProvider : ContentProvider() {

    companion object {
        const val AUTHORITY = "com.filebox.collect.files"

        /** 文件/目录 → content Uri（保留路径分隔符，中文会被自动编码） */
        fun uriFor(f: File): Uri =
            Uri.parse("content://" + AUTHORITY + Uri.encode(f.absolutePath, "/"))
    }

    /** 解析并校验 Uri 对应的文件（越权路径返回 null） */
    private fun fileFor(uri: Uri): File? {
        val ctx = context ?: return null
        val decoded = Uri.decode(uri.encodedPath ?: return null) ?: return null
        val f = File(decoded)
        val canon = try { f.canonicalFile } catch (_: Exception) { return null }
        val abs = canon.absolutePath

        // 存储根目录下的「我的文件」（含子目录与本身）
        val root = File(Environment.getExternalStorageDirectory(), AppSettings.rootName(ctx))
        val rootAbs = try { root.canonicalFile.absolutePath } catch (_: Exception) { root.absolutePath }
        if (abs == rootAbs || abs.startsWith(rootAbs + File.separator)) return canon

        // 免权限模式下系统标准目录中的「我的文件」
        for (base in arrayOf("Pictures", "Movies", "Music", "Download")) {
            val d = File(Environment.getExternalStorageDirectory(),
                "$base/" + AppSettings.rootName(ctx))
            val dAbs = try { d.canonicalFile.absolutePath } catch (_: Exception) { d.absolutePath }
            if (abs.startsWith(dAbs + File.separator)) return canon
        }
        return null
    }

    override fun onCreate(): Boolean = true

    override fun openFile(uri: Uri, mode: String): ParcelFileDescriptor? {
        val f = fileFor(uri) ?: throw FileNotFoundException(uri.toString())
        if (f.isDirectory) throw FileNotFoundException(uri.toString())
        return ParcelFileDescriptor.open(f, ParcelFileDescriptor.parseMode(mode))
    }

    override fun query(
        uri: Uri, projection: Array<out String>?, selection: String?,
        selectionArgs: Array<out String>?, sortOrder: String?
    ): Cursor? {
        val f = fileFor(uri) ?: return null
        val cols = projection ?: arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE)
        val cursor = MatrixCursor(cols)
        val row = ArrayList<Any>(cols.size)
        cols.forEach { c ->
            row.add(
                when (c) {
                    OpenableColumns.DISPLAY_NAME -> f.name
                    OpenableColumns.SIZE -> f.length()
                    else -> 0
                }
            )
        }
        cursor.addRow(row)
        return cursor
    }

    override fun getType(uri: Uri): String? {
        val f = fileFor(uri) ?: return null
        if (f.isDirectory) return DocumentsContract.Document.MIME_TYPE_DIR
        // MimeKit：系统映射 + 内置表 + 文本嗅探，冷门扩展名不再落到 octet-stream
        return MimeKit.forFile(f)
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? = null
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = 0
    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<out String>?
    ): Int = 0
}
