package com.filebox.collect

import android.annotation.SuppressLint
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * 文件收纳盒 - 主界面（兼接收页）
 *
 * 保存策略（按系统版本自动选择）：
 *  Android 11+：「所有文件访问」→ 根目录/我的文件/分类/；未开启可走 MediaStore 免权限备选
 *  Android 10：legacy 模式 + WRITE → 根目录
 *  Android 9-：WRITE → 根目录
 *
 * v1.5 新增：
 *  · 文本收集：text/plain 分享（EXTRA_TEXT）存为 .txt
 *  · 收纳历史：每次成功保存记录到 HistoryStore（来源 App、路径、大小）
 *  · 统计面板：主页统计卡片（总数 / 近7天 / 占用）
 *  · 文件夹直达：一键打开「我的文件」（BoxProvider + 系统文件管理器）
 *  · 来源记忆：面板可勾选「记住」，之后该 App 分享静默保存
 *  · 深色模式：ThemeKit 包装 Context，values-night 色板自动切换
 */
class MainActivity : Activity() {

    companion object {
        private const val REQUEST_WRITE = 1001
        private const val REQUEST_POST_NOTIF = 1002
        private const val AUTO_FINISH_MS = 2600L

        // 主页最近生效的主题（设置页修改后 onResume 检测重建）
        private var appliedTheme: String? = null
        private var appliedBrand = -1
        private var appliedSkin = -1
    }

    /** 一条待保存分享：uri 文件 或 纯文本（text != null） */
    private class ShareItem(val uri: Uri?, val defaultName: String, val text: String?)

    /** 单个文件的保存结果 */
    private class SaveInfo(
        val success: Boolean,    // 是否保存成功
        val skipped: Boolean,    // 是否因重名跳过
        val dir: String,         // 展示用相对目录
        val fileName: String,    // 保存后的文件名
        val category: String,    // 归入分类
        val error: String?,      // 失败原因
        val absPath: String,     // 绝对路径（根目录引擎）
        val contentUri: String?, // MediaStore 引擎 content uri
        val size: Long,          // 字节数
        val isText: Boolean      // 是否文本收集
    )

    /** 确认面板中的一行 */
    private class RowState(val item: ShareItem, val edit: EditText, val hint: TextView)

    // ---- 视图 ----
    private lateinit var contentScroll: ScrollView
    private lateinit var workArea: FrameLayout
    private lateinit var sheetOverlay: FrameLayout
    private lateinit var sheetScrim: View
    private lateinit var sheetCard: LinearLayout
    private lateinit var sheetTitle: TextView
    private lateinit var sheetScroll: ScrollView
    private lateinit var sheetList: LinearLayout
    private lateinit var cbRemember: CheckBox
    private lateinit var btnSheetCancel: Button
    private lateinit var btnSheetSave: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvDetail: TextView
    private lateinit var btnAction: Button
    private lateinit var btnFallback: Button
    private lateinit var btnSettings: Button
    private lateinit var btnOpenFolder: Button
    private lateinit var btnHistory: Button
    private lateinit var btnFiles: Button
    private lateinit var statsCard: LinearLayout
    private lateinit var tvStatTotal: TextView
    private lateinit var tvStatWeek: TextView
    private lateinit var tvStatSize: TextView
    private lateinit var tvWorkTitle: TextView
    private lateinit var workList: LinearLayout
    private lateinit var btnWorkDone: Button

    // ---- 状态 ----
    private val mainHandler = Handler(Looper.getMainLooper())
    private var pendingItems: List<ShareItem> = emptyList()   // 暂存的分享（等权限）
    private var sheetRows: List<RowState> = emptyList()       // 面板行
    private var sheetItems: List<ShareItem> = emptyList()     // 面板对应的分享
    private var srcPkg: String? = null                        // 分享来源包名
    private var srcLabel: String? = null                      // 分享来源应用名
    private var clipBar: LinearLayout? = null                 // 剪贴板笔记横条
    private var clipPreview: TextView? = null
    private var pendingClipText: String? = null               // 横条当前对应的文本

    // ==================== 生命周期 ====================

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(ThemeKit.wrap(base))
    }

    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        CrashGuard.install(this)
        try {
            onCreateInner(savedInstanceState)
        } catch (e: Throwable) {
            // 兜底降级：初始化失败也给出可操作页面，绝不明闪退
            CrashGuard.mark(e)
            setContentView(android.widget.TextView(this).apply {
                text = "启动遇到问题，已记录日志。\n\n点按屏幕重试。"
                textSize = 16f
                gravity = android.view.Gravity.CENTER
                setOnClickListener { recreate() }
            })
        }
    }

    private fun onCreateInner(savedInstanceState: Bundle?) {
        SkinKit.apply(this)
        ThemeKit.apply(this)
        setContentView(R.layout.activity_main)
        // 大屏 / 分屏 / 横屏：内容列限宽居中（手机竖屏无感知）
        ThemeKit.capWidth(findViewById(R.id.home_column))
        ThemeKit.capWidth(findViewById(R.id.work_column))
        ThemeKit.capWidth(findViewById(R.id.sheet_card))
        // Android 15 edge-to-edge：根视图插边（背景仍铺满全屏）
        InsetsKit.edge(this)
        InsetsKit.padRoot(findViewById(R.id.main_root))
        bindViews()
        bindActions()
        NotifyKit.channel(this)
        if (!AppSettings.onboardingDone(this)) showOnboarding()
        applyHomeLayout()

        // 33+ 通知权限（一次性请求；拒绝则保存完成通知静默跳过）
        if (Build.VERSION.SDK_INT >= 33 && !AppSettings.notifAsked(this)) {
            AppSettings.setNotifAsked(this)
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(
                    arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),
                    REQUEST_POST_NOTIF
                )
            }
        }

        appliedTheme = AppSettings.themeMode(this)

        if (!handleIntent(intent)) {
            showIdlePage() // 桌面启动
        }
    }

    override fun onResume() {
        super.onResume()
        NotifyKit.cancel(this)
        // 主题被设置页修改 → 重建以应用新外观
        val cur = AppSettings.themeMode(this)
        if (appliedTheme != null && appliedTheme != cur) {
            recreate()
            return
        }
        appliedTheme = cur

        // 强调色/皮肤被设置页修改 → 重建以应用新外观
        val brandNow = AppSettings.brandIdx(this)
        if (appliedBrand >= 0 && appliedBrand != brandNow) {
            appliedBrand = brandNow
            recreate()
            return
        }
        appliedBrand = brandNow
        val skinNow = AppSettings.skinIdx(this)
        if (appliedSkin >= 0 && appliedSkin != skinNow) {
            appliedSkin = skinNow
            recreate()
            return
        }
        appliedSkin = skinNow

        if (pendingItems.isNotEmpty()) {
            // 从系统设置授权返回 → 自动继续保存
            if (useSafEngine()) proceedIfReady()
            else if (useRootEngine() && hasAllFilesAccess()) proceedIfReady()
        } else if (contentScroll.visibility == View.VISIBLE) {
            refreshIdle() // 统计数据可能已变化（历史页删除等）
        }
    }

    /** 处理进入的 Intent；返回 true 表示是分享进入 */
    private fun handleIntent(intent: Intent?): Boolean {
        if (intent == null) return false
        detectSource(intent)
        pendingItems = when (intent.action) {
            Intent.ACTION_SEND -> {
                val stream = getStream(intent)
                if (stream != null) {
                    listOf(ShareItem(stream, queryDisplayName(stream), null))
                } else {
                    // 文本收集：微信/QQ/浏览器 分享文字（text/plain + EXTRA_TEXT）
                    val text = intent.getStringExtra(Intent.EXTRA_TEXT)
                    if (!text.isNullOrBlank()) listOf(ShareItem(null, defaultTextName(), text))
                    else emptyList()
                }
            }
            Intent.ACTION_SEND_MULTIPLE -> {
                val streams = getStreams(intent)
                streams.map { ShareItem(it, queryDisplayName(it), null) }
            }
            else -> return false
        }
        if (pendingItems.isEmpty()) return false
        proceedIfReady()
        return true
    }

    private fun getStream(intent: Intent): Uri? =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(Intent.EXTRA_STREAM)
        }

    private fun getStreams(intent: Intent): List<Uri> =
        if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableArrayListExtra(Intent.EXTRA_STREAM, Uri::class.java).orEmpty()
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM).orEmpty()
        }

    /** 识别分享来源 App（getReferrer 尽力而为，失败则显示未知来源） */
    private fun detectSource(intent: Intent) {
        srcPkg = null
        srcLabel = null
        val r = try {
            if (Build.VERSION.SDK_INT >= 22) referrer else intent.getStringExtra(Intent.EXTRA_REFERRER_NAME)?.let { Uri.parse(it) }
        } catch (_: Exception) {
            null
        }
        val host = r?.host
        if (!host.isNullOrBlank() && host != packageName) {
            srcPkg = host
            srcLabel = try {
                packageManager.getApplicationLabel(
                    packageManager.getApplicationInfo(host, 0)
                ).toString()
            } catch (_: Exception) {
                host
            }
        }
    }

    /** 分享就绪 → 决定：静默保存 / 弹确认面板 / 等权限 */
    private fun proceedIfReady() {
        if (pendingItems.isEmpty()) return

        // SAF 引擎：已授权目录，无权限门槛
        if (useSafEngine()) {
            startSave(pendingItems, null)
            return
        }

        // 根目录引擎的权限门槛
        if (useRootEngine()) {
            if (Build.VERSION.SDK_INT >= 30 && !hasAllFilesAccess()) {
                showNeedAllFilesPage()
                return
            }
            if (Build.VERSION.SDK_INT < 30 && !hasWritePermission()) {
                requestStoragePermission()
                return
            }
        }

        val silent = srcPkg != null && AppSettings.isSilentSource(this, srcPkg!!)
        when {
            silent -> startSave(pendingItems, null)                    // 来源记忆：静默
            AppSettings.editBeforeSave(this) -> showSaveSheet(pendingItems)
            else -> startSave(pendingItems, null)
        }
    }

    // ==================== 权限 ====================

    private fun useSafEngine(): Boolean =
        AppSettings.useSafEngine(this) && SafKit.tree(this) != null

    private fun useRootEngine(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) hasAllFilesAccess() else true

    private fun hasAllFilesAccess(): Boolean =
        Build.VERSION.SDK_INT >= 30 && Environment.isExternalStorageManager()

    private fun useLegacyFileEngine(): Boolean = Build.VERSION.SDK_INT < 30

    private fun hasWritePermission(): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED

    private fun requestStoragePermission() {
        if (useLegacyFileEngine()) {
            requestPermissions(
                arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), REQUEST_WRITE
            )
        } else {
            showNeedAllFilesPage()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_WRITE) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            proceedIfReady()
        } else {
            toast(getString(R.string.toast_perm_denied))
            finish()
        }
    }

    private fun openAllFilesSettings() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
                toast(getString(R.string.toast_perm_denied))
            }
        }
    }

    // ==================== 主页 ====================

    private fun refreshIdle() {
        if (useSafEngine()) {
            showIdlePage() // SAF 引擎：无需存储权限
        } else if (useLegacyFileEngine() && !hasWritePermission()) {
            showIdlePageLegacyNoPerm()
        } else if (!useLegacyFileEngine() && !hasAllFilesAccess()) {
            showIdlePageModernNoPerm()
        } else {
            showIdlePage()
        }
    }

    private fun showIdlePage() {
        contentScroll.visibility = View.VISIBLE
        workArea.visibility = View.GONE
        sheetOverlay.visibility = View.GONE
        tvStatus.setText(R.string.status_idle)
        tvDetail.setText(R.string.detail_idle)
        btnAction.visibility = View.GONE
        btnFallback.visibility = View.GONE
        fillStats()
        showRecentCard()
        showCrashBannerIfAny()
        staggerIdleContent()
    }

    // ==================== 最近收纳卡（v1.9.9） ====================

    /** 统计卡下方展示最近 3 条收纳记录，点击直达历史页 */
    private fun showRecentCard() {
        val stats = findViewById<View>(R.id.stats_card) ?: return
        val parent = stats.parent as? ViewGroup ?: return
        parent.findViewWithTag<View>("recent_card")?.let { parent.removeView(it) }
        val recs = try {
            HistoryStore.all(this).take(3)
        } catch (_: Exception) {
            return
        }
        if (recs.isEmpty()) return

        val dp = { v: Int -> (v * resources.displayMetrics.density + 0.5f).toInt() }
        val card = LinearLayout(this).apply {
            tag = "recent_card"
            orientation = LinearLayout.VERTICAL
            background = SkinKit.card(this@MainActivity)
            elevation = dp(2).toFloat()
            setPadding(dp(14), dp(12), dp(14), dp(8))
        }
        // 标题行：图标 + 最近收纳 · 全部›
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(
            ImageView(this).apply {
                setImageResource(R.drawable.ic_history)
                setColorFilter(SkinKit.iconTint(this@MainActivity))
            },
            LinearLayout.LayoutParams(dp(15), dp(15)).apply { rightMargin = dp(7) }
        )
        head.addView(
            TextView(this).apply {
                text = getString(R.string.recent_title)
                textSize = 14f
                setTextColor(SkinKit.text(this@MainActivity))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        head.addView(
            TextView(this).apply {
                text = getString(R.string.recent_all)
                textSize = 12f
                setTextColor(BrandKit.accent(this@MainActivity))
                background = getDrawable(R.drawable.ripple_text)
                setPadding(dp(8), dp(4), dp(8), dp(4))
                Anim.pressable(this)
                setOnClickListener { startActivity(Intent(this@MainActivity, HistoryActivity::class.java)) }
            }
        )
        card.addView(
            head, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        // 三条记录行：分类图标 + 文件名 + 时间
        recs.forEach { rec ->
            val row = LinearLayout(this).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = getDrawable(R.drawable.ripple_text)
                Anim.pressable(this)
                setOnClickListener { startActivity(Intent(this@MainActivity, HistoryActivity::class.java)) }
            }
            row.addView(
                ImageView(this).apply {
                    setImageResource(CategoryIcons.forCategory(rec.category))
                    setColorFilter(SkinKit.iconTint(this@MainActivity))
                },
                LinearLayout.LayoutParams(dp(18), dp(18)).apply { rightMargin = dp(10) }
            )
            row.addView(
                TextView(this).apply {
                    text = rec.fileName
                    textSize = 13f
                    setTextColor(SkinKit.text(this@MainActivity))
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(
                TextView(this).apply {
                    text = HistoryStore.fmtTime(rec.time)
                    textSize = 11f
                    setTextColor(getColor(R.color.text_secondary))
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginStart = dp(8) }
            )
            card.addView(
                row, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(8) }
            )
        }
        val lp = stats.layoutParams
        parent.addView(card, parent.indexOfChild(stats) + 1, LinearLayout.LayoutParams(lp.width, lp.height).apply {
            if (lp is LinearLayout.LayoutParams) {
                setMargins(dp(20), dp(10), dp(20), 0)
            } else {
                setMargins(dp(20), dp(10), dp(20), 0)
            }
        })
    }

    // ==================== 崩溃自证横幅 ====================

    /** 上次崩溃未读 → 主页顶部横幅（一句话原因 + 一键复制完整堆栈） */
    private fun showCrashBannerIfAny() {
        val head = CrashGuard.unreadHead(this) ?: return
        val home = findViewById<LinearLayout>(R.id.home_column)
        // 防止重复添加
        home.findViewWithTag<View>("crash_banner")?.let { home.removeView(it) }

        val banner = LinearLayout(this).apply {
            tag = "crash_banner"
            orientation = LinearLayout.VERTICAL
            background = SkinKit.card(this@MainActivity)
            elevation = SkinKit.cardElev(this@MainActivity).toFloat()
            setPadding(dp(14), dp(10), dp(14), dp(10))
        }
        val headRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        headRow.addView(
            TextView(this@MainActivity).apply {
                text = getString(R.string.crash_banner_fmt, head)
                textSize = 12f
                setTextColor(getColor(R.color.error))
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        headRow.addView(
            TextView(this@MainActivity).apply {
                text = getString(R.string.crash_copy)
                textSize = 13f
                setTextColor(BrandKit.accent(this@MainActivity))
                background = getDrawable(R.drawable.ripple_text)
                setPadding(dp(10), dp(4), dp(10), dp(4))
                Anim.pressable(this)
                setOnClickListener {
                    val detail = CrashGuard.fullDetail(this@MainActivity) ?: head
                    (getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
                        ?.setPrimaryClip(ClipData.newPlainText("crash", detail))
                    CrashGuard.clear(this@MainActivity)
                    toast(getString(R.string.crash_copied))
                    home.removeView(banner)
                }
            }
        )
        banner.addView(
            headRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        banner.addView(
            TextView(this@MainActivity).apply {
                text = getString(R.string.crash_ignore)
                textSize = 12f
                setTextColor(SkinKit.textSub(this@MainActivity))
                background = getDrawable(R.drawable.ripple_text)
                setPadding(dp(10), dp(6), dp(10), dp(2))
                Anim.pressable(this)
                setOnClickListener {
                    CrashGuard.clear(this@MainActivity)
                    home.removeView(banner)
                }
            }
        )
        home.addView(
            banner, 0, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(dp(20), dp(10), dp(20), 0) }
        )
    }

    private fun showIdlePageModernNoPerm() {
        contentScroll.visibility = View.VISIBLE
        workArea.visibility = View.GONE
        sheetOverlay.visibility = View.GONE
        tvStatus.setText(R.string.status_idle_no_perm)
        tvDetail.setText(R.string.detail_idle_no_perm)
        btnAction.setText(R.string.btn_grant)
        btnAction.visibility = View.VISIBLE
        btnAction.setOnClickListener { openAllFilesSettings() }
        btnFallback.visibility = View.VISIBLE
        btnFallback.setOnClickListener {
            // 未开所有文件权限 → 走 MediaStore 免权限引擎
            startSave(pendingItems, null)
        }
        if (pendingItems.isEmpty()) btnFallback.visibility = View.GONE
        fillStats()
        staggerIdleContent()
    }

    private fun showIdlePageLegacyNoPerm() {
        contentScroll.visibility = View.VISIBLE
        workArea.visibility = View.GONE
        sheetOverlay.visibility = View.GONE
        tvStatus.setText(R.string.status_need_perm)
        tvDetail.setText(R.string.detail_idle_no_perm_old)
        btnAction.setText(R.string.btn_grant)
        btnAction.visibility = View.VISIBLE
        btnAction.setOnClickListener { requestStoragePermission() }
        btnFallback.visibility = View.GONE
        fillStats()
        staggerIdleContent()
    }

    /** 未授权时的暂存引导页 */
    private fun showNeedAllFilesPage() {
        contentScroll.visibility = View.VISIBLE
        workArea.visibility = View.GONE
        tvStatus.setText(R.string.status_need_all_files)
        tvDetail.setText(R.string.detail_need_all_files)
        btnAction.setText(R.string.btn_grant)
        btnAction.visibility = View.VISIBLE
        btnAction.setOnClickListener { openAllFilesSettings() }
        btnFallback.visibility = View.VISIBLE
        btnFallback.setOnClickListener { startSave(pendingItems, null) }
        fillStats()
        staggerIdleContent()
    }

    /** 主页卡片交错入场 */
    private var intro3dViews: List<View> = emptyList()
    private val introRunnable = Runnable { playIntro3d() }

    private fun staggerIdleContent() {
        // 3D 级联开场（v1.0.1 修）：每次打开都播（用户确认不需要只播一次）；
        // post 到下一帧确保 Activity 可见后再启动，避免动画播在启动幕后
        val intro = AppSettings.introAnimOn(this)
        if (!intro || Anim.reducedMotion(this)) {
            resetIntro3d()
            return
        }
        // 防抖：连续 showIdle 只保留最后一次 post
        contentScroll.removeCallbacks(introRunnable)
        contentScroll.postDelayed(introRunnable, 40)
    }

    private fun playIntro3d() {
        run {
            val fast = AppSettings.onboardingDone(this)
            val dur = if (fast) 550L else 850L
            val gap = if (fast) 70L else 130L
            val dp = { v: Int -> (v * resources.displayMetrics.density + 0.5f).toInt() }

        val targets = mutableListOf<View>()
        findViewById<View>(R.id.iv_hero)?.let { if (it.visibility == View.VISIBLE) targets.add(it) }
        (btnOpenFolder.parent as? ViewGroup)?.findViewWithTag<View>("skin_hero")?.let { targets.add(it) }
        findViewById<TextView>(R.id.tv_app_name)?.let { targets.add(it) }
        findViewById<TextView>(R.id.tv_status)?.let { targets.add(it) }
        findViewById<TextView>(R.id.tv_detail)?.let { targets.add(it) }
        findViewById<View>(R.id.stats_card)?.let { targets.add(it) }
        recentTagView()?.let { targets.add(it) }
        findViewById<View>(R.id.row_tools)?.let { targets.add(it) }
        findViewById<View>(R.id.row_tools2)?.let { if (it.visibility == View.VISIBLE) targets.add(it) }

        targets.forEachIndexed { i, v ->
            v.animate().cancel()
            // 透视相机拉远 8 倍：大角度俯瞰不畸变
            v.cameraDistance = 8f * 325f * resources.displayMetrics.density
            v.alpha = 0f
            v.rotationX = 52f
            v.rotationY = -26f
            v.translationX = dp(70).toFloat()
            v.translationY = dp(-46).toFloat()
            v.scaleX = 0.72f
            v.scaleY = 0.72f
            v.animate()
                .rotationX(0f).rotationY(0f)
                .translationX(0f).translationY(0f)
                .scaleX(1f).scaleY(1f).alpha(1f)
                .setStartDelay(i * gap)
                .setDuration(dur)
                .setInterpolator(Anim.ENTER)
                .start()
        }
        intro3dViews = targets
        }
    }

    /** 强制归位 3D 姿态（动画中途离开 / 关闭开关后回页的兜底） */
    private fun resetIntro3d() {
        intro3dViews.forEach { v ->
            v.animate().cancel()
            v.rotationX = 0f
            v.rotationY = 0f
            v.translationX = 0f
            v.translationY = 0f
            v.scaleX = 1f
            v.scaleY = 1f
            v.alpha = 1f
        }
    }

    /** 桌面图标 alias 切换延迟到退后台（v1.11.1）：应用内切皮肤不再被系统踢回桌面 */
    override fun onStop() {
        super.onStop()
        LauncherAlias.apply(this, AppSettings.skinIdx(this))
    }

    /** 最近收纳卡句柄（开场序列用；无则 null） */
    private fun recentTagView(): View? =
        (btnOpenFolder.parent as? ViewGroup)?.findViewWithTag<View>("recent_card")

    // ==================== 主页布局的皮肤差异（v1.10.8） ====================

    /**
     * 部分皮肤重排主页：
     *  · homeWide（经典白/禅意/奶油）：2×2 紧凑按钮 → 四个全宽大按钮竖排，hero 放大
     *  · homeLeft（终端/工作台）：状态区与标题左对齐（信息效率感）
     * 其余皮肤保持默认 2×2 + 居中（XML 初始状态）。
     */
    private fun applyHomeLayout() {
        val spec = SkinKit.uiSpec(this)
        // 布局重排失败不拖垮主页：降级为 XML 默认 2×2
        try {
            applyHomeLayoutInner(spec)
        } catch (e: Exception) {
            CrashGuard.mark(e)
        }
    }

    private fun applyHomeLayoutInner(spec: SkinKit.UiSpec) {
        val dp = { v: Int -> (v * resources.displayMetrics.density + 0.5f).toInt() }
        val col = findViewById<LinearLayout>(R.id.home_column) ?: return
        val row1 = findViewById<LinearLayout>(R.id.row_tools) ?: return
        val row2 = findViewById<LinearLayout>(R.id.row_tools2) ?: return

        // hero 换皮肤配色 Logo（v1.11.6：3D 开场主角，随皮肤换装）
        val heroOld = findViewById<View>(R.id.iv_hero)
        if (heroOld != null && heroOld.visibility != View.GONE) {
            val idx = col.indexOfChild(heroOld)
            heroOld.visibility = View.GONE
            if (col.findViewWithTag<View>("skin_hero") == null) {
                val logo = SkinLogoView(this).apply {
                    tag = "skin_hero"
                    setColors(
                        BrandKit.accent(this@MainActivity),
                        SkinKit.attrColor(this@MainActivity, R.attr.skinCard, 0xFFFFFFFF.toInt())
                    )
                }
                col.addView(logo, idx.coerceAtMost(col.childCount), LinearLayout.LayoutParams(dp(64), dp(64)))
            }
        }
        val heroView = col.findViewWithTag<View>("skin_hero") ?: heroOld

        val buttons = listOf(
            findViewById<Button>(R.id.btn_files),
            findViewById<Button>(R.id.btn_history),
            findViewById<Button>(R.id.btn_open_folder),
            findViewById<Button>(R.id.btn_settings)
        ).filterNotNull()
        if (spec.homeWide) {
            // 收集全部按钮与间隔，row1 改为竖排大按钮容器，row2 隐藏
            val spaces = mutableListOf<View>()
            listOf(row1, row2).forEach { row ->
                for (i in row.childCount - 1 downTo 0) {
                    val c = row.getChildAt(i)
                    if (c is android.widget.Space || buttons.contains(c)) row.removeView(c)
                    if (c is android.widget.Space) spaces.add(c)
                }
            }
            row2.visibility = View.GONE
            row1.orientation = LinearLayout.VERTICAL
            row1.removeAllViews()
            buttons.forEachIndexed { i, b ->
                b.layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(52)
                ).apply { if (i > 0) topMargin = dp(10) }
                row1.addView(b)
            }
            // hero 放大 + 间距
            heroView?.layoutParams = LinearLayout.LayoutParams(dp(76), dp(76))
            row1.layoutParams = (row1.layoutParams as LinearLayout.LayoutParams).apply {
                topMargin = dp(18)
            }
        }
        // 按钮强调色随皮肤（v1.11.8）
        listOf(R.id.btn_files, R.id.btn_history, R.id.btn_open_folder, R.id.btn_settings)
            .forEach { id -> findViewById<Button>(id)?.setTextColor(SkinKit.iconTint(this)) }
        if (spec.homeLeft) {
            col.gravity = Gravity.START
            findViewById<View>(R.id.iv_hero)?.let { v ->
                (v.layoutParams as? LinearLayout.LayoutParams)?.gravity = Gravity.START
            }
            findViewById<TextView>(R.id.tv_app_name)?.let { v ->
                v.gravity = Gravity.START
                (v.layoutParams as? LinearLayout.LayoutParams)?.gravity = Gravity.START
            }
            findViewById<TextView>(R.id.tv_status)?.let { v ->
                v.gravity = Gravity.START
                (v.layoutParams as? LinearLayout.LayoutParams)?.gravity = Gravity.START
            }
            findViewById<TextView>(R.id.tv_detail)?.let { v ->
                v.gravity = Gravity.START
            }
        }
    }

    // ==================== 首次使用引导（v1.10.1） ====================

    /** 首启全屏引导：logo + 四大功能点 + 开始按钮（点按后淡出，不再出现） */
    private fun showOnboarding() {
        val decor = window.decorView as ViewGroup
        val dp = { v: Int -> (v * resources.displayMetrics.density + 0.5f).toInt() }
        val layer = FrameLayout(this).apply {
            tag = "onboarding"
            setBackgroundColor(getColor(R.color.bg_page))
            isClickable = true
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(28), dp(48), dp(28), dp(28))
        }
        col.addView(
            SkinLogoView(this).apply {
                setColors(
                    BrandKit.accent(this@MainActivity),
                    SkinKit.attrColor(this@MainActivity, R.attr.skinCard, 0xFFFFFFFF.toInt())
                )
            },
            LinearLayout.LayoutParams(dp(72), dp(72))
        )
        col.addView(
            TextView(this).apply {
                text = getString(R.string.ob_title)
                textSize = 24f
                setTextColor(SkinKit.text(this@MainActivity))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(14) }
        )
        col.addView(
            TextView(this).apply {
                text = getString(R.string.ob_slogan)
                textSize = 13.5f
                setTextColor(getColor(R.color.text_secondary))
                gravity = Gravity.CENTER
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        val feats = listOf(
            Triple(R.drawable.ic_check, R.string.ob_f1t, R.string.ob_f1d),
            Triple(R.drawable.ic_cat_doc, R.string.ob_f2t, R.string.ob_f2d),
            Triple(R.drawable.ic_folder, R.string.ob_f3t, R.string.ob_f3d),
            Triple(R.drawable.ic_history, R.string.ob_f4t, R.string.ob_f4d)
        )
        feats.forEach { f ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(
                ImageView(this).apply {
                    setImageResource(f.first)
                    setColorFilter(SkinKit.iconTint(this@MainActivity))
                },
                LinearLayout.LayoutParams(dp(20), dp(20))
            )
            val tcol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            tcol.addView(
                TextView(this).apply {
                    text = getString(f.second)
                    textSize = 14.5f
                    setTextColor(SkinKit.text(this@MainActivity))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                }
            )
            tcol.addView(
                TextView(this).apply {
                    text = getString(f.third)
                    textSize = 12f
                    setTextColor(getColor(R.color.text_secondary))
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(2) }
            )
            row.addView(
                tcol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { leftMargin = dp(12) }
            )
            col.addView(
                row, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(22) }
            )
        }
        val btnStart = TextView(this).apply {
            text = getString(R.string.ob_start)
            textSize = 15f
            gravity = Gravity.CENTER
            background = SkinKit.primaryBtn(this@MainActivity)
            setTextColor(BrandKit.WHITE)
            setPadding(dp(20), dp(12), dp(20), dp(12))
            Anim.pressable(this)
            setOnClickListener {
                AppSettings.setOnboardingDone(this@MainActivity)
                layer.animate().alpha(0f).setDuration(200L)
                    .withEndAction { decor.removeView(layer) }.start()
            }
        }
        col.addView(
            btnStart, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(34) }
        )
        layer.addView(
            col, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { gravity = Gravity.CENTER }
        )
        decor.addView(
            layer, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
    }

    /** 统计卡片填充 */
    private fun fillStats() {
        val s = try {
            HistoryStore.stats(this)
        } catch (_: Exception) {
            null
        } ?: return
        tvStatTotal.text = s.total.toString()
        tvStatWeek.text = s.week.toString()
        tvStatSize.text = HistoryStore.fmtSize(s.bytes)
        statsCard.visibility = View.VISIBLE
    }

    // ==================== 保存确认面板 ====================

    @SuppressLint("SetTextI18n")
    private fun showSaveSheet(items: List<ShareItem>) {
        sheetItems = items
        contentScroll.visibility = View.GONE
        workArea.visibility = View.GONE
        sheetOverlay.visibility = View.VISIBLE

        sheetTitle.text = if (items.size == 1)
            getString(R.string.sheet_title_one)
        else
            getString(R.string.sheet_title_many, items.size)

        // 「记住来源」勾选框：来源可识别 且 功能开启 且 尚未记住
        if (srcPkg != null && AppSettings.sourceMemoryEnabled(this) &&
            !AppSettings.isSilentSource(this, srcPkg!!)
        ) {
            cbRemember.text = getString(R.string.sheet_remember, srcLabel ?: srcPkg)
            cbRemember.isChecked = false
            cbRemember.visibility = View.VISIBLE
        } else {
            cbRemember.visibility = View.GONE
        }

        buildSheetRows(items)

        // 面板入场：缩放 + 淡入（回弹）
        val reduced = Anim.reducedMotion(this)
        if (!reduced) {
            sheetScrim.alpha = 0f
            sheetScrim.animate().alpha(1f).setDuration(250L)
                .setInterpolator(Anim.EXIT).start()
            sheetCard.alpha = 0f
            sheetCard.scaleX = 0.9f
            sheetCard.scaleY = 0.9f
            sheetCard.translationY = dp(16).toFloat()
            sheetCard.animate().alpha(1f).scaleX(1f).scaleY(1f).translationY(0f)
                .setDuration(300L).setInterpolator(Anim.ENTER).start()
        } else {
            sheetScrim.alpha = 1f
            sheetCard.alpha = 1f
            sheetCard.scaleX = 1f
            sheetCard.scaleY = 1f
            sheetCard.translationY = 0f
        }
    }

    /** 构建面板行：图标 + 名称输入 + 冲突预览 */
    private fun buildSheetRows(items: List<ShareItem>) {
        sheetList.removeAllViews()
        val rows = ArrayList<RowState>()

        items.forEach { item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }

            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            top.gravity = Gravity.CENTER_VERTICAL

            // 分类图标（线性风格）
            val cat = CategoryUtils.categorize(
                item.defaultName, item.uri, contentResolver, AppSettings.customRules(this)
            )
            val icon = ImageView(this).apply {
                setImageResource(CategoryIcons.forCategory(cat))
                setColorFilter(SkinKit.iconTint(this@MainActivity))
            }
            top.addView(
                icon, LinearLayout.LayoutParams(dp(20), dp(20)).apply {
                    marginEnd = dp(10)
                }
            )

            // 名称输入框
            val edit = EditText(this).apply {
                setText(item.defaultName)
                setSingleLine()
                imeOptions = EditorInfo.IME_ACTION_DONE
                inputType = InputType.TYPE_CLASS_TEXT
                background.setTint(SkinKit.divider(this@MainActivity))
                setTextColor(SkinKit.text(this@MainActivity))
                setHintTextColor(SkinKit.textSub(this@MainActivity))
                textSize = 14f
            }
            top.addView(
                edit, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(
                top, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )

            // 冲突预览（灰字）
            val hint = TextView(this).apply {
                textSize = 12f
                setTextColor(SkinKit.textSub(this@MainActivity))
                setPadding(dp(30), 0, 0, 0)
            }
            row.addView(
                hint, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )

            sheetList.addView(row)
            rows.add(RowState(item, edit, hint))
        }
        sheetRows = rows
        rows.forEach { updateRowPreview(it) }
    }

    /** 实时预览：无冲突显示最终名；冲突显示自动命名；跳过模式显示跳过 */
    private fun updateRowPreview(st: RowState) {
        val name = st.edit.text.toString().trim().ifBlank { st.item.defaultName }
        val cat = CategoryUtils.categorize(
            name, st.item.uri, contentResolver, AppSettings.customRules(this)
        )
        val dirName = resolveDirName(cat)
        val skip = AppSettings.dupMode(this) == AppSettings.DUP_SKIP

        if (useRootEngine()) {
            val root = File(Environment.getExternalStorageDirectory(), AppSettings.rootName(this))
            val dir = if (dirName.isEmpty()) root else File(root, dirName)
            val existing = HashMap<String, Long>()
            dir.listFiles()?.forEach { f -> existing[f.name] = f.lastModified() }

            when {
                !existing.containsKey(name) ->
                    st.hint.text = getString(R.string.sheet_hint_free, name)
                skip ->
                    st.hint.text = getString(R.string.sheet_hint_skip)
                else -> {
                    val final = SmartNamer.resolve(name, existing)
                    st.hint.text = getString(R.string.sheet_hint_conflict, final)
                }
            }
        } else {
            // MediaStore 引擎：由系统自动消歧，只做存在性提示
            val relDir = mediaRelDir(cat)
            st.hint.text = when {
                skip && mediaExists(relDir, name) -> getString(R.string.sheet_hint_skip)
                else -> getString(R.string.sheet_hint_free, name)
            }
        }

        // 输入变化 → 实时刷新预览
        st.edit.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) = updateRowPreview(st)
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })
    }

    // ==================== 保存流程 ====================

    private fun onSheetSave() {
        val names = sheetRows.map { it.edit.text.toString().trim().ifBlank { it.item.defaultName } }
        if (cbRemember.visibility == View.VISIBLE && cbRemember.isChecked) {
            srcPkg?.let { AppSettings.setSilentSource(this, it) }
        }
        val items = sheetItems
        dismissSheet { startSave(items, names) }
    }

    private fun dismissSheet(after: () -> Unit) {
        val reduced = Anim.reducedMotion(this)
        if (reduced) {
            sheetOverlay.visibility = View.GONE
            after()
            return
        }
        // 面板退场：缩放 + 淡出（加速离场），结束后回调
        sheetScrim.animate().alpha(0f).setDuration(200L)
            .setInterpolator(Anim.EXIT).start()
        sheetCard.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f)
            .translationY(dp(10).toFloat())
            .setDuration(250L).setInterpolator(Anim.EXIT)
            .withEndAction {
                sheetOverlay.visibility = View.GONE
                after()
            }.start()
    }

    /** 后台执行保存（items 与 names 一一对应） */
    private fun startSave(items: List<ShareItem>, names: List<String>?) {
        pendingItems = emptyList()
        showSavingState(items.size)
        thread {
            val results = ArrayList<SaveInfo>()
            val hist = ArrayList<HistoryStore.Rec>()
            val now = System.currentTimeMillis()

            items.forEachIndexed { i, item ->
                val desired = names?.getOrNull(i) ?: item.defaultName
                // 存储空间预警（v1.9.9）：剩余不足 20MB 放弃本项，避免半截文件
                val free = android.os.Environment.getExternalStorageDirectory().usableSpace
                if (free < 20L * 1024 * 1024) {
                    results.add(
                        SaveInfo(
                            false, false, "", desired, "",
                            getString(R.string.err_low_space), "", null, 0, item.text != null
                        )
                    )
                    mainHandler.post { updateSavingProgress(i + 1, items.size) }
                    return@forEachIndexed
                }
                val info = try {
                    when {
                        useSafEngine() -> saveSaf(item, desired)
                        useRootEngine() -> saveRoot(item, desired)
                        else -> saveMedia(item, desired)
                    }
                } catch (e: Exception) {
                    SaveInfo(
                        false, false, "", desired, "",
                        e.message ?: "未知错误", "", null, 0, item.text != null
                    )
                }
                results.add(info)
                mainHandler.post { updateSavingProgress(i + 1, items.size) }

                // 成功 → 写入收纳历史
                if (info.success) {
                    hist.add(
                        HistoryStore.Rec(
                            id = now * 1000 + i,
                            fileName = info.fileName,
                            category = info.category,
                            pathDisplay = info.dir,
                            absPath = info.absPath,
                            contentUri = info.contentUri,
                            source = srcLabel ?: getString(R.string.source_unknown),
                            time = now,
                            size = info.size,
                            isText = info.isText
                        )
                    )
                }
            }
            try {
                HistoryStore.add(this, hist)
            } catch (_: Exception) {
            }
            mainHandler.post { showResults(results) }
        }
    }

    /** 根目录引擎：保存到 存储根目录/我的文件/<分类>/ */
    private fun saveRoot(item: ShareItem, desired: String): SaveInfo {
        val name = desired.ifBlank { item.defaultName }
        val cat = CategoryUtils.categorize(
            name, item.uri, contentResolver, AppSettings.customRules(this)
        )
        val dirName = resolveDirName(cat)
        val root = File(Environment.getExternalStorageDirectory(), AppSettings.rootName(this))
        val dir = if (dirName.isEmpty()) root else File(root, dirName)
        if (!dir.exists() && !dir.mkdirs()) {
            throw IOException("无法创建目录 ${dir.absolutePath}")
        }

        // 已有文件：名称 → 创建时间（智能命名判定基准）
        val existing = HashMap<String, Long>()
        dir.listFiles()?.forEach { f -> existing[f.name] = f.lastModified() }

        // 跳过模式
        if (existing.containsKey(name) && AppSettings.dupMode(this) == AppSettings.DUP_SKIP) {
            return SaveInfo(
                false, true, relDisplay(dirName), name, cat, null, "", null, 0, item.text != null
            )
        }

        // 智能链式命名（永不覆盖）
        val final = SmartNamer.resolve(name, existing)
        val target = File(dir, final)

        var size = 0L
        if (item.text != null) {
            // 文本收集：直接写入
            val bytes = item.text.toByteArray()
            FileOutputStream(target).use { it.write(bytes) }
            size = bytes.size.toLong()
        } else {
            // 文件分享：ContentResolver 读流拷贝
            val input = contentResolver.openInputStream(item.uri!!)
                ?: throw IOException("无法读取分享内容")
            input.use { ins ->
                FileOutputStream(target).use { outs -> size = ins.copyTo(outs) }
            }
        }
        return SaveInfo(
            true, false, relDisplay(dirName), final, cat, null,
            target.absolutePath, null, size, item.text != null
        )
    }

    /** SAF 引擎：保存到系统授权目录（免「所有文件」权限） */
    private fun saveSaf(item: ShareItem, desired: String): SaveInfo {
        val name = desired.ifBlank { item.defaultName }
        val cat = CategoryUtils.categorize(
            name, item.uri, contentResolver, AppSettings.customRules(this)
        )
        val tree = SafKit.tree(this) ?: throw IOException("SAF 目录未配置")
        val rootDocId = SafKit.rootDocId(tree)

        // 目标子目录（平铺 → 树根；分类 → 找或建子目录；月份细分 → 再下一层）
        var dirId = rootDocId
        if (!AppSettings.flat(this)) {
            dirId = SafKit.findChild(this, rootDocId, cat)?.takeIf { it.isDir }?.docId
                ?: SafKit.ensureDir(this, rootDocId, cat)
                ?: throw IOException("无法创建分类目录")
        }
        if (AppSettings.subMonth(this)) {
            val cal = java.util.Calendar.getInstance()
            val monthDir = String.format("%04d-%02d", cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1)
            dirId = SafKit.findChild(this, dirId, monthDir)?.takeIf { it.isDir }?.docId
                ?: SafKit.ensureDir(this, dirId, monthDir)
                ?: throw IOException("无法创建月份目录")
        }

        // 已有文件（名称 → 修改时间，智能命名基准）
        val existing = HashMap<String, Long>()
        SafKit.children(this, dirId).forEach { c -> existing[c.name] = c.modified }

        // 跳过模式
        if (existing.containsKey(name) && AppSettings.dupMode(this) == AppSettings.DUP_SKIP) {
            return SaveInfo(
                false, true, SafKit.displayPath(tree, dirId), name, cat,
                null, "", null, 0, item.text != null
            )
        }

        // 智能链式命名（永不覆盖）
        val final = SmartNamer.resolve(name, existing)
        val mime = guessMime(item, final)
        val fileUri = SafKit.createFile(this, dirId, mime, final)
            ?: throw IOException("创建文件失败")

        var size = 0L
        val outs = contentResolver.openOutputStream(fileUri)
            ?: throw IOException("无法打开输出流")
        outs.use { output ->
            if (item.text != null) {
                val bytes = item.text.toByteArray()
                output.write(bytes)
                size = bytes.size.toLong()
            } else {
                val input = contentResolver.openInputStream(item.uri!!)
                    ?: throw IOException("无法读取分享内容")
                input.use { ins -> size = ins.copyTo(output) }
            }
        }
        return SaveInfo(
            true, false, SafKit.displayPath(tree, dirId), final, cat, null,
            fileUri.toString(), fileUri.toString(), size, item.text != null
        )
    }

    /** MediaStore 免权限引擎（API 29+） */
    private fun saveMedia(item: ShareItem, desired: String): SaveInfo {
        val name = desired.ifBlank { item.defaultName }
        val cat = CategoryUtils.categorize(
            name, item.uri, contentResolver, AppSettings.customRules(this)
        )
        val mime = guessMime(item, name)

        val (coll, baseDir) = when {
            mime.startsWith("image/") ->
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") ->
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") ->
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_MUSIC
            else ->
                MediaStore.Downloads.EXTERNAL_CONTENT_URI to Environment.DIRECTORY_DOWNLOADS
        }
        val rootName = AppSettings.rootName(this)
        val relDir = if (AppSettings.flat(this)) "$baseDir/$rootName"
        else "$baseDir/$rootName/$cat"

        // 跳过模式（查询可见条目）
        if (AppSettings.dupMode(this) == AppSettings.DUP_SKIP && mediaExists(relDir, name)) {
            return SaveInfo(
                false, true, relDisplayMedia(baseDir, cat), name, cat, null, "", null, 0,
                item.text != null
            )
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, relDir)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val outUri = contentResolver.insert(coll, values)
            ?: throw IOException("MediaStore 插入失败")

        var size = 0L
        val outs = contentResolver.openOutputStream(outUri)
            ?: throw IOException("无法打开输出流")
        outs.use { output ->
            if (item.text != null) {
                val bytes = item.text.toByteArray()
                output.write(bytes)
                size = bytes.size.toLong()
            } else {
                val input = contentResolver.openInputStream(item.uri!!)
                    ?: throw IOException("无法读取分享内容")
                input.use { ins -> size = ins.copyTo(output) }
            }
        }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        contentResolver.update(outUri, values, null, null)

        return SaveInfo(
            true, false, relDisplayMedia(baseDir, cat), name, cat, null,
            "", outUri.toString(), size, item.text != null
        )
    }

    // ==================== 工作区（骨架屏 / 结果） ====================

    @SuppressLint("SetTextI18n")
    private fun showSavingState(total: Int) {
        contentScroll.visibility = View.GONE
        sheetOverlay.visibility = View.GONE
        workArea.visibility = View.VISIBLE
        tvWorkTitle.text = getString(R.string.status_saving)
        btnWorkDone.visibility = View.GONE
        workList.removeAllViews()

        // 骨架屏（脉冲动画，与内容结构同形）
        val reduced = Anim.reducedMotion(this)
        repeat(minOf(total, 8)) {
            val sk = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val line1 = View(this).apply { background = getDrawable(R.drawable.bg_skeleton) }
            sk.addView(
                line1, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(18)
                ).apply { bottomMargin = dp(8) }
            )
            val line2 = View(this).apply { background = getDrawable(R.drawable.bg_skeleton) }
            sk.addView(
                line2, LinearLayout.LayoutParams(dp(150), dp(12))
            )
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(18) }
            workList.addView(sk, lp)

            if (!reduced) {
                line1.alpha = 0.55f
                line2.alpha = 0.55f
                Anim.pulse(line1)
                Anim.pulse(line2)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateSavingProgress(done: Int, total: Int) {
        if (done < total) tvWorkTitle.text = getString(R.string.status_saving_fmt, done, total)
    }

    @SuppressLint("SetTextI18n")
    private fun showResults(results: List<SaveInfo>) {
        // 收纳完成通知（#3）：App 不在前台/自动退出时仍能直达
        NotifyKit.done(
            this,
            NotifyKit.Summary(
                results.count { it.success },
                results.count { it.skipped },
                results.filter { it.success }.take(3).map { it.fileName }
            )
        )
        workArea.visibility = View.VISIBLE
        contentScroll.visibility = View.GONE
        val ok = results.count { it.success }
        val skipped = results.count { it.skipped }

        tvWorkTitle.text = when {
            ok > 0 -> getString(R.string.status_saved, ok)
            skipped > 0 -> getString(R.string.status_all_skipped)
            else -> getString(R.string.status_all_failed)
        }

        workList.removeAllViews()
        val cards = ArrayList<View>()
        results.forEach { r ->
            val card = buildResultCard(r)
            workList.addView(card)
            cards.add(card)
        }
        Anim.staggerIn(cards, Anim.reducedMotion(this))

        // 结果 Toast（路径 + 分类）
        val toastText = if (results.size == 1 && results[0].success) {
            getString(R.string.toast_saved_one, results[0].dir + results[0].fileName)
        } else if (ok > 0) {
            val summary = summarize(results)
            getString(R.string.toast_saved_many, ok, summary)
        } else {
            results.firstOrNull { it.error != null }?.error ?: ""
        }
        if (toastText.isNotEmpty()) toast(toastText)

        btnWorkDone.visibility = View.VISIBLE
        if (AppSettings.autoExit(this)) {
            mainHandler.postDelayed({ finish() }, AUTO_FINISH_MS)
        }
    }

    /** 结果卡片 */
    @SuppressLint("SetTextI18n")
    private fun buildResultCard(r: SaveInfo): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = SkinKit.card(this@MainActivity)
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = dp(10) }
        card.layoutParams = lp

        // 图标
        val icon = ImageView(this).apply {
            setImageResource(CategoryIcons.forCategory(r.category.ifBlank { CategoryUtils.CAT_OTHER }))
            setColorFilter(SkinKit.iconTint(this@MainActivity))
        }
        card.addView(
            icon, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(12) }
        )

        // 文字区
        val textCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = r.fileName
            setTextColor(SkinKit.text(this@MainActivity))
            textSize = 14f
            isSingleLine = true
            ellipsize = TextUtils.TruncateAt.MIDDLE
        }
        textCol.addView(
            title, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        val sub = TextView(this).apply {
            textSize = 12f
            setTextColor(SkinKit.textSub(this@MainActivity))
            text = when {
                r.success -> getString(R.string.res_saved, r.dir)
                r.skipped -> getString(R.string.res_skipped)
                else -> getString(R.string.res_failed, r.error ?: "")
            }
        }
        textCol.addView(
            sub, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(2) }
        )
        card.addView(
            textCol, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        Anim.pressable(card)
        return card
    }

    /** 分类统计摘要（图片 2 · 视频 1 …） */
    private fun summarize(list: List<SaveInfo>): String =
        list.filter { it.success }
            .groupingBy { it.category }
            .eachCount().entries
            .joinToString(" · ") { "${it.key} ${it.value}" }

    // ==================== 剪贴板笔记（直接复制 → 存为笔记） ====================

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        // 拿到焦点后再读剪贴板（Android 10+ 后台读取受限，前台有焦点即可）
        if (hasFocus) mainHandler.postDelayed({ checkClipboardForNote() }, 350L)
    }

    /** 空闲状态下检测剪贴板文字，提示一键存为笔记 */
    private fun checkClipboardForNote() {
        // 仅主页空闲态提示（保存中 / 结果页 / 面板弹出 / 权限页都不打扰）
        if (pendingItems.isNotEmpty() ||
            workArea.visibility == View.VISIBLE ||
            sheetOverlay.visibility == View.VISIBLE ||
            !::contentScroll.isInitialized ||
            contentScroll.visibility != View.VISIBLE
        ) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this)?.toString() ?: return
        if (text.length < 4 || text.length > 100_000) return
        val hash = md5Hex(text)
        if (hash == AppSettings.clipHash(this)) return
        showClipBar(text)
    }

    private fun md5Hex(s: String): String = try {
        val d = java.security.MessageDigest.getInstance("MD5").digest(s.toByteArray())
        d.joinToString("") { "%02x".format(it) }
    } catch (_: Exception) {
        s.hashCode().toString()
    }

    private fun showClipBar(text: String) {
        pendingClipText = text
        val root = findViewById<FrameLayout>(R.id.main_root)
        if (clipBar == null) buildClipBar(root)
        clipPreview?.text = if (text.length > 60) text.take(60) + "…" else text
        clipBar?.let { bar ->
            bar.bringToFront()
            bar.visibility = View.VISIBLE
            bar.translationY = dp(24).toFloat()
            bar.alpha = 0f
            bar.animate().translationY(0f).alpha(1f).setDuration(250L)
                .setInterpolator(Anim.ENTER).start()
        }
    }

    private fun hideClipBar() {
        pendingClipText = null
        clipBar?.let { bar ->
            bar.animate().alpha(0f).translationY(dp(24).toFloat()).setDuration(200L)
                .withEndAction { bar.visibility = View.GONE }.start()
        }
    }

    private fun buildClipBar(root: FrameLayout) {
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = SkinKit.card(this@MainActivity)
            elevation = SkinKit.overlayElev(this@MainActivity).toFloat()
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }

        // 标签 + 忽略
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(
            TextView(this).apply {
                text = getString(R.string.clip_found)
                textSize = 12f
                setTextColor(SkinKit.textSub(this@MainActivity))
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        top.addView(
            TextView(this).apply {
                text = getString(R.string.clip_ignore)
                textSize = 13f
                setTextColor(SkinKit.textSub(this@MainActivity))
                background = getDrawable(R.drawable.ripple_text)
                setPadding(dp(12), dp(4), dp(12), dp(4))
                setOnClickListener {
                    pendingClipText?.let { AppSettings.setClipHash(this@MainActivity, md5Hex(it)) }
                    hideClipBar()
                }
            }
        )
        bar.addView(
            top, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // 预览
        val preview = TextView(this).apply {
            textSize = 14f
            setTextColor(SkinKit.text(this@MainActivity))
            ellipsize = TextUtils.TruncateAt.MIDDLE
            isSingleLine = true
            setPadding(0, dp(4), 0, 0)
        }
        bar.addView(
            preview, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        clipPreview = preview

        // 存为笔记按钮
        bar.addView(
            Button(this).apply {
                text = getString(R.string.clip_save)
                background = SkinKit.primaryBtn(this@MainActivity)
                minHeight = dp(42)
                stateListAnimator = null
                isAllCaps = false
                setTextColor(BrandKit.onAccent(this@MainActivity))
                textSize = 14f
                setOnClickListener { saveClipNote() }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(12) }
        )

        root.addView(
            bar,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            ).apply {
                marginStart = dp(20)
                marginEnd = dp(20)
                bottomMargin = dp(20)
            }
        )
        clipBar = bar
    }

    /** 把剪贴板文字走标准保存管线（分类归入「文档」） */
    private fun saveClipNote() {
        val text = pendingClipText ?: return
        AppSettings.setClipHash(this, md5Hex(text))
        srcLabel = getString(R.string.source_clipboard)
        val name = "笔记 " + java.text.SimpleDateFormat(
            "MMdd HHmm", Locale.getDefault()
        ).format(java.util.Date()) + ".txt"
        hideClipBar()
        startSave(listOf(ShareItem(null, name, text)), null)
    }

    // ==================== 文件夹直达 ====================

    private fun openFolder() {
        // SAF 引擎：授权目录交给系统文件管理器打开
        if (useSafEngine()) {
            SafKit.tree(this)?.let { t ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(t, DocumentsContract.Document.MIME_TYPE_DIR)
                    })
                    return
                } catch (_: Exception) {
                }
            }
            showFolderPaths()
            return
        }
        val rootName = AppSettings.rootName(this)
        val root = File(Environment.getExternalStorageDirectory(), rootName)
        if (useRootEngine() && root.exists()) {
            // 1) API 26+：系统文件管理器（DocumentsUI）直达并定位到收纳文件夹
            if (Build.VERSION.SDK_INT >= 26) {
                try {
                    val docUri = DocumentsContract.buildDocumentUri(
                        "com.android.externalstorage.documents",
                        "primary:$rootName"
                    )
                    val intent = Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(docUri, DocumentsContract.Document.MIME_TYPE_DIR)
                        putExtra(DocumentsContract.EXTRA_INITIAL_URI, docUri)
                    }
                    startActivity(intent)
                    return
                } catch (_: Exception) {
                    // 该设备无响应 → 落到下一级兜底
                }
            }
            try {
                // 2) 兜底：目录作为 content Uri 交给能处理的应用
                val intent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(
                        BoxProvider.uriFor(root),
                        DocumentsContract.Document.MIME_TYPE_DIR
                    )
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                startActivity(intent)
                return
            } catch (_: Exception) {
                // 没有文件管理器能接 → 兜底显示路径
            }
        }
        showFolderPaths()
    }

    /** 兜底：弹窗显示保存位置 + 复制路径 */
    private fun showFolderPaths() {
        val rootName = AppSettings.rootName(this)
        val pathText: String
        val msg: String
        if (useRootEngine()) {
            val root = File(Environment.getExternalStorageDirectory(), rootName)
            pathText = root.absolutePath
            msg = "保存位置：\n\n" + root.absolutePath
        } else {
            pathText = "Download/$rootName"
            msg = getString(R.string.folder_paths_media, rootName)
        }
        DialogKit.confirm(
            this, getString(R.string.folder_open_title), msg,
            okText = getString(R.string.folder_copy)
        ) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("path", pathText))
            toast(getString(R.string.copied))
        }
    }

    // ==================== 内容工具 ====================

    /** 通过 ContentResolver 查询分享 Uri 的原始文件名 */
    private fun queryDisplayName(uri: Uri): String = try {
        var name = ""
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) name = cursor.getString(idx) ?: ""
            }
        }
        if (name.isBlank()) uri.lastPathSegment?.substringAfterLast('/') ?: "" else name
    } catch (_: Exception) {
        uri.lastPathSegment?.substringAfterLast('/') ?: ""
    }

    /** 猜测 MIME（MediaStore 插入用） */
    private fun guessMime(item: ShareItem, fileName: String): String {
        if (item.text != null) return "text/plain"
        var mime: String? = null
        try {
            mime = contentResolver.getType(item.uri!!)
        } catch (_: Exception) {
        }
        if (mime.isNullOrBlank()) {
            val ext = fileName.substringAfterLast('.', "").lowercase()
            if (ext.isNotBlank()) {
                mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            }
        }
        return mime ?: "application/octet-stream"
    }

    /** 文本收集的默认文件名：文本 MMdd HHmm.txt */
    private fun defaultTextName(): String =
        "文本 " + SimpleDateFormat("MMdd HHmm", Locale.getDefault()).format(Date()) + ".txt"

    /** MediaStore 引擎：查询目录下同名文件是否存在 */
    private fun mediaExists(relDir: String, name: String): Boolean = try {
        contentResolver.query(
            MediaStore.Files.getContentUri("external"),
            arrayOf(MediaStore.MediaColumns._ID),
            "${MediaStore.MediaColumns.RELATIVE_PATH}=? AND ${MediaStore.MediaColumns.DISPLAY_NAME}=?",
            arrayOf("$relDir/", name), null
        )?.use { it.count > 0 } ?: false
    } catch (_: Exception) {
        false
    }

    private fun mediaRelDir(cat: String): String {
        val rootName = AppSettings.rootName(this)
        return if (AppSettings.flat(this)) "Download/$rootName"
        else "Download/$rootName/$cat"
    }

    /** 保存目标子目录：分类 + 可选月份细分（v1.11.2） */
    private fun resolveDirName(cat: String): String {
        val parts = mutableListOf<String>()
        if (!AppSettings.flat(this)) parts += cat
        if (AppSettings.subMonth(this)) {
            val cal = java.util.Calendar.getInstance()
            parts += String.format("%04d-%02d", cal.get(java.util.Calendar.YEAR), cal.get(java.util.Calendar.MONTH) + 1)
        }
        return parts.joinToString("/")
    }

    private fun relDisplay(dirName: String): String {
        val rootName = AppSettings.rootName(this)
        return if (dirName.isEmpty()) "$rootName/" else "$rootName/$dirName/"
    }

    private fun relDisplayMedia(baseDir: String, cat: String): String {
        val rootName = AppSettings.rootName(this)
        return if (AppSettings.flat(this)) "$baseDir/$rootName/"
        else "$baseDir/$rootName/$cat/"
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()

    // ==================== 视图绑定 ====================

    private fun bindViews() {
        contentScroll = findViewById(R.id.content_scroll)
        tvStatus = findViewById(R.id.tv_status)
        tvDetail = findViewById(R.id.tv_detail)
        btnAction = findViewById(R.id.btn_action)
        btnFallback = findViewById(R.id.btn_fallback)
        btnSettings = findViewById(R.id.btn_settings)
        btnOpenFolder = findViewById(R.id.btn_open_folder)
        btnHistory = findViewById(R.id.btn_history)
        btnFiles = findViewById(R.id.btn_files)
        statsCard = findViewById(R.id.stats_card)
        tvStatTotal = findViewById(R.id.tv_stat_total)
        tvStatWeek = findViewById(R.id.tv_stat_week)
        tvStatSize = findViewById(R.id.tv_stat_size)
        workArea = findViewById(R.id.work_area)
        tvWorkTitle = findViewById(R.id.tv_work_title)
        workList = findViewById(R.id.work_list)
        btnWorkDone = findViewById(R.id.btn_work_done)
        sheetOverlay = findViewById(R.id.sheet_overlay)
        sheetScrim = findViewById(R.id.sheet_scrim)
        sheetCard = findViewById(R.id.sheet_card)
        sheetTitle = findViewById(R.id.sheet_title)
        sheetScroll = findViewById(R.id.sheet_scroll)
        sheetList = findViewById(R.id.sheet_list)
        cbRemember = findViewById(R.id.cb_remember)
        btnSheetCancel = findViewById(R.id.btn_sheet_cancel)
        btnSheetSave = findViewById(R.id.btn_sheet_save)
    }

    private fun bindActions() {
        Anim.pressable(btnAction)
        Anim.pressable(btnFallback)
        Anim.pressable(btnSettings)
        Anim.pressable(btnOpenFolder)
        Anim.pressable(btnHistory)
        Anim.pressable(btnFiles)
        Anim.pressable(btnSheetCancel)
        Anim.pressable(btnSheetSave)
        Anim.pressable(btnWorkDone)

        btnSettings.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        btnHistory.setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        btnFiles.setOnClickListener {
            startActivity(Intent(this, FilesActivity::class.java))
        }
        btnOpenFolder.setOnClickListener { openFolder() }
        btnSheetCancel.setOnClickListener {
            dismissSheet { finish() }
        }
        btnSheetSave.setOnClickListener { onSheetSave() }
        btnWorkDone.setOnClickListener { finish() }
    }
}
