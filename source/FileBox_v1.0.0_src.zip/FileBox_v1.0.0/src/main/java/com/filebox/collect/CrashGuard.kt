package com.filebox.collect

import android.app.Activity
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * 崩溃自证（行车记录仪）
 *
 * 远程报障往往没有日志——这里把任何未捕获异常落盘到
 * App 专属目录（免权限），主页空闲态检测到未读崩溃时
 * 弹出横幅：一句话原因 + 「复制详情」一键复制完整堆栈。
 * 用户截图/粘贴即可精准定位，不再隔空猜。
 */
object CrashGuard {

    private const val KEY_UNREAD = "crash_unread"
    private const val KEY_HEAD = "crash_head"

    /** 在每个 Activity 的 onCreate 最前面调用（幂等） */
    fun install(a: Activity) {
        appRef = a.applicationContext
        val systemHandler = Thread.getDefaultUncaughtExceptionHandler()
        if (systemHandler is Guard) return // 已安装
        Thread.setDefaultUncaughtExceptionHandler(Guard(systemHandler))
    }

    private class Guard(
        private val system: Thread.UncaughtExceptionHandler?
    ) : Thread.UncaughtExceptionHandler {
        override fun uncaughtException(t: Thread, e: Throwable) {
            try {
                val sw = StringWriter()
                e.printStackTrace(PrintWriter(sw))
                val detail = buildString {
                    append("FileBox ")
                    append("时间: ")
                    append(java.text.SimpleDateFormat(
                        "MM-dd HH:mm:ss", java.util.Locale.getDefault()
                    ).format(java.util.Date()))
                    append('\n')
                    append(sw.toString())
                }
                // 落盘（App 专属外部目录，免权限）
                runCatching {
                    val dir = appRef?.getExternalFilesDir(null) ?: return@runCatching
                    File(dir, "crash_latest.txt").writeText(detail.take(60_000))
                }
                // prefs 存摘要（主页横幅用）——commit 同步写盘，进程将死时 apply 会丢
                appRef?.let { ctx ->
                    ctx.getSharedPreferences("filebox_meta", Context_MODE)
                        .edit()
                        .putBoolean(KEY_UNREAD, true)
                        .putString(KEY_HEAD, crashHead(e))
                        .commit()
                }
            } catch (_: Exception) {
            }
            system?.uncaughtException(t, e)
        }

        private fun crashHead(e: Throwable): String {
            val msg = e.message ?: ""
            val cls = e.javaClass.simpleName
            val line = e.stackTrace.firstOrNull {
                it.className.startsWith("com.filebox")
            }?.let { "${it.className.substringAfterLast('.')}#${it.methodName}" } ?: ""
            return "$cls: ${msg.take(120)} @ $line"
        }
    }

    private const val Context_MODE = android.content.Context.MODE_PRIVATE

    @Volatile
    private var appRef: android.content.Context? = null

    fun bindApp(ctx: android.content.Context) {
        appRef = ctx.applicationContext
    }

    // ==================== 主页横幅 ====================

    fun unreadHead(ctx: android.content.Context): String? {
        val p = ctx.getSharedPreferences("filebox_meta", Context_MODE)
        return if (p.getBoolean(KEY_UNREAD, false)) p.getString(KEY_HEAD, null) else null
    }

    fun fullDetail(ctx: android.content.Context): String? = runCatching {
        val dir = ctx.getExternalFilesDir(null) ?: return null
        val f = File(dir, "crash_latest.txt")
        if (f.exists()) f.readText().take(4000) else null
    }.getOrNull()

    fun clear(ctx: android.content.Context) {
        ctx.getSharedPreferences("filebox_meta", Context_MODE)
            .edit().putBoolean(KEY_UNREAD, false).commit() // 崩溃场景 apply 可能丢
    }

    /** 非致命异常也记录（降级路径用） */
    fun mark(e: Throwable) {
        val sw = StringWriter()
        e.printStackTrace(PrintWriter(sw))
        appRef?.let { ctx ->
            runCatching {
                val dir = ctx.getExternalFilesDir(null)
                dir?.let { File(it, "crash_latest.txt").writeText(sw.toString().take(60_000)) }
            }
            ctx.getSharedPreferences("filebox_meta", Context_MODE).edit()
                .putBoolean(KEY_UNREAD, true)
                .putString(KEY_HEAD, "${e.javaClass.simpleName}: ${e.message?.take(120) ?: ""}")
                .commit()
        }
    }
}
