package com.filebox.collect

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/**
 * 桌面图标皮肤联动（v1.11）——activity-alias 动态切换。
 *
 * manifest 预置 10 个互斥 alias（LauncherSkin0..9，各带皮肤配色图标），
 * 切换界面风格时启用对应 alias、禁用其余——MIUI/澎湃/鸿蒙/原生桌面
 * 均在 1~2 秒内刷新桌面图标（DONT_KILL_APP 不杀进程）。
 * 幂等：重复调用只改变差异项。
 */
object LauncherAlias {

    fun apply(ctx: Context, skinIdx: Int) {
        val pm = ctx.packageManager
        (0..9).forEach { i ->
            val target = runCatching {
                ComponentName(ctx, "com.filebox.collect.LauncherSkin$i")
            }.getOrNull() ?: return@forEach
            runCatching {
                val enabled = i == skinIdx.coerceIn(0, 9)
                val current = pm.getComponentEnabledSetting(target)
                val want = if (enabled)
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED
                else
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                if (current != want) {
                    pm.setComponentEnabledSetting(
                        target, want, PackageManager.DONT_KILL_APP
                    )
                }
            }
        }
    }
}
