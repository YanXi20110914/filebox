package com.filebox.collect

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * 收纳历史页（纯代码构建，Minimal White / Dark 自动适配）
 *
 * 功能：
 *  · 展示每次成功收纳的记录（图标、名称、分类、来源 App、时间、大小）
 *  · 点击卡片 → 用系统应用打开文件
 *  · 长按卡片 → 打开 / 重新分享 / 删除记录
 *  · 顶栏「清空」→ 确认后清空全部记录（不删除文件本身）
 *  · 列表卡片交错弹簧入场
 */
class HistoryActivity : Activity() {

    private lateinit var listContainer: LinearLayout
    private lateinit var emptyView: TextView
    private lateinit var tvCount: TextView

    // ---- 筛选状态（#14） ----
    private var filterKeyword = ""
    private var filterCat: String? = null
    private var filterSrc: String? = null

    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(ThemeKit.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SkinKit.apply(this)
        ThemeKit.apply(this)
        // 保底：任何构建异常 → 极简纯文本页（无任何皮肤/主题依赖，保证能进）
        val content: View = try {
            buildContentView()
        } catch (e: Exception) {
            simpleFallbackView(e)
        }
        setContentView(content)
    }

    /** 兜底简版：诊断模式下也能看历史（正常路径永远不走这里） */
    private fun simpleFallbackView(e: Exception): View {
        CrashGuard.mark(e)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(SkinKit.attrColor(this@HistoryActivity, R.attr.skinBg, 0xFFFFFFFF.toInt()))
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        box.addView(
            TextView(this).apply {
                text = getString(R.string.hist_fallback_title)
                textSize = 15f
                setTextColor(SkinKit.text(this@HistoryActivity))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
        )
        box.addView(
            TextView(this).apply {
                text = e.javaClass.simpleName + ": " + (e.message ?: "")
                textSize = 12f
                setTextColor(SkinKit.textSub(this@HistoryActivity))
                setPadding(0, dp(6), 0, dp(10))
            }
        )
        try {
            HistoryStore.all(this).take(100).forEach { rec ->
                box.addView(
                    TextView(this).apply {
                        text = "· ${rec.fileName}  ${HistoryStore.fmtTime(rec.time)}"
                        textSize = 13f
                        setTextColor(SkinKit.textSub(this@HistoryActivity))
                        setPadding(0, dp(5), 0, 0)
                    }
                )
            }
        } catch (_: Exception) {
        }
        return android.widget.ScrollView(this).apply { addView(box) }
    }

    override fun onResume() {
        super.onResume()
        // 保底：刷新异常不拖垮页面
        try {
            rebuild()
        } catch (e: Exception) {
            CrashGuard.mark(e)
            listContainer.removeAllViews()
            emptyView.visibility = View.VISIBLE
            emptyView.text = getString(R.string.hist_fallback_title)
        }
    }

    // ==================== UI 构建 ====================

    private fun buildContentView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(SkinKit.attrColor(this@HistoryActivity, R.attr.skinBg, 0xFFFFFFFF.toInt()))
        }

        // ---- 顶栏 ----
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(6))
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 28f
            setTextColor(SkinKit.text(this@HistoryActivity))
            setPadding(dp(4), dp(6), dp(12), dp(6))
            Anim.pressable(this)
            setOnClickListener { finish() }
        }
        bar.addView(back)
        val spec = SkinKit.uiSpec(this)
        val title = TextView(this).apply {
            text = getString(R.string.history_title)
            textSize = 20f
            setTextColor(SkinKit.text(this@HistoryActivity))
            setTypeface(
                if (spec.titleMono) android.graphics.Typeface.MONOSPACE else typeface,
                android.graphics.Typeface.BOLD
            )
            if (spec.titleCenter) gravity = Gravity.CENTER
        }
        bar.addView(
            title, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        // 筛选（#14）
        val filterBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_filter)
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = getDrawable(R.drawable.ripple_icon)
            Anim.pressable(this)
            setOnClickListener { showFilterDialog() }
        }
        bar.addView(
            filterBtn, LinearLayout.LayoutParams(dp(44), dp(44))
        )
        val clear = TextView(this).apply {
            text = getString(R.string.history_clear)
            textSize = 14f
            setTextColor(getColor(R.color.error))
            setPadding(dp(8), dp(6), dp(4), dp(6))
            Anim.pressable(this)
            setOnClickListener { confirmClear() }
        }
        bar.addView(clear)
        root.addView(
            bar, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        // 顶栏分隔线（纸张/终端/墨水屏/复古/霓虹/工作台等结构感皮肤）
        if (spec.barLine) {
            root.addView(
                View(this).apply {
                    setBackgroundColor(
                        SkinKit.attrColor(this@HistoryActivity, R.attr.skinRowLine, 0x1A000000.toInt())
                    )
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(1)
                )
            )
        }

        // ---- 副标题（记录数）----
        tvCount = TextView(this).apply {
            textSize = 12f
            setTextColor(SkinKit.textSub(this@HistoryActivity))
            setPadding(dp(20), 0, dp(20), dp(4))
        }
        root.addView(
            tvCount, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // ---- 提示行 ----
        val hint = TextView(this).apply {
            text = getString(R.string.history_hint)
            textSize = 12f
            setTextColor(SkinKit.textSub(this@HistoryActivity))
            setPadding(dp(20), dp(2), dp(20), dp(6))
        }
        root.addView(
            hint, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // ---- 空态 ----
        emptyView = TextView(this).apply {
            text = getString(R.string.history_empty)
            textSize = 14f
            setTextColor(SkinKit.textSub(this@HistoryActivity))
            gravity = Gravity.CENTER
            setPadding(dp(40), dp(80), dp(40), dp(40))
            visibility = View.GONE
            // 空态品牌图标 + 间距
            setCompoundDrawablesRelativeWithIntrinsicBounds(0, R.drawable.ic_folder, 0, 0)
            compoundDrawablePadding = dp(12)
        }

        // ---- 列表 ----
        listContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(24))
        }
        val scroll = ScrollView(this).apply {
            addView(
                emptyView, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            addView(
                listContainer, FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        root.addView(
            scroll, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
            )
        )
        // 大屏 / 分屏 / 横屏：内容列限宽居中
        ThemeKit.capWidth(listContainer)
        ThemeKit.capWidth(emptyView)
        // Android 15 edge-to-edge：根视图插边
        InsetsKit.edge(this)
        InsetsKit.padRoot(root)
        return root
    }

    // ==================== 数据渲染 ====================

    private fun rebuild() {
        val all = try {
            HistoryStore.all(this)
        } catch (_: Exception) {
            emptyList<HistoryStore.Rec>()
        }
        // 应用筛选（#14）：关键词 + 分类 + 来源
        val kw = filterKeyword.trim()
        val recs = all.filter { r ->
            (kw.isBlank() || r.fileName.contains(kw, true) ||
                    r.category.contains(kw, true) ||
                    r.source.contains(kw, true)) &&
            (filterCat == null || r.category == filterCat) &&
            (filterSrc == null || r.source == filterSrc)
        }
        listContainer.removeAllViews()

        tvCount.text = when {
            recs.isEmpty() && all.isEmpty() -> ""
            hasActiveFilter() -> getString(R.string.hist_filtered_fmt, recs.size, all.size)
            else -> getString(R.string.history_count_fmt, recs.size)
        }

        if (recs.isEmpty()) {
            emptyView.visibility = View.VISIBLE
            emptyView.text = if (all.isEmpty() || !hasActiveFilter())
                getString(R.string.history_empty)
            else getString(R.string.hist_none)
            return
        }
        emptyView.visibility = View.GONE

        val cards = ArrayList<View>()
        recs.take(300).forEach { rec ->
            // 单卡降级：单条记录渲染异常不再拖垮整页
            val card: View = try {
                buildCard(rec)
            } catch (e: Exception) {
                TextView(this).apply {
                    text = getString(R.string.hist_card_broken, rec.fileName)
                    textSize = 12f
                    setTextColor(SkinKit.textSub(this@HistoryActivity))
                    setPadding(dp(4), dp(8), dp(4), dp(8))
                }
            }
            listContainer.addView(card)
            cards.add(card)
        }
        Anim.staggerIn(cards, Anim.reducedMotion(this))
    }

    private fun hasActiveFilter(): Boolean =
        filterKeyword.isNotBlank() || filterCat != null || filterSrc != null

    // ==================== 筛选面板（#14） ====================

    private fun showFilterDialog() {
        val recs = try {
            HistoryStore.all(this)
        } catch (_: Exception) {
            emptyList<HistoryStore.Rec>()
        }
        val cats = linkedSetOf(*CategoryUtils.ALL_CATS.toTypedArray())
        cats.addAll(recs.map { it.category })
        val srcs = linkedSetOf<String>().apply { recs.forEach { add(it.source) } }

        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(10), dp(22), dp(6))
        }

        // 关键词
        val kwInput = EditText(this).apply {
            hint = getString(R.string.hist_kw)
            setText(filterKeyword)
            background = SkinKit.input(this@HistoryActivity)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            isSingleLine = true
            textSize = 14f
        }
        wrap.addView(
            kwInput, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // 分类 chips（横向滚动）
        wrap.addView(label(getString(R.string.hist_cat)))
        val catChips = chipRow(wrap)
        val catViews = HashMap<String, TextView>()
        (listOf<String?>(null) + cats.toList()).forEach { c ->
            val chip = makeChip(c ?: getString(R.string.hist_all), c == filterCat)
            catViews[c ?: ""] = chip
            catChips.addView(chip)
            chip.setOnClickListener {
                filterCat = c
                refreshChipSelection(catViews, c ?: "")
                refreshChipSelection(srcViewsCache, filterSrc ?: "")
            }
        }

        // 来源 chips
        wrap.addView(label(getString(R.string.hist_src)))
        val srcChips = chipRow(wrap)
        (listOf<String?>(null) + srcs.toList()).forEach { s ->
            val chip = makeChip(s ?: getString(R.string.hist_all), s == filterSrc)
            srcViewsCache[s ?: ""] = chip
            srcChips.addView(chip)
            chip.setOnClickListener {
                filterSrc = s
                refreshChipSelection(srcViewsCache, s ?: "")
                refreshChipSelection(catViews, filterCat ?: "")
            }
        }

        DialogKit.show(
            this, getString(R.string.hist_filter_title),
            ScrollView(this).apply { addView(wrap) },
            listOf(
                Triple(getString(R.string.hist_reset), false) {
                    filterKeyword = ""
                    filterCat = null
                    filterSrc = null
                    rebuild()
                },
                Triple(getString(R.string.btn_close), false, null),
                Triple(getString(R.string.hist_apply), true) {
                    filterKeyword = kwInput.text.toString()
                    rebuild()
                }
            )
        )
    }

    private val srcViewsCache = HashMap<String, TextView>()

    private fun label(text: String): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 12f
            setTextColor(SkinKit.textSub(this@HistoryActivity))
            setPadding(0, dp(12), 0, dp(6))
        }

    private fun chipRow(parent: LinearLayout): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        parent.addView(
            HorizontalScrollView(this).apply { addView(row) },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        return row
    }

    private fun makeChip(text: String, selected: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = 13f
            setPadding(dp(12), dp(7), dp(12), dp(7))
            setTextColor(if (selected) BrandKit.onAccent(this@HistoryActivity) else SkinKit.textMuted(this@HistoryActivity))
            background = if (selected) SkinKit.primaryBtn(this@HistoryActivity)
            else SkinKit.secondaryBtn(this@HistoryActivity)
        }

    private fun refreshChipSelection(map: Map<String, TextView>, activeKey: String) {
        map.forEach { (k, v) ->
            val sel = k == activeKey
            v.setTextColor(if (sel) BrandKit.onAccent(this@HistoryActivity) else SkinKit.textMuted(this@HistoryActivity))
            v.background = if (sel) SkinKit.primaryBtn(this@HistoryActivity)
            else SkinKit.secondaryBtn(this@HistoryActivity)
        }
    }

    /** 单条历史卡片 */
    private fun buildCard(rec: HistoryStore.Rec): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            // 卡片底（bg_card）+ 圆角涟漪按压反馈
            background = RippleDrawable(
                ColorStateList.valueOf(SkinKit.ripple(this@HistoryActivity)),
                SkinKit.card(this@HistoryActivity),
                GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = SkinKit.cardRadius(this@HistoryActivity)
                }
            )
            elevation = SkinKit.cardElev(this@HistoryActivity).toFloat()
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // 分类图标
        val icon = ImageView(this).apply {
            setImageResource(CategoryIcons.forCategory(rec.category))
            setColorFilter(SkinKit.iconTint(this@HistoryActivity))
        }
        card.addView(
            icon, LinearLayout.LayoutParams(dp(20), dp(20)).apply { marginEnd = dp(12) }
        )

        // 文字区
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val title = TextView(this).apply {
            text = rec.fileName
            textSize = 14f
            setTextColor(SkinKit.text(this@HistoryActivity))
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.MIDDLE
        }
        col.addView(
            title, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        val sub = TextView(this).apply {
            text = buildString {
                append(rec.category)
                if (rec.isText) append(" · 文本")
                append(" · 来自 ")
                append(rec.source)
                append("\n")
                append(HistoryStore.fmtTime(rec.time))
                append(" · ")
                append(HistoryStore.fmtSize(rec.size))
            }
            textSize = 12f
            setTextColor(SkinKit.textSub(this@HistoryActivity))
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        col.addView(
            sub, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(2) }
        )
        // 文件备注（#7）
        val note = MetaStore.noteFor(this, rec.absPath)
        if (!note.isNullOrBlank()) {
            col.addView(
                TextView(this).apply {
                    text = getString(R.string.note_label, note)
                    textSize = 12f
                    setTextColor(SkinKit.textMuted(this@HistoryActivity))
                    isSingleLine = true
                    ellipsize = android.text.TextUtils.TruncateAt.END
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(1) }
            )
        }
        card.addView(
            col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        // 右侧箭头
        val chevron = TextView(this).apply {
            text = "›"
            textSize = 18f
            setTextColor(SkinKit.textSub(this@HistoryActivity))
        }
        card.addView(chevron)

        Anim.pressable(card)
        card.setOnClickListener { openRec(rec) }
        card.setOnLongClickListener {
            showActions(rec)
            true
        }
        return card
    }

    // ==================== 记录操作 ====================

    /** 打开文件（系统应用）；APK 直达安装确认 */
    private fun openRec(rec: HistoryStore.Rec) {
        if (InstallKit.isApk(rec.fileName)) {
            val f = File(rec.absPath)
            if (f.isFile) {
                InstallKit.confirm(this, f)
                return
            }
        }
        try {
            startActivity(viewIntent(rec))
        } catch (_: Exception) {
            // 精确 MIME 无应用响应 → 弹「选择打开方式」兜底（含 */* 全量应用）
            OpenWithKit.show(this, contentUriFor(rec), rec.fileName, mimeFor(rec))
        }
    }

    /** 重新分享 */
    private fun shareRec(rec: HistoryStore.Rec) {
        try {
            val uri = contentUriFor(rec)
            val send = Intent(Intent.ACTION_SEND).apply {
                type = mimeFor(rec)
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(send, getString(R.string.history_share)))
        } catch (_: Exception) {
            toast(getString(R.string.history_no_app))
        }
    }

    /** 长按操作面板 */
    private fun showActions(rec: HistoryStore.Rec) {
        // 「打开所在文件夹」仅对根目录引擎的记录（无 contentUri）且文件仍存在时提供
        val canLocate = rec.contentUri == null && File(rec.absPath).exists()
        val isApkRec = InstallKit.isApk(rec.fileName) && File(rec.absPath).isFile
        val options = buildList {
            if (isApkRec) add(getString(R.string.install_btn))
            add(getString(R.string.history_open))
            add(getString(R.string.act_open_with))
            add(getString(R.string.history_share))
            if (canLocate) add(getString(R.string.history_locate))
            add(getString(R.string.history_del))
        }
        val actions = mutableListOf<Pair<String, () -> Unit>>()
        if (isApkRec) actions.add(getString(R.string.install_btn) to { InstallKit.confirm(this@HistoryActivity, File(rec.absPath)) })
        actions.add(getString(R.string.history_open) to { openRec(rec) })
        actions.add(getString(R.string.act_open_with) to {
            OpenWithKit.show(this, contentUriFor(rec), rec.fileName, mimeFor(rec))
        })
        actions.add(getString(R.string.history_share) to { shareRec(rec) })
        if (canLocate) actions.add(getString(R.string.history_locate) to {
            // 跳到文件管理页并直接进入该文件所在文件夹
            val dir = File(rec.absPath).parentFile
            val intent = Intent(this, FilesActivity::class.java)
            if (dir != null) intent.putExtra(FilesActivity.EXTRA_START_DIR, dir.absolutePath)
            startActivity(intent)
        })
        actions.add(getString(R.string.history_del) to {
            HistoryStore.delete(this, rec.id)
            rebuild()
        })
        DialogKit.menu(this, rec.fileName, actions)
    }

    private fun confirmClear() {
        DialogKit.confirm(
            this, getString(R.string.history_clear),
            getString(R.string.history_confirm_clear),
            okText = getString(R.string.history_clear)
        ) {
            HistoryStore.clear(this)
            rebuild()
        }
    }

    // ==================== 工具 ====================

    private fun contentUriFor(rec: HistoryStore.Rec): Uri =
        rec.contentUri?.let { Uri.parse(it) } ?: BoxProvider.uriFor(File(rec.absPath))

    private fun mimeFor(rec: HistoryStore.Rec): String {
        // 根目录引擎的记录：本地文件存在时嗅探文件头，无扩展名文本也能识别
        if (rec.contentUri == null) {
            val f = File(rec.absPath)
            if (f.isFile) return MimeKit.forFile(f)
        }
        return MimeKit.forName(rec.fileName)
    }

    private fun viewIntent(rec: HistoryStore.Rec): Intent =
        Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUriFor(rec), mimeFor(rec))
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()
}
