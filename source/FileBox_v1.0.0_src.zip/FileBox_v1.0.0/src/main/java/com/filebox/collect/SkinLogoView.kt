package com.filebox.collect

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View

/**
 * 应用 Logo（v1.10.3）：flat-shadow 收纳盒图形，代码绘制。
 *
 * 颜色随皮肤联动——传入当前皮肤的强调色/卡色，
 * 切换界面风格后 Logo 的盒身、盖、描边细节同步变色。
 * 图形结构复刻 icon-07-flatshadow.svg（白底圆角卡 + 斜投影 + 双色盒）。
 */
class SkinLogoView(ctx: Context) : View(ctx) {

    private var cAccent = 0xFF378ADD.toInt()   // 盖 / 描边（亮）
    private var cDeep = 0xFF185FA5.toInt()     // 盒身（深）
    private var cCard = 0xFFFFFFFF.toInt()     // 底卡

    private val pFill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val pStroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
    }

    /** 设置配色（accent=当前皮肤强调色；card=皮肤卡色），自动推导深浅 */
    fun setColors(accent: Int, card: Int) {
        this.cAccent = accent
        this.cDeep = shade(accent, 0.62f)
        this.cCard = card
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val s = width.coerceAtMost(height) / 240f   // SVG viewport 240 → 实际
        val ox = (width - 240 * s) / 2f
        val oy = (height - 240 * s) / 2f
        fun T(x: Float, y: Float): Pair<Float, Float> = Pair(ox + x * s, oy + y * s)

        // 底卡：白/皮肤卡色圆角矩形 + 强调色描边
        pFill.color = cCard
        canvas.drawRoundRect(ox + 8 * s, oy + 8 * s, ox + 232 * s, oy + 232 * s, 52 * s, 52 * s, pFill)
        pStroke.color = cAccent
        pStroke.strokeWidth = 6 * s
        canvas.drawRoundRect(ox + 8 * s, oy + 8 * s, ox + 232 * s, oy + 232 * s, 52 * s, 52 * s, pStroke)

        // 斜投影（深色 18%）
        val shadow = Path()
        val (x1, y1) = T(60f, 120f); val (x2, y2) = T(196f, 232f)
        val (x3, y3) = T(232f, 232f); val (x4, y4) = T(232f, 160f)
        val (x5, y5) = T(124f, 84f)
        shadow.moveTo(x1, y1); shadow.lineTo(x2, y2); shadow.lineTo(x3, y3)
        shadow.lineTo(x4, y4); shadow.lineTo(x5, y5); shadow.close()
        pFill.color = withAlpha(cDeep, 0.18f)
        canvas.drawPath(shadow, pFill)

        // 盒身（深）
        pFill.color = cDeep
        canvas.drawRoundRect(ox + 62 * s, oy + 104 * s, ox + 178 * s, oy + 180 * s, 10 * s, 10 * s, pFill)

        // 盖（亮）
        pFill.color = cAccent
        canvas.drawRoundRect(ox + 52 * s, oy + 80 * s, ox + 188 * s, oy + 108 * s, 14 * s, 14 * s, pFill)

        // 提手 + 双文本条（卡色/白）
        pFill.color = cCard
        canvas.drawRoundRect(ox + 98 * s, oy + 89 * s, ox + 142 * s, oy + 101 * s, 6 * s, 6 * s, pFill)
        canvas.drawRoundRect(ox + 80 * s, oy + 126 * s, ox + 160 * s, oy + 132 * s, 3 * s, 3 * s, pFill)
        pFill.color = withAlpha(cCard, 0.6f)
        canvas.drawRoundRect(ox + 80 * s, oy + 140 * s, ox + 134 * s, oy + 146 * s, 3 * s, 3 * s, pFill)
    }

    private fun withAlpha(color: Int, a: Float): Int =
        (color and 0x00FFFFFF) or ((a * 255).toInt() shl 24)

    private fun shade(color: Int, f: Float): Int {
        val r = ((color shr 16 and 0xFF) * f).toInt().coerceIn(0, 255)
        val g = ((color shr 8 and 0xFF) * f).toInt().coerceIn(0, 255)
        val b = ((color and 0xFF) * f).toInt().coerceIn(0, 255)
        return 0xFF000000.toInt() or (r shl 16) or (g shl 8) or b
    }
}
