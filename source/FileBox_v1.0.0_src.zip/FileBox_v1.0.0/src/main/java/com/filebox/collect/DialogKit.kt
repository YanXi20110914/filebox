package com.filebox.collect

import android.app.Activity
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/**
 * 内置弹窗引擎（v1.10.0）——全 App 弹窗统一走这里，零系统 AlertDialog。
 *
 * 结构：decorView 上挂全屏 scrim 层（点击关闭 / 返回键拦截 / 支持弹窗栈），
 * 卡片 = 皮肤卡底 + 圆角 + 标题/内容/按钮行，随十款皮肤与强调色自动换装。
 * 动效：遮罩淡入 + 卡片自下而上弹入（Anim.ENTER），退场加速离场（Anim.EXIT）。
 * 按钮回调返回 false 可保持弹窗打开（如表单校验失败）。
 */
object DialogKit {

    private const val TAG_SCRIM = "dk_scrim"
    private const val TAG_SHEET = "dk_sheet"
    private const val TAG_BUSY = "dk_busy"

    // ==================== 遮罩宿主 ====================

    private fun host(a: Activity): FrameLayout {
        val decor = a.window.decorView as ViewGroup
        decor.findViewWithTag<View>(TAG_SCRIM)?.let { return it as FrameLayout }
        val scrim = FrameLayout(a).apply {
            tag = TAG_SCRIM
            setBackgroundColor(0x59000000)
            visibility = View.INVISIBLE
            isClickable = true
            isFocusable = true
            isFocusableInTouchMode = true
            setOnKeyListener { _, k, e ->
                if (k == KeyEvent.KEYCODE_BACK && e.action == KeyEvent.ACTION_UP) {
                    dismissTop(a); true
                } else false
            }
        }
        decor.addView(
            scrim, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        return scrim
    }

    /** 关闭最上层弹窗（忙碌层不响应） */
    fun dismissTop(a: Activity) {
        val scrim = (a.window.decorView as? ViewGroup)
            ?.findViewWithTag<View>(TAG_SCRIM) as? FrameLayout ?: return
        if (scrim.childCount == 0) return
        val layer = scrim.getChildAt(scrim.childCount - 1)
        if (layer.findViewWithTag<View>(TAG_BUSY) != null) return
        layer.findViewWithTag<View>(TAG_SHEET)?.let { sheet ->
            sheet.animate().alpha(0f).translationY(dp(a, 14).toFloat())
                .setDuration(140L).setInterpolator(Anim.EXIT).start()
        }
        layer.animate().alpha(0f).setDuration(140L).setInterpolator(Anim.EXIT)
            .withEndAction {
                scrim.removeView(layer)
                if (scrim.childCount == 0) {
                    scrim.animate().cancel()
                    scrim.visibility = View.INVISIBLE
                    scrim.alpha = 1f
                }
            }.start()
    }

    // ==================== 核心 ====================

    /**
     * 通用弹窗。
     * @param buttons 按钮列表（次→主），元素：文案 / 是否主按钮 / 回调（返回 false 不关闭）
     * @param cancelOnScrim 点击遮罩是否关闭
     */
    fun show(
        a: Activity, title: String?, body: View? = null,
        buttons: List<Triple<String, Boolean, (() -> Any?)?>?> = listOf(),
        cancelOnScrim: Boolean = true, scrollBody: Boolean = true
    ): View {
        val scrim = host(a)
        val layer = FrameLayout(a)
        layer.tag = TAG_SHEET
        layer.alpha = 0f
        scrim.addView(
            layer, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        scrim.visibility = View.VISIBLE
        scrim.alpha = 0f
        scrim.animate().alpha(1f).setDuration(150L).setInterpolator(Anim.ENTER).start()
        // 层级淡入（v1.10.1 修复：此前 layer 恒为 0 导致弹窗不可见）
        layer.animate().alpha(1f).setDuration(150L).setInterpolator(Anim.ENTER).start()

        val card = LinearLayout(a).apply {
            orientation = LinearLayout.VERTICAL
            background = SkinKit.card(a)
            elevation = dp(a, 8).toFloat()
            setPadding(dp(a, 18), dp(a, 16), dp(a, 18), dp(a, 12))
        }
        title?.let {
            card.addView(
                TextView(a).apply {
                    text = it
                    textSize = 16f
                    setTextColor(SkinKit.text(a))
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
            card.addView(
                View(a), LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 10)
                )
            )
        }
        body?.let {
            if (scrollBody) {
                card.addView(
                    ScrollView(a).apply { addView(it) }, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            } else {
                card.addView(
                    it, LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        }
        if (buttons.isNotEmpty()) {
            card.addView(
                View(a), LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(a, 12)
                )
            )
            val row = LinearLayout(a).apply { gravity = Gravity.END }
            buttons.filterNotNull().forEach { b ->
                row.addView(
                    TextView(a).apply {
                        text = b.first
                        textSize = 14f
                        if (b.second) {
                            background = SkinKit.primaryBtn(a)
                            setTextColor(BrandKit.WHITE)
                            setPadding(dp(a, 16), dp(a, 8), dp(a, 16), dp(a, 8))
                        } else {
                            background = SkinKit.secondaryBtn(a)
                            setTextColor(SkinKit.text(a))
                            setPadding(dp(a, 14), dp(a, 8), dp(a, 14), dp(a, 8))
                        }
                        Anim.pressable(this)
                        setOnClickListener {
                            val r = b.third?.invoke()
                            if (r != false) dismissTop(a)
                        }
                    },
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                    ).apply { leftMargin = dp(a, 10) }
                )
            }
            card.addView(
                row, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        val holder = FrameLayout(a)
        holder.addView(
            card, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                gravity = Gravity.CENTER
                leftMargin = dp(a, 24); rightMargin = dp(a, 24)
            }
        )
        ThemeKit.capWidth(card)
        layer.addView(holder)
        layer.setOnClickListener { if (cancelOnScrim) dismissTop(a) }

        card.translationY = dp(a, 18).toFloat()
        card.animate().alpha(1f).translationY(0f)
            .setDuration(240L).setInterpolator(Anim.ENTER)
            .setStartDelay(30L).start()
        return card
    }

    // ==================== 三件套 ====================

    /** 确认框：msg 文本 + 主/次按钮 */
    fun confirm(
        a: Activity, title: String, msg: String,
        okText: String = a.getString(R.string.dk_ok), onOk: (() -> Unit)? = null,
        cancelText: String = a.getString(R.string.dk_cancel), onCancel: (() -> Unit)? = null
    ) {
        val body = TextView(a).apply {
            text = msg
            textSize = 13.5f
            setTextColor(SkinKit.textSub(a))
            setPadding(dp(a, 4), dp(a, 2), dp(a, 4), dp(a, 4))
        }
        show(
            a, title, body, listOf(
                Triple(cancelText, false) { onCancel?.invoke(); Unit },
                Triple(okText, true) { onOk?.invoke(); Unit }
            )
        )
    }

    /** 列表菜单（长按操作等）：竖排行，点击即回调 */
    fun menu(a: Activity, title: String?, items: List<Pair<String, () -> Unit>>) {
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        items.forEach { item ->
            col.addView(
                TextView(a).apply {
                    text = item.first
                    textSize = 14.5f
                    setTextColor(SkinKit.text(a))
                    background = a.getDrawable(R.drawable.ripple_text)
                    setPadding(dp(a, 6), dp(a, 12), dp(a, 6), dp(a, 12))
                    Anim.pressable(this)
                    setOnClickListener {
                        dismissTop(a)
                        item.second.invoke()
                    }
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        show(a, title, col, listOf(), scrollBody = true)
    }

    /** 单选列表（排序等）：当前项行尾强调色 ✓ */
    fun choices(a: Activity, title: String?, labels: List<String>, checked: Int, onPick: (Int) -> Unit) {
        val col = LinearLayout(a).apply { orientation = LinearLayout.VERTICAL }
        labels.forEachIndexed { i, label ->
            val row = LinearLayout(a).apply {
                gravity = Gravity.CENTER_VERTICAL
                background = a.getDrawable(R.drawable.ripple_text)
                setPadding(dp(a, 6), dp(a, 11), dp(a, 6), dp(a, 11))
                Anim.pressable(this)
                setOnClickListener {
                    dismissTop(a)
                    onPick(i)
                }
            }
            row.addView(
                TextView(a).apply {
                    text = label
                    textSize = 14.5f
                    setTextColor(SkinKit.text(a))
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            if (i == checked) {
                row.addView(
                    TextView(a).apply {
                        text = "✓"
                        textSize = 15f
                        setTextColor(BrandKit.accent(a))
                        setTypeface(typeface, android.graphics.Typeface.BOLD)
                    }
                )
            }
            col.addView(
                row, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }
        show(a, title, col, listOf(), scrollBody = true)
    }

    /** 仅展示（统计/关于）：一个关闭按钮 */
    fun message(a: Activity, title: String, body: View, closeText: String = a.getString(R.string.dk_ok)) {
        show(a, title, body, listOf(Triple(closeText, true, null)))
    }

    /**
     * 忙碌提示（扫描中/清理中）：无按钮、遮罩与返回键均不关闭；
     * 返回 sheet 句柄，完成后用 dismissSheet 关闭（切主线程）。
     */
    fun busy(a: Activity, msg: String): View {
        val body = TextView(a).apply {
            text = msg
            textSize = 13.5f
            setTextColor(SkinKit.textSub(a))
            setPadding(dp(a, 4), dp(a, 6), dp(a, 4), dp(a, 2))
        }
        val sheet = show(a, null, body, listOf(), cancelOnScrim = false, scrollBody = false)
        sheet.tag = TAG_BUSY
        return sheet
    }

    /** 关闭指定 sheet（配合 busy 使用） */
    fun dismissSheet(a: Activity, sheet: View) {
        val scrim = (a.window.decorView as? ViewGroup)
            ?.findViewWithTag<View>(TAG_SCRIM) as? FrameLayout ?: return
        val layer = sheet.parent as? FrameLayout ?: return
        if (layer.parent !== scrim) return
        sheet.animate().alpha(0f).translationY(dp(a, 14).toFloat())
            .setDuration(140L).setInterpolator(Anim.EXIT).start()
        layer.animate().alpha(0f).setDuration(140L).setInterpolator(Anim.EXIT)
            .withEndAction {
                scrim.removeView(layer)
                if (scrim.childCount == 0) {
                    scrim.animate().cancel()
                    scrim.visibility = View.INVISIBLE
                    scrim.alpha = 1f
                }
            }.start()
    }

    private fun dp(a: Activity, v: Int): Int =
        (v * a.resources.displayMetrics.density + 0.5f).toInt()
}
