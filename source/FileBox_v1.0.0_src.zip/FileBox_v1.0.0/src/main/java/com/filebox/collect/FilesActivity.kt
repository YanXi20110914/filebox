package com.filebox.collect

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.Settings
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.MimeTypeMap
import android.widget.AbsListView
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * 文件管理页（应用内建，与全局 Minimal White / Dark 风格统一）
 *
 * 功能：
 *  · 浏览收纳目录树：文件夹在前，面包屑导航，返回键逐级回退
 *    （根目录引擎 = File API；SAF 引擎 = 系统授权目录，DocumentsContract 查询）
 *  · 全局搜索：搜索整个收纳盒（不只当前目录），结果带相对路径
 *  · 排序：名称 / 修改时间 / 大小 / 类型（记忆到设置）
 *  · 视图：列表 / 网格切换（记忆到设置）
 *  · 收藏星标：置顶显示（记忆在本地）
 *  · 备注：给文件加一句话备注（文件页 + 历史页可见）
 *  · 详情：名称 / 分类 / 大小 / 修改时间 / 收纳时间 / 位置 / MD5
 *  · 新建文件夹
 *  · 打开（系统应用）/ 分享 / 重命名 / 删除 / 复制路径 / 多选批量
 *  · 无权限时显示引导页
 */
class FilesActivity : Activity() {

    // ==================== 数据模型 ====================

    /** 统一文件条目：根目录引擎=File，SAF=docId */
    private class Entry(
        val name: String,
        val isDir: Boolean,
        val size: Long,
        val modified: Long,
        val file: File?,          // 根目录引擎
        val docId: String?,       // SAF 引擎
        val relPath: String       // 相对根路径（全局搜索显示用）
    )

    // ==================== 状态 ====================

    private lateinit var rootDir: File          // 「我的文件」根（根目录引擎）
    private lateinit var currentDir: File       // 当前目录（根目录引擎）
    private var tree: Uri? = null              // SAF 授权树
    private var currentDocId: String? = null     // SAF 当前目录
    private var safMode = false                 // 当前是否 SAF 引擎

    private var sortMode = 0                    // 0名称 1时间 2大小 3类型
    private var gridMode = false                // 列表/网格
    private var selectMode = false              // 多选模式
    private val checked = HashSet<String>()      // 多选 key 集
    private var items: List<Entry> = emptyList()
    private var firstAnim = true

    // ---- 视图 ----
    private lateinit var tvTitle: TextView
    private lateinit var tvCrumbs: TextView
    private lateinit var searchRow: LinearLayout
    private lateinit var etSearch: EditText
    private lateinit var selBar: LinearLayout
    private lateinit var tvSelCount: TextView
    private lateinit var lvFiles: ListView
    private lateinit var gvFiles: GridView
    private lateinit var tvEmpty: TextView
    private lateinit var emptyBox: View
    private lateinit var permLayer: LinearLayout
    private lateinit var btnView: ImageView
    private lateinit var adapter: FileAdapter

    // ==================== 生命周期 ====================

    override fun attachBaseContext(newBase: Context) {
        super.attachBaseContext(ThemeKit.wrap(newBase))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SkinKit.apply(this)
        ThemeKit.apply(this)
        setContentView(R.layout.activity_files)
        InsetsKit.edge(this)
        InsetsKit.padRoot(findViewById(R.id.files_column))
        // 大屏 / 分屏：内容列限宽居中（手机竖屏无感知）
        ThemeKit.capWidth(findViewById(R.id.files_column))
        ThemeKit.capWidth(findViewById(R.id.perm_box))

        // 引擎
        tree = SafKit.tree(this)
        safMode = AppSettings.useSafEngine(this) && tree != null
        rootDir = File(
            Environment.getExternalStorageDirectory(),
            AppSettings.rootName(this)
        )
        currentDir = rootDir
        currentDocId = tree?.let { SafKit.rootDocId(it) }
        sortMode = AppSettings.filesSort(this)
        gridMode = AppSettings.filesGrid(this)

        bindViews()
        bindActions()
        applyView(false)

        // 历史页「打开所在文件夹」跳转：定位到目标目录
        intent?.getStringExtra(EXTRA_START_DIR)?.let { dir ->
            if (safMode) {
                if (dir.startsWith("content:")) {
                    try {
                        val docId = DocumentsContract.getDocumentId(Uri.parse(dir))
                        currentDocId = docId
                    } catch (_: Exception) {
                    }
                }
            } else {
                val f = File(dir)
                if (f.isDirectory && f.absolutePath.startsWith(rootDir.absolutePath)) {
                    currentDir = f
                }
            }
        }

        if (canBrowse()) {
            permLayer.visibility = View.GONE
            load()
        } else {
            permLayer.visibility = View.VISIBLE
        }
    }

    /** 从系统设置开启权限返回后，自动进入浏览 */
    override fun onResume() {
        super.onResume()
        if (permLayer.visibility == View.VISIBLE && canBrowse()) {
            permLayer.visibility = View.GONE
            load()
        }
    }

    private fun canBrowse(): Boolean =
        if (safMode) true else hasRootAccess()

    // ==================== 数据加载 ====================

    /**
     * 读取当前目录（或全局搜索结果）→ 排序（收藏置顶 > 文件夹 > 排序键）→ 刷新。
     */
    private fun load(animate: Boolean = firstAnim) {
        val q = if (searchRow.visibility == View.VISIBLE)
            etSearch.text.toString().trim().lowercase(Locale.getDefault()) else ""

        items = if (q.isNotBlank()) globalSearch(q) else listCurrent()
        items = items.sortedWith(
            compareByDescending<Entry> { MetaStore.isStarred(this, key(it)) }
                .thenComparator { a, b ->
                    compareByDescending<Entry> { it.isDir }.compare(a, b).let { d ->
                        if (d != 0) d else compare(a, b)
                    }
                }
        )

        adapter.notifyDataSetChanged()
        tvTitle.text = if (q.isNotBlank()) getString(R.string.search_result_title)
        else currentName()
        tvCrumbs.text = if (q.isNotBlank())
            getString(R.string.search_all_scope) + "：\"$q\""
        else crumbsText()
        emptyBox.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        if (items.isEmpty()) {
            tvEmpty.text = if (q.isNotBlank())
                getString(R.string.files_empty_search_short, q)
            else getString(R.string.files_empty)
        }

        val list = activeList()
        if (animate && items.isNotEmpty() && !Anim.reducedMotion(this)) {
            // 交错入场只做首屏可见部分（可被滚动/点击随时中断）
            list.post {
                val kids = ArrayList<View>(minOf(items.size, 9))
                for (i in 0 until minOf(items.size, list.childCount)) {
                    kids.add(list.getChildAt(i))
                }
                Anim.staggerIn(kids, false)
                firstAnim = false
            }
        } else {
            firstAnim = false
        }
    }

    /** 当前目录子项 */
    private fun listCurrent(): List<Entry> {
        if (safMode) {
            val t = tree ?: return emptyList()
            val docId = currentDocId ?: return emptyList()
            return SafKit.children(this, docId).filterNot { it.name.startsWith(".") }
                .map { c ->
                    Entry(
                        c.name, c.isDir, c.size, c.modified,
                        null, c.docId,
                        relOf(c.docId, c.name)
                    )
                }
        }
        val raw = currentDir.listFiles()?.toList() ?: emptyList()
        return raw.filterNot { it.name.startsWith(".") }.map { f ->
            Entry(
                f.name, f.isDirectory, f.length(), f.lastModified(),
                f, null,
                relOf(null, f.name)
            )
        }
    }

    /** 全局搜索：递归整个收纳盒（有扫描上限保护） */
    private fun globalSearch(q: String): List<Entry> {
        val out = ArrayList<Entry>()
        if (safMode) {
            val t = tree ?: return out
            val rootId = SafKit.rootDocId(t)
            val queue = ArrayDeque<Pair<String, String>>() // docId to relPath
            queue.add(rootId to "")
            var scanned = 0
            while (queue.isNotEmpty() && scanned < SEARCH_SCAN_CAP) {
                val (dirId, rel) = queue.removeFirst()
                SafKit.children(this, dirId).forEach { c ->
                    scanned++
                    if (scanned >= SEARCH_SCAN_CAP) return@forEach
                    val childRel = if (rel.isEmpty()) c.name else "$rel/${c.name}"
                    if (c.name.lowercase(Locale.getDefault()).contains(q)) {
                        out.add(
                            Entry(
                                c.name, c.isDir, c.size, c.modified,
                                null, c.docId, childRel
                            )
                        )
                    }
                    if (c.isDir && out.size < SEARCH_RESULT_CAP) {
                        queue.add(c.docId to childRel)
                    }
                }
            }
        } else {
            val queue = ArrayDeque<Pair<File, String>>()
            queue.add(rootDir to "")
            var scanned = 0
            while (queue.isNotEmpty() && scanned < SEARCH_SCAN_CAP) {
                val (dir, rel) = queue.removeFirst()
                val kids = dir.listFiles() ?: continue
                kids.forEach { f ->
                    scanned++
                    if (scanned >= SEARCH_SCAN_CAP) return@forEach
                    if (!f.name.startsWith(".")) {
                        val childRel = if (rel.isEmpty()) f.name else "$rel/${f.name}"
                        if (f.name.lowercase(Locale.getDefault()).contains(q)) {
                            out.add(
                                Entry(
                                    f.name, f.isDirectory, f.length(), f.lastModified(),
                                    f, null, childRel
                                )
                            )
                        }
                        if (f.isDirectory && out.size < SEARCH_RESULT_CAP) {
                            queue.add(f to childRel)
                        }
                    }
                }
            }
        }
        return out
    }

    /** 相对根路径（正常浏览时=文件名所在层） */
    private fun relOf(docId: String?, name: String): String {
        return if (safMode) {
            SafKit.displayPath(tree ?: return name, docId ?: return name)
        } else {
            currentDir.absolutePath.removePrefix(rootDir.absolutePath)
                .removePrefix("/") + "/" + name
        }
    }

    /** 条目唯一 key（收藏/备注用） */
    private fun key(e: Entry): String =
        e.file?.absolutePath ?: SafKit.docUri(tree ?: Uri.EMPTY, e.docId ?: "").toString()

    private fun currentName(): String =
        if (safMode) {
            val id = currentDocId ?: ""
            val tail = id.substringAfterLast('/', "")
            if (id == (tree?.let { SafKit.rootDocId(it) } ?: id)) getString(R.string.files_title)
            else tail.ifBlank { getString(R.string.files_title) }
        } else if (currentDir == rootDir) getString(R.string.files_title)
        else currentDir.name

    /** 排序比较器（sortMode） */
    private fun compare(a: Entry, b: Entry): Int = when (sortMode) {
        1 -> b.modified.compareTo(a.modified)                             // 时间 新→旧
        2 -> b.size.compareTo(a.size)                                      // 大小 大→小
        3 -> {                                                             // 类型：扩展名 + 名称
            val ea = a.name.substringAfterLast('.', "").lowercase(Locale.getDefault())
            val eb = b.name.substringAfterLast('.', "").lowercase(Locale.getDefault())
            if (ea != eb) ea.compareTo(eb)
            else a.name.lowercase(Locale.getDefault())
                .compareTo(b.name.lowercase(Locale.getDefault()))
        }
        else -> a.name.lowercase(Locale.getDefault())                      // 名称 A→Z
            .compareTo(b.name.lowercase(Locale.getDefault()))
    }

    /** 面包屑：我的文件/图片/… */
    private fun crumbsText(): String =
        if (safMode) SafKit.displayPath(tree ?: Uri.EMPTY, currentDocId ?: "")
        else currentDir.absolutePath.removePrefix(
            Environment.getExternalStorageDirectory().absolutePath + "/"
        )

    // ==================== 适配器（列表 + 网格共用） ====================

    private inner class FileAdapter : BaseAdapter() {

        override fun getCount(): Int = items.size
        override fun getItem(position: Int): Entry = items[position]
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val grid = parent.id == R.id.gv_files
            val v: View
            val holder: Any
            if (convertView == null) {
                v = if (grid) layoutInflater.inflate(R.layout.grid_item_file, parent, false)
                else layoutInflater.inflate(R.layout.list_item_file, parent, false)
                holder = if (grid) {
                    VHGrid(
                        v.findViewById(R.id.iv_icon_grid),
                        v.findViewById(R.id.iv_star_grid),
                        v.findViewById(R.id.tv_name_grid),
                        v.findViewById(R.id.tv_sub_grid),
                        v.findViewById(R.id.iv_check_grid)
                    )
                } else {
                    VHList(
                        v.findViewById(R.id.iv_icon_file),
                        v.findViewById(R.id.tv_name_file),
                        v.findViewById(R.id.tv_sub_file),
                        v.findViewById(R.id.iv_check_file),
                        v.findViewById(R.id.iv_star_file)
                    )
                }
                v.tag = holder
                Anim.pressable(v)
            } else {
                v = convertView
                holder = v.tag as Any
            }

            val e = items[position]
            val starred = MetaStore.isStarred(this@FilesActivity, key(e))
            val note = MetaStore.noteFor(this@FilesActivity, key(e))
            val isSel = selectMode && checked.contains(key(e))
            val inSearch = searchRow.visibility == View.VISIBLE &&
                    etSearch.text.isNotBlank()

            val accent = BrandKit.accent(this@FilesActivity)
            if (holder is VHList) {
                // 图标：文件夹 → 浅底 + 线性文件夹；文件 → 强调色圆底 + 分类图标
                if (e.isDir) {
                    holder.icon.background = SkinKit.badgeFolder(this@FilesActivity)
                    holder.icon.setImageResource(R.drawable.ic_folder)
                } else {
                    holder.icon.background = SkinKit.badgeCat(this@FilesActivity)
                    holder.icon.setImageResource(
                        CategoryIcons.forCategory(
                            CategoryUtils.categorize(
                                e.name, rules = AppSettings.customRules(this@FilesActivity)
                            )
                        )
                    )
                }

                holder.name.text = e.name
                val base = if (inSearch) {
                    // 全局搜索结果：显示相对目录
                    e.relPath.substringBeforeLast('/', "")
                } else if (e.isDir) {
                    val n = if (safMode) -1 else e.file?.listFiles()?.size ?: 0
                    if (n >= 0) getString(R.string.files_sub_dir_fmt, n)
                    else getString(R.string.files_sub_dir)
                } else {
                    HistoryStore.fmtSize(e.size) + " · " + HistoryStore.fmtTime(e.modified)
                }
                holder.sub.text = if (note != null && note.isNotBlank()) {
                    getString(R.string.note_label, note) +
                            (if (base.isBlank()) "" else "\n$base")
                } else base

                holder.star.visibility = if (starred) View.VISIBLE else View.INVISIBLE
                holder.star.setColorFilter(accent)

                holder.check.visibility = if (selectMode) View.VISIBLE else View.INVISIBLE
                holder.check.alpha = if (isSel) 1f else 0f
                holder.name.setTextColor(
                    if (isSel) accent
                    else SkinKit.text(this@FilesActivity)
                )
            } else if (holder is VHGrid) {
                if (e.isDir) {
                    holder.icon.background = SkinKit.badgeFolder(this@FilesActivity)
                    holder.icon.setImageResource(R.drawable.ic_folder)
                } else {
                    holder.icon.background = SkinKit.badgeCat(this@FilesActivity)
                    holder.icon.setImageResource(
                        CategoryIcons.forCategory(
                            CategoryUtils.categorize(
                                e.name, rules = AppSettings.customRules(this@FilesActivity)
                            )
                        )
                    )
                }
                holder.name.text = e.name
                holder.sub.text = if (e.isDir) {
                    if (safMode) getString(R.string.files_sub_dir)
                    else getString(
                        R.string.files_sub_dir_fmt,
                        e.file?.listFiles()?.size ?: 0
                    )
                } else HistoryStore.fmtSize(e.size)

                holder.star.visibility = if (starred) View.VISIBLE else View.INVISIBLE
                holder.star.setColorFilter(accent)
                holder.check.visibility = if (selectMode) View.VISIBLE else View.GONE
            }
            return v
        }
    }

    private class VHList(
        val icon: ImageView,
        val name: TextView,
        val sub: TextView,
        val check: ImageView,
        val star: ImageView
    )

    private class VHGrid(
        val icon: ImageView,
        val star: ImageView,
        val name: TextView,
        val sub: TextView,
        val check: ImageView
    )

    // ==================== 视图绑定 ====================

    private fun bindViews() {
        tvTitle = findViewById(R.id.tv_title_files)
        tvCrumbs = findViewById(R.id.tv_crumbs)
        val spec = SkinKit.uiSpec(this)
        // 皮肤决定顶栏排版：居中标题（墨水屏/禅意）、终端等宽标题
        if (spec.titleCenter) tvTitle.gravity = android.view.Gravity.CENTER
        if (spec.titleMono) {
            tvTitle.typeface = android.graphics.Typeface.MONOSPACE
            tvCrumbs.typeface = android.graphics.Typeface.MONOSPACE
        } else if (AppSettings.skinIdx(this) == 2 || AppSettings.skinIdx(this) == 3) {
            tvCrumbs.typeface = android.graphics.Typeface.MONOSPACE
        }
        // 顶栏分隔线：结构感皮肤显示
        findViewById<View>(R.id.bar_line_files).visibility =
            if (spec.barLine) View.VISIBLE else View.GONE
        searchRow = findViewById(R.id.search_row)
        etSearch = findViewById(R.id.et_search_files)
        selBar = findViewById(R.id.sel_bar)
        tvSelCount = findViewById(R.id.tv_sel_count)
        lvFiles = findViewById(R.id.lv_files)
        gvFiles = findViewById(R.id.gv_files)
        tvEmpty = findViewById(R.id.tv_empty_files)
        emptyBox = findViewById(R.id.empty_files_box)
        permLayer = findViewById(R.id.perm_layer)
        btnView = findViewById(R.id.btn_view_files)
        // 皮肤决定列表密度：禅意大留白 / 终端·复古·工作台紧凑四列
        val lp = spec.listPadDp
        lvFiles.setPadding(lp, lvFiles.paddingTop, lp, lvFiles.paddingBottom)
        gvFiles.setPadding(lp, gvFiles.paddingTop, lp, gvFiles.paddingBottom)
        gvFiles.numColumns = spec.gridCols
        adapter = FileAdapter()
        lvFiles.adapter = adapter
    }

    private fun bindActions() {
        Anim.pressable(findViewById(R.id.btn_back_files))
        Anim.pressable(findViewById(R.id.btn_search_files))
        Anim.pressable(findViewById(R.id.btn_view_files))
        Anim.pressable(findViewById(R.id.btn_sort_files))
        Anim.pressable(findViewById(R.id.btn_new_folder))
        Anim.pressable(findViewById(R.id.btn_search_cancel))
        Anim.pressable(findViewById(R.id.btn_sel_share))
        Anim.pressable(findViewById(R.id.btn_sel_delete))
        Anim.pressable(findViewById(R.id.btn_sel_cancel))
        Anim.pressable(findViewById(R.id.btn_files_perm))

        findViewById<View>(R.id.btn_back_files).setOnClickListener { onBackPressed() }

        // 搜索（全局范围）
        findViewById<View>(R.id.btn_search_files).setOnClickListener {
            if (searchRow.visibility == View.VISIBLE) closeSearch() else openSearch()
        }
        findViewById<View>(R.id.btn_search_cancel).setOnClickListener { closeSearch() }
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { load(false) }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })

        // 视图切换 / 排序 / 新建文件夹 / 权限引导
        btnView.setOnClickListener {
            gridMode = !gridMode
            AppSettings.setFilesGrid(this, gridMode)
            applyView(true)
        }
        findViewById<View>(R.id.btn_sort_files).setOnClickListener { showSortDialog() }
        findViewById<View>(R.id.btn_new_folder).setOnClickListener { showNewFolderDialog() }
        findViewById<View>(R.id.btn_files_perm).setOnClickListener {
            if (safMode) {
                // SAF 模式下引导去设置页选择授权目录
                startActivity(Intent(this, SettingsActivity::class.java))
            } else {
                openAllFilesSettings()
            }
        }

        // 列表交互（列表 + 网格共用逻辑）
        val click: (Int) -> Unit = { position ->
            val e = items[position]
            if (selectMode) {
                toggleCheck(e)
            } else if (e.isDir) {
                if (safMode) {
                    currentDocId = e.docId
                } else {
                    currentDir = e.file ?: currentDir
                }
                firstAnim = true
                load()
            } else if (e.file != null && InstallKit.isApk(e.file.name)) {
                // APK 直装：收纳的应用一键进系统安装器
                InstallKit.confirm(this, e.file)
            } else {
                openFile(e)
            }
        }
        val longClick: (Int) -> Boolean = { position ->
            val e = items[position]
            if (selectMode) {
                toggleCheck(e)
            } else {
                showItemMenu(e)
            }
            true
        }
        lvFiles.setOnItemClickListener { _, _, position, _ -> click(position) }
        gvFiles.setOnItemClickListener { _, _, position, _ -> click(position) }
        lvFiles.setOnItemLongClickListener { _, _, position, _ -> longClick(position) }
        gvFiles.setOnItemLongClickListener { _, _, position, _ -> longClick(position) }

        // 多选操作栏
        findViewById<View>(R.id.btn_sel_share).setOnClickListener { shareChecked() }
        findViewById<View>(R.id.btn_sel_delete).setOnClickListener { deleteChecked() }
        findViewById<View>(R.id.btn_sel_cancel).setOnClickListener { exitSelectMode() }
    }

    /** 列表 / 网格切换 */
    private fun applyView(animate: Boolean) {
        if (gridMode) {
            lvFiles.visibility = View.GONE
            gvFiles.visibility = View.VISIBLE
            gvFiles.adapter = adapter
            btnView.setImageResource(R.drawable.ic_view_list)
        } else {
            gvFiles.visibility = View.GONE
            lvFiles.visibility = View.VISIBLE
            btnView.setImageResource(R.drawable.ic_view_grid)
        }
        if (animate) {
            toast(getString(if (gridMode) R.string.view_now_grid else R.string.view_now_list))
        }
        adapter.notifyDataSetChanged()
    }

    private fun activeList(): AbsListView =
        if (gridMode) gvFiles else lvFiles

    // ==================== 搜索 ====================

    private fun openSearch() {
        searchRow.visibility = View.VISIBLE
        searchRow.alpha = 0f
        searchRow.animate().alpha(1f)
            .setDuration(Anim.DUR_MICRO).setInterpolator(Anim.ENTER).start()
        etSearch.requestFocus()
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.showSoftInput(etSearch, 0)
    }

    private fun closeSearch() {
        if (etSearch.text.isNotBlank()) {
            etSearch.setText("")
            load(false)
        }
        searchRow.visibility = View.GONE
        hideKeyboard()
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)
            ?.hideSoftInputFromWindow(etSearch.windowToken, 0)
    }

    // ==================== 排序 ====================

    private fun showSortDialog() {
        val labels = arrayOf(
            getString(R.string.sort_name), getString(R.string.sort_time),
            getString(R.string.sort_size), getString(R.string.sort_type)
        )
        DialogKit.choices(this, getString(R.string.sort_title), labels.toList(), sortMode) { which ->
            sortMode = which
            AppSettings.setFilesSort(this, which)
            load(false)
        }
    }

    // ==================== 新建文件夹 ====================

    private fun showNewFolderDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.new_folder_hint)
            background = SkinKit.input(this@FilesActivity)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setSingleLine(true)
        }
        DialogKit.show(
            this, getString(R.string.new_folder_title), wrapInput(input),
            listOf(
                Triple(getString(R.string.btn_close), false, null),
                Triple(getString(R.string.btn_create), true) {
                    val name = cleanName(input.text.toString())
                    if (name.isBlank()) toast(getString(R.string.err_name_blank))
                    else createFolder(name)
                }
            )
        )
    }

    private fun createFolder(name: String) {
        if (safMode) {
            val t = tree ?: return
            val dirId = currentDocId ?: return
            val exists = SafKit.findChild(this, dirId, name) != null
            when {
                exists -> toast(getString(R.string.err_exists, name))
                SafKit.ensureDir(this, dirId, name) != null -> {
                    load(false)
                    toast(getString(R.string.folder_created, name))
                }
                else -> toast(getString(R.string.err_io))
            }
        } else {
            val target = File(currentDir, name)
            when {
                target.exists() -> toast(getString(R.string.err_exists, name))
                target.mkdirs() || target.mkdir() -> {
                    load(false)
                    toast(getString(R.string.folder_created, name))
                }
                else -> toast(getString(R.string.err_io))
            }
        }
    }

    // ==================== 单项操作菜单 ====================

    private fun showItemMenu(e: Entry) {
        val starred = MetaStore.isStarred(this, key(e))
        val actions = mutableListOf(
            getString(R.string.act_share),
            getString(if (starred) R.string.act_unstar else R.string.act_star),
            getString(R.string.act_note),
            getString(R.string.act_detail),
            getString(R.string.act_rename),
            getString(R.string.act_delete),
            getString(R.string.act_copy_path),
            getString(R.string.act_multiselect)
        )
        if (!e.isDir) {
            actions.add(0, getString(R.string.act_open))
            actions.add(1, getString(R.string.act_open_with))
        }

        val menuItems = mutableListOf<Pair<String, () -> Unit>>()
        actions.forEach { label ->
            when (label) {
                getString(R.string.act_open) -> menuItems.add(label to { openFile(e) })
                getString(R.string.act_open_with) -> menuItems.add(label to {
                    OpenWithKit.show(this, openUri(e), e.name, mimeFor(e))
                })
                getString(R.string.act_share) -> menuItems.add(label to { shareFiles(listOf(e)) })
                getString(R.string.act_star) -> menuItems.add(label to {
                    MetaStore.toggleStar(this, key(e))
                    toast(getString(R.string.star_on))
                    adapter.notifyDataSetChanged()
                })
                getString(R.string.act_unstar) -> menuItems.add(label to {
                    MetaStore.toggleStar(this, key(e))
                    toast(getString(R.string.star_off))
                    adapter.notifyDataSetChanged()
                })
                getString(R.string.act_note) -> menuItems.add(label to { showNoteDialog(e) })
                getString(R.string.act_detail) -> menuItems.add(label to { showDetailDialog(e) })
                getString(R.string.act_rename) -> menuItems.add(label to { showRenameDialog(e) })
                getString(R.string.act_delete) -> menuItems.add(label to { confirmDelete(listOf(e)) })
                getString(R.string.act_copy_path) -> menuItems.add(label to { copyPath(e) })
                getString(R.string.act_multiselect) -> menuItems.add(label to {
                    enterSelectMode()
                    toggleCheck(e)
                })
            }
        }
        DialogKit.menu(this, e.name, menuItems)
    }

    // ==================== 备注 / 详情 ====================

    private fun showNoteDialog(e: Entry) {
        val input = EditText(this).apply {
            setText(MetaStore.noteFor(this@FilesActivity, key(e)) ?: "")
            hint = getString(R.string.note_hint)
            background = SkinKit.input(this@FilesActivity)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setSingleLine(false)
            minLines = 2
            gravity = Gravity.TOP
        }
        DialogKit.show(
            this, getString(R.string.note_title), wrapInput(input),
            listOf(
                Triple(getString(R.string.btn_close), false, null),
                Triple(getString(R.string.btn_save), true) {
                    val text = input.text.toString().trim()
                    if (text.isBlank()) {
                        MetaStore.setNote(this, key(e), null)
                        toast(getString(R.string.note_cleared))
                    } else {
                        MetaStore.setNote(this, key(e), text)
                        toast(getString(R.string.note_saved))
                    }
                    adapter.notifyDataSetChanged()
                }
            )
        )
    }

    /** 文件详情：名称/分类/大小/时间/位置/收纳信息/MD5 */
    private fun showDetailDialog(e: Entry) {
        val pad = dp(22)
        val root = ScrollView(this)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(6), pad, dp(4))
        }
        val cat = if (e.isDir) getString(R.string.files_sub_dir)
        else CategoryUtils.categorize(
            e.name, rules = AppSettings.customRules(this)
        )
        val stored = try {
            HistoryStore.all(this).firstOrNull { it.absPath == key(e) }
        } catch (_: Exception) {
            null
        }
        val starred = MetaStore.isStarred(this, key(e))
        val note = MetaStore.noteFor(this, key(e))

        addRow(box, getString(R.string.detail_name), e.name)
        addRow(box, getString(R.string.detail_cat), cat)
        addRow(box, getString(R.string.detail_size), HistoryStore.fmtSize(e.size))
        addRow(box, getString(R.string.detail_time), HistoryStore.fmtTime(e.modified))
        addRow(
            box, getString(R.string.detail_stored),
            stored?.let { HistoryStore.fmtTime(it.time) } ?: "—"
        )
        addRow(
            box, getString(R.string.detail_star),
            getString(if (starred) R.string.detail_star else R.string.detail_star_no)
        )
        if (note != null && note.isNotBlank()) {
            addRow(box, getString(R.string.act_note), note)
        }

        // 位置 + 复制
        val pathText = if (safMode) key(e) else e.file?.absolutePath ?: key(e)
        val pathRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        addRow(pathRow, getString(R.string.detail_path), pathText)
        val copyBtn = TextView(this).apply {
            text = getString(R.string.detail_copy)
            setTextColor(BrandKit.accent(this@FilesActivity))
            textSize = 13f
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = getDrawable(R.drawable.ripple_text)
            setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
                    ?.setPrimaryClip(ClipData.newPlainText("path", pathText))
                toast(getString(R.string.copy_done))
            }
        }
        pathRow.addView(copyBtn)
        box.addView(
            pathRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )

        // MD5（文件）
        if (!e.isDir) {
            val md5Row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            val md5Value = TextView(this).apply {
                textSize = 13f
                setTextColor(SkinKit.textMuted(this@FilesActivity))
                text = "—"
                tag = "md5"
            }
            addRow(md5Row, getString(R.string.detail_md5), " ")
            md5Row.addView(
                md5Value, LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f
                )
            )
            val calcBtn = TextView(this).apply {
                text = getString(R.string.detail_md5_btn)
                setTextColor(BrandKit.accent(this@FilesActivity))
                textSize = 13f
                setPadding(dp(8), dp(8), dp(8), dp(8))
                background = getDrawable(R.drawable.ripple_text)
                setOnClickListener {
                    text = getString(R.string.detail_md5_calc)
                    isClickable = false
                    thread {
                        val digest = md5Of(e)
                        runOnUiThread {
                            md5Value.text = digest ?: getString(R.string.err_io)
                            this@apply.text = ""
                        }
                    }
                }
            }
            md5Row.addView(calcBtn)
            box.addView(
                md5Row, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

        root.addView(
            box, ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        DialogKit.message(this, getString(R.string.detail_title), root)
    }

    private fun addRow(parent: LinearLayout, label: String, value: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(6), 0, dp(6))
        }
        row.addView(
            TextView(this).apply {
                text = label
                textSize = 12f
                setTextColor(SkinKit.textSub(this@FilesActivity))
            }
        )
        row.addView(
            TextView(this).apply {
                text = value
                textSize = 14f
                setTextColor(SkinKit.text(this@FilesActivity))
                setTextIsSelectable(true)
            }, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(2) }
        )
        parent.addView(
            row, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
    }

    private fun md5Of(e: Entry): String? = try {
        val md = MessageDigest.getInstance("MD5")
        val input = if (safMode) {
            contentResolver.openInputStream(
                SafKit.docUri(tree ?: return null, e.docId ?: return null)
            ) ?: return null
        } else {
            e.file?.inputStream() ?: return null
        }
        input.use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (_: Exception) {
        null
    }

    // ==================== 打开 / 分享 / 路径 ====================

    /** 打开用的 Uri：根目录引擎走 BoxProvider，SAF 直接用 document uri */
    private fun openUri(e: Entry): Uri {
        if (safMode) return SafKit.docUri(tree ?: Uri.EMPTY, e.docId ?: "")
        return BoxProvider.uriFor(e.file ?: return Uri.EMPTY)
    }

    private fun openFile(e: Entry) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(openUri(e), mimeFor(e))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (_: Exception) {
            // 精确 MIME 无应用响应 → 弹「选择打开方式」兜底（含 */* 全量应用）
            OpenWithKit.show(this, openUri(e), e.name, mimeFor(e))
        }
    }

    private fun shareFiles(list: List<Entry>) {
        if (list.isEmpty()) return
        try {
            val uris = ArrayList<Uri>(list.map { openUri(it) })
            val intent = Intent(
                if (list.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE
            ).apply {
                type = if (list.size == 1) mimeFor(list[0]) else "*/*"
                putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(
                Intent.createChooser(intent, getString(R.string.share_via))
            )
        } catch (_: Exception) {
            toast(getString(R.string.err_share))
        }
    }

    private fun mimeFor(e: Entry): String {
        if (safMode) {
            val uri = SafKit.docUri(tree ?: Uri.EMPTY, e.docId ?: return "*/*")
            return try {
                contentResolver.getType(uri)
            } catch (_: Exception) {
                null
            } ?: run {
                val ext = e.name.substringAfterLast('.', "").lowercase(Locale.getDefault())
                MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            } ?: "*/*"
        }
        return MimeKit.forFile(e.file ?: return "*/*")
    }

    private fun copyPath(e: Entry) {
        val path = if (safMode) key(e) else e.file?.absolutePath ?: key(e)
        (getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager)
            ?.setPrimaryClip(ClipData.newPlainText("path", path))
        toast(getString(R.string.path_copied))
    }

    // ==================== 重命名 ====================

    private fun showRenameDialog(e: Entry) {
        val input = EditText(this).apply {
            setText(e.name)
            setSelection(e.name.length)
            background = SkinKit.input(this@FilesActivity)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            setSingleLine(true)
        }
        DialogKit.show(
            this, getString(R.string.rename_title), wrapInput(input),
            listOf(
                Triple(getString(R.string.btn_close), false, null),
                Triple(getString(R.string.btn_save), true) {
                    val name = cleanName(input.text.toString())
                    when {
                        name.isBlank() -> toast(getString(R.string.err_name_blank))
                        name == e.name -> Unit
                        else -> rename(e, name)
                    }
                }
            )
        )
    }

    private fun rename(e: Entry, name: String) {
        val oldKey = key(e)
        if (safMode) {
            val t = tree ?: return
            val newUri = SafKit.rename(
                this, SafKit.docUri(t, e.docId ?: return), name
            )
            if (newUri != null) {
                HistoryStore.removeByPathPrefix(this, oldKey)
                MetaStore.cleanupPrefix(this, oldKey)
                load(false)
                toast(getString(R.string.renamed, name))
            } else {
                toast(getString(R.string.err_io))
            }
        } else {
            val f = e.file ?: return
            val conflict = File(f.parentFile, name).exists()
            when {
                conflict -> toast(getString(R.string.err_exists, name))
                f.renameTo(File(f.parentFile, name)) -> {
                    HistoryStore.removeByPathPrefix(this, oldKey)
                    MetaStore.cleanupPrefix(this, oldKey)
                    load(false)
                    toast(getString(R.string.renamed, name))
                }
                else -> toast(getString(R.string.err_io))
            }
        }
    }

    // ==================== 删除 ====================

    private fun confirmDelete(list: List<Entry>) {
        val msg = if (list.size == 1) {
            val e = list[0]
            if (e.isDir) getString(R.string.delete_dir_msg, e.name)
            else getString(R.string.delete_file_msg, e.name)
        } else getString(R.string.delete_multi_msg, list.size)

        DialogKit.confirm(
            this, getString(R.string.delete_title), msg,
            okText = getString(R.string.btn_delete)
        ) {
            var ok = 0
            list.forEach { e ->
                val deleted = if (safMode) {
                    SafKit.delete(this, openUri(e))
                } else {
                    e.file?.deleteRecursively() == true
                }
                if (deleted) {
                    HistoryStore.removeByPathPrefix(this, key(e))
                    MetaStore.cleanupPrefix(this, key(e))
                    ok++
                }
            }
            if (selectMode) exitSelectMode()
            load(false)
            toast(getString(R.string.deleted_fmt, ok))
        }
    }

    // ==================== 多选 ====================

    private fun enterSelectMode() {
        selectMode = true
        checked.clear()
        selBar.visibility = View.VISIBLE
        selBar.translationY = dp(56).toFloat()
        selBar.animate().translationY(0f)
            .setDuration(Anim.DUR_COMPONENT).setInterpolator(Anim.ENTER).start()
        refreshSelCount()
        adapter.notifyDataSetChanged()
    }

    private fun exitSelectMode() {
        selectMode = false
        checked.clear()
        selBar.animate().translationY(dp(56).toFloat())
            .setDuration(Anim.DUR_COMPONENT).setInterpolator(Anim.EXIT)
            .withEndAction { selBar.visibility = View.GONE }
            .start()
        adapter.notifyDataSetChanged()
    }

    private fun toggleCheck(e: Entry) {
        val k = key(e)
        if (checked.contains(k)) checked.remove(k)
        else checked.add(k)
        refreshSelCount()
        adapter.notifyDataSetChanged()
        // 全部取消勾选时自动退出多选
        if (checked.isEmpty()) exitSelectMode()
    }

    private fun refreshSelCount() {
        tvSelCount.text = getString(R.string.sel_count_fmt, checked.size)
    }

    private fun shareChecked() {
        shareFiles(items.filter { checked.contains(key(it)) })
    }

    private fun deleteChecked() {
        confirmDelete(items.filter { checked.contains(key(it)) })
    }

    // ==================== 导航 ====================

    override fun onBackPressed() {
        when {
            selectMode -> exitSelectMode()
            searchRow.visibility == View.VISIBLE -> closeSearch()
            !atRoot() -> {
                if (safMode) {
                    currentDocId = SafKit.parentDocId(currentDocId ?: return)
                } else {
                    currentDir = currentDir.parentFile ?: rootDir
                }
                firstAnim = true
                load()
            }
            else -> super.onBackPressed()
        }
    }

    private fun atRoot(): Boolean =
        if (safMode) {
            currentDocId == tree?.let { SafKit.rootDocId(it) }
        } else currentDir == rootDir

    // ==================== 权限 ====================

    private fun hasRootAccess(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED

    private fun openAllFilesSettings() {
        try {
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
        } catch (_: Exception) {
            try {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            } catch (_: Exception) {
                toast(getString(R.string.err_open_settings))
            }
        }
    }

    // ==================== 工具 ====================

    /** 过滤文件系统非法字符 */
    private fun cleanName(raw: String): String =
        raw.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()

    /** 对话框内边距容器 */
    private fun wrapInput(input: EditText): View =
        LinearLayout(this).apply {
            setPadding(dp(22), dp(8), dp(22), dp(4))
            addView(
                input,
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            )
        }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()

    companion object {
        const val EXTRA_START_DIR = "start_dir"
        private const val SEARCH_SCAN_CAP = 8000       // 全局搜索扫描条目上限
        private const val SEARCH_RESULT_CAP = 500      // 全局搜索结果上限
    }
}
