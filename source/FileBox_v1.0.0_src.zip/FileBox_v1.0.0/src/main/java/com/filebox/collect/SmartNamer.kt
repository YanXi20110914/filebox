package com.filebox.collect

import java.util.Calendar
import java.util.Locale

/**
 * 智能链式命名引擎（命名冲突自动处理）
 *
 * 规则（判定基准：已有同名文件的「创建时间」与当前时间的比较；
 *       后缀取值：当前时间）：
 *
 *  1. 无重名                    → 直接使用原名           我的应用
 *  2. 重名，且已有文件创建于不同年份 → 追加年份 YYYY       我的应用 2026
 *  3. 重名，同年但不同日          → 追加月日 MMDD        我的应用 0822
 *  4. 重名，同年同日              → 追加月日时分 MMDDHHMM 我的应用 08220907
 *  5. 极端冲突（候选名仍被占用）   → 追加秒数 MMDDHHMMSS   我的应用 0822090730
 *     或递增序号兜底              → MMDDHHMM-N          我的应用 08220907-2
 *
 * 性能：existing 为预构建的 名称→创建时间 映射（HashMap），
 * 单次解析为 O(1) 查表 + 小循环，1000+ 文件远低于 50ms。
 */
object SmartNamer {

    /**
     * 生成唯一名称。
     *
     * @param desired   期望使用的名称（含扩展名）
     * @param existing  目标目录内 已有名称 → 创建时间（毫秒） 的映射
     * @param now       当前时间（毫秒），默认取系统时间
     * @return 不冲突或链式消歧后的最终名称（保证不覆盖已有文件）
     */
    fun resolve(
        desired: String,
        existing: Map<String, Long>,
        now: Long = System.currentTimeMillis()
    ): String {
        // ---------- 1. 无重名：直接使用 ----------
        if (desired.isEmpty() || !existing.containsKey(desired)) return desired

        // 已有同名文件的创建时间（判定基准）
        val exTime = existing[desired] ?: now

        // 拆分主名与扩展名（后缀插在扩展名之前：文件 0822.pdf）
        val dot = desired.lastIndexOf('.')
        val base: String
        val ext: String
        if (dot > 0) {
            base = desired.substring(0, dot)
            ext = desired.substring(dot)
        } else {
            base = desired
            ext = ""
        }

        val ex = Calendar.getInstance().apply { timeInMillis = exTime }
        val cur = Calendar.getInstance().apply { timeInMillis = now }

        val sameYear = ex.get(Calendar.YEAR) == cur.get(Calendar.YEAR)
        val sameDay = sameYear && ex.get(Calendar.DAY_OF_YEAR) == cur.get(Calendar.DAY_OF_YEAR)

        val md = String.format(
            Locale.US, "%02d%02d",
            cur.get(Calendar.MONTH) + 1, cur.get(Calendar.DAY_OF_MONTH)
        )
        val mdhm = md + String.format(
            Locale.US, "%02d%02d",
            cur.get(Calendar.HOUR_OF_DAY), cur.get(Calendar.MINUTE)
        )
        val mdhms = mdhm + String.format(
            Locale.US, "%02d", cur.get(Calendar.SECOND)
        )

        // ---------- 2~4. 按冲突等级选取后缀 ----------
        val candidate = when {
            !sameYear -> "$base ${cur.get(Calendar.YEAR)}$ext" // 跨年：年份
            !sameDay -> "$base $md$ext"                        // 同年不同日：月日
            else -> "$base $mdhm$ext"                          // 同年同日：月日时分
        }
        if (!existing.containsKey(candidate)) return candidate

        // ---------- 5. 极端冲突：先试带秒，再递增序号 ----------
        val withSec = "$base $mdhms$ext"
        if (!existing.containsKey(withSec)) return withSec

        val stem = "$base $mdhm"
        for (i in 2..9999) {
            val n = "$stem-$i$ext"
            if (!existing.containsKey(n)) return n
        }
        return withSec // 理论上不可达
    }
}
