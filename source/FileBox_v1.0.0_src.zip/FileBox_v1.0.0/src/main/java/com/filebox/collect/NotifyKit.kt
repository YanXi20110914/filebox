package com.filebox.collect

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build

/**
 * 收纳完成通知（#3）
 *
 * 保存流程结束后弹系统通知：标题「已收纳 N 个文件」+ 摘要，
 * 点击直达文件管理页。33+ 需要运行时授权（主页一次性申请），
 * 未授权时静默跳过，不影响保存功能。
 */
object NotifyKit {

    private const val CHANNEL_ID = "filebox_save"
    private const val NOTIFY_ID = 10

    /** 保存结果摘要（供通知文案） */
    class Summary(val ok: Int, val skipped: Int, val lines: List<String>)

    fun channel(ctx: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return
        if (nm.getNotificationChannel(CHANNEL_ID) == null) {
            nm.createNotificationChannel(
                NotificationChannel(
                    CHANNEL_ID,
                    ctx.getString(R.string.notif_channel),
                    NotificationManager.IMPORTANCE_DEFAULT
                ).apply {
                    description = ctx.getString(R.string.notif_channel)
                }
            )
        }
    }

    /** 弹「收纳完成」通知；未授权 / 全失败时静默 */
    fun done(ctx: Context, s: Summary) {
        if (s.ok <= 0) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return
        if (!nm.areNotificationsEnabled()) return
        channel(ctx)

        val pi = PendingIntent.getActivity(
            ctx, 0,
            Intent(ctx, FilesActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        // 通知快捷入口（v1.9.9）：直达收纳历史
        val piHist = PendingIntent.getActivity(
            ctx, 1,
            Intent(ctx, HistoryActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val body = StringBuilder()
        s.lines.take(3).forEach { body.append(it).append('\n') }
        if (s.lines.size > 3) body.append(ctx.getString(R.string.notif_more, s.lines.size - 3))
        if (s.skipped > 0) {
            if (body.isNotEmpty()) body.append('\n')
            body.append(ctx.getString(R.string.res_skipped))
            body.append(' ').append(s.skipped)
        }

        val builder =
            if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, CHANNEL_ID)
            else Notification.Builder(ctx)

        builder.setSmallIcon(R.drawable.ic_check)
            .setContentTitle(ctx.getString(R.string.notif_title_fmt, s.ok))
            .setContentText(ctx.getString(R.string.notif_open))
            .setStyle(Notification.BigTextStyle().bigText(body.toString().trim()))
            .setContentIntent(pi)
            .addAction(
                Notification.Action.Builder(
                    if (Build.VERSION.SDK_INT >= 23) android.graphics.drawable.Icon.createWithResource(ctx, R.drawable.ic_history) else null,
                    ctx.getString(R.string.notif_action_history), piHist
                ).build()
            )
            .setAutoCancel(true)
            .setColor(BrandKit.accent(ctx))

        try {
            nm.notify(NOTIFY_ID, builder.build())
        } catch (_: Exception) {
        }
    }

    /** 主页回到前台时清掉通知 */
    fun cancel(ctx: Context) {
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            ?: return
        nm.cancel(NOTIFY_ID)
    }
}
