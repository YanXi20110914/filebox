package com.filebox.collect

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.RadioGroup
import android.widget.Switch
import android.widget.TextView
import java.io.File
import kotlin.concurrent.thread

/**
 * 设置页（Minimal White / Dark，六张可折叠卡片）
 *
 *  保存     —— 保存前编辑文件名（实时预览冲突）
 *  重名处理 —— 智能链式命名 / 跳过重复
 *  保存位置 —— 根文件夹名 / 平铺模式
 *  来源记忆 —— 总开关 + 已记住的静默来源列表（可移除）
 *  外观     —— 跟随系统 / 浅色 / 深色
 *  其他     —— 保存后自动退出
 *
 * 交互：改动即时保存；折叠卡片带高度 + 透明度 + 箭头旋转过渡；
 * 主题切换立即重建本页并通知主页重建。
 */
class SettingsActivity : Activity() {

    private companion object {
        const val REQ_SAF_TREE = 601
    }

    private lateinit var rgDup: RadioGroup
    private lateinit var swEdit: Switch
    private lateinit var etRoot: EditText
    private lateinit var swFlat: Switch
    private lateinit var swAuto: Switch
    private lateinit var rgTheme: RadioGroup
    private lateinit var swSource: Switch
    private lateinit var llSourceList: LinearLayout
    private lateinit var tvSourceEmpty: TextView

    // ---- v1.9 ----
    private lateinit var swSaf: Switch
    private lateinit var tvSafPath: TextView
    private lateinit var llRules: LinearLayout
    private lateinit var tvRulesEmpty: TextView


    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(ThemeKit.wrap(base))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SkinKit.apply(this)
        ThemeKit.apply(this)
        setContentView(R.layout.activity_settings)
        ThemeKit.capWidth(findViewById(R.id.settings_column))
        // Android 15 edge-to-edge：滚动内容插边
        InsetsKit.edge(this)
        bindViews()
        bindCards()
        loadState()
        bindActions()
        rebuildSourceRows()
        rebuildRuleRows()
        // 皮肤动效：设置行按当前皮肤语言入场（直显皮肤自动跳过）
        findViewById<LinearLayout>(R.id.settings_column)?.let { col ->
            Anim.staggerIn((0 until col.childCount).map { col.getChildAt(it) }, Anim.reducedMotion(this))
        }
        // 个性化转场（v1.9.9）：变更皮肤/字体/强调色 recreate 后整页淡入上浮
        window.decorView.alpha = 0f
        window.decorView.translationY = resources.displayMetrics.density * 12
        window.decorView.animate()
            .alpha(1f).translationY(0f)
            .setDuration(260L)
            .setInterpolator(Anim.ENTER)
            .start()
    }

    // ==================== 视图绑定 ====================

    private fun bindViews() {
        rgDup = findViewById(R.id.rg_dup)
        swEdit = findViewById(R.id.sw_edit)
        etRoot = findViewById(R.id.et_root)
        swFlat = findViewById(R.id.sw_flat)
        swAuto = findViewById(R.id.sw_auto)
        rgTheme = findViewById(R.id.rg_theme)
        swSource = findViewById(R.id.sw_source)
        llSourceList = findViewById(R.id.ll_source_list)
        tvSourceEmpty = findViewById(R.id.tv_source_empty)
        swSaf = findViewById(R.id.sw_saf)
        tvSafPath = findViewById(R.id.tv_saf_path)
        llRules = findViewById(R.id.ll_rules)
        tvRulesEmpty = findViewById(R.id.tv_rules_empty)
        findViewById<View>(R.id.btn_back).apply {
            Anim.pressable(this)
            setOnClickListener { finish() }
        }
        findViewById<Button>(R.id.btn_done_settings).apply {
            Anim.pressable(this)
            setOnClickListener { finish() }
        }
    }

    /** 八张折叠卡片绑定 */
    private fun bindCards() {
        bindCard(R.id.header_save, R.id.body_save, R.id.iv_chevron_save)
        bindCard(R.id.header_dup, R.id.body_dup, R.id.iv_chevron_dup)
        bindCard(R.id.header_location, R.id.body_location, R.id.iv_chevron_location)
        bindCard(R.id.header_rules, R.id.body_rules, R.id.iv_chevron_rules)
        bindCard(R.id.header_space, R.id.body_space, R.id.iv_chevron_space)
        bindCard(R.id.header_source, R.id.body_source, R.id.iv_chevron_source)
        bindCard(R.id.header_appearance, R.id.body_appearance, R.id.iv_chevron_appearance)
        bindCard(R.id.header_other, R.id.body_other, R.id.iv_chevron_other)
    }

    private fun bindCard(headerId: Int, bodyId: Int, chevronId: Int) {
        val header = findViewById<LinearLayout>(headerId)
        val body = findViewById<LinearLayout>(bodyId)
        val chevron = findViewById<ImageView>(chevronId)
        Anim.pressable(header)
        header.setOnClickListener { toggleCard(body, chevron) }
    }

    // ==================== 状态载入 / 保存 ====================

    private fun loadState() {
        rgDup.check(
            if (AppSettings.dupMode(this) == AppSettings.DUP_SKIP) R.id.rb_skip
            else R.id.rb_smart
        )
        swEdit.isChecked = AppSettings.editBeforeSave(this)
        etRoot.setText(AppSettings.rawRootName(this))
        swFlat.isChecked = AppSettings.flat(this)
        swAuto.isChecked = AppSettings.autoExit(this)
        swSource.isChecked = AppSettings.sourceMemoryEnabled(this)
        rgTheme.check(
            when (AppSettings.themeMode(this)) {
                AppSettings.THEME_LIGHT -> R.id.rb_theme_light
                AppSettings.THEME_DARK -> R.id.rb_theme_dark
                else -> R.id.rb_theme_system
            }
        )
    }

    private fun bindActions() {
        rgDup.setOnCheckedChangeListener { _, id ->
            AppSettings.setDupMode(
                this,
                if (id == R.id.rb_skip) AppSettings.DUP_SKIP else AppSettings.DUP_SMART
            )
        }
        swEdit.setOnCheckedChangeListener { _, c -> AppSettings.setEditBeforeSave(this, c) }

        etRoot.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                // 存原文；读取时由 AppSettings.rootName() 清洗并回退默认值
                AppSettings.setRawRootName(this@SettingsActivity, s?.toString())
            }

            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}
        })

        swFlat.setOnCheckedChangeListener { _, c -> AppSettings.setFlat(this, c) }
        swAuto.setOnCheckedChangeListener { _, c -> AppSettings.setAutoExit(this, c) }
        swSource.setOnCheckedChangeListener { _, c ->
            AppSettings.setSourceMemoryEnabled(this, c)
            rebuildSourceRows()
        }

        rgTheme.setOnCheckedChangeListener { _, id ->
            val mode = when (id) {
                R.id.rb_theme_light -> AppSettings.THEME_LIGHT
                R.id.rb_theme_dark -> AppSettings.THEME_DARK
                else -> AppSettings.THEME_SYSTEM
            }
            if (mode != AppSettings.themeMode(this)) {
                AppSettings.setThemeMode(this, mode)
                ThemeKit.stampFromSettings = mode
                recreate() // 立即以新主题重建本页
            }
        }

        // ---- SAF 存储引擎（#16） ----
        swSaf.isChecked = AppSettings.useSafEngine(this) && AppSettings.safTree(this) != null
        updateSafPath()
        swSaf.setOnCheckedChangeListener { _, c ->
            if (c && AppSettings.safTree(this) == null) {
                launchSafPicker() // 首次开启：先选目录
            } else {
                AppSettings.setSafEngine(this, c)
                if (c) toast(getString(R.string.set_saf_engine_toast))
            }
        }
        findViewById<TextView>(R.id.btn_saf_pick).setOnClickListener { launchSafPicker() }

        // ---- 分类规则（#8） ----
        findViewById<Button>(R.id.btn_rules_add).setOnClickListener { showAddRuleDialog() }

        // ---- 空间统计（#15） ----
        findViewById<Button>(R.id.btn_space_stats).setOnClickListener { showSpaceStats() }

        // ---- 界面风格（十款皮肤：大卡预览网格，点卡即切） ----
        buildSkinGrid()
        // 字体大小（v1.9.8）：行内选项卡，点一下即切换
        val fontTabs = intArrayOf(R.id.tab_font_0, R.id.tab_font_1, R.id.tab_font_2, R.id.tab_font_3)
        fontTabs.forEachIndexed { i, id ->
            findViewById<View>(id)?.setOnClickListener {
                if (AppSettings.fontScaleIdx(this) != i) {
                    AppSettings.setFontScaleIdx(this, i)
                    toast(getString(R.string.font_changed))
                    recreate()
                }
            }
        }
        refreshFontTabs()
        applySettingsLayout()
        // 底部小字：开发者声明 · 开源软件（v1.11.4）
        val colAbout = findViewById<LinearLayout>(R.id.settings_column)
        colAbout?.addView(
            TextView(this).apply {
                text = getString(R.string.about_link)
                textSize = 11f
                gravity = Gravity.CENTER
                setPadding(0, dp(18), 0, dp(4))
                background = getDrawable(R.drawable.ripple_text)
                Anim.pressable(this)
                setOnClickListener { showAboutDialog() }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        // 细分文件夹开关（v1.11.2）：分类下按年月再分一层
        val swSub = findViewById<android.widget.Switch>(R.id.sw_submonth)
        swSub?.isChecked = AppSettings.subMonth(this)
        swSub?.setOnCheckedChangeListener { _, on ->
            AppSettings.setSubMonth(this, on)
            toast(getString(R.string.submonth_title) + if (on) "：按年月" else "：关闭")
        }
        // 开场动画开关（v1.10.1）
        val swIntro = findViewById<android.widget.Switch>(R.id.sw_intro)
        swIntro?.isChecked = AppSettings.introAnimOn(this)
        swIntro?.setOnCheckedChangeListener { _, on ->
            AppSettings.setIntroAnimOn(this, on)
            toast(getString(R.string.intro_title) + if (on) "：开" else "：关")
        }
    }

    // ==================== 界面风格选择 ====================

    /** 字体选项卡选中态：品牌实底 + 白字，其余卡片形 */
    private fun refreshFontTabs() {
        val tabs = intArrayOf(R.id.tab_font_0, R.id.tab_font_1, R.id.tab_font_2, R.id.tab_font_3)
        val cur = AppSettings.fontScaleIdx(this)
        tabs.forEachIndexed { i, id ->
            findViewById<TextView>(id)?.let { tv ->
                if (i == cur) {
                    tv.background = SkinKit.primaryBtn(this)
                    tv.setTextColor(BrandKit.WHITE)
                } else {
                    tv.background = SkinKit.secondaryBtn(this)
                    tv.setTextColor(getColor(R.color.text_secondary))
                }
            }
        }
    }

    // ==================== 界面风格：大卡预览网格 ====================

    /** 迷你皮肤快照：按该皮肤真实配色绘制的 mockup（顶栏/卡片/强调点/文本线） */
    private inner class SkinPreview(ctx: android.content.Context, idx: Int) :
        android.view.View(ctx) {

        private val c = SkinKit.previewColors(ctx, idx)
        private val card = c[0]; private val accent = c[1]; private val stroke = c[2]
        private val bg = SkinKit.attrColor(ctx, R.attr.skinBg, 0xFFEEF1F5.toInt())
        private val line = SkinKit.attrColor(ctx, R.attr.skinIcon, 0xFF86909C.toInt())

        private val pFill = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG)
        private val pStroke = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = px(1f)
        }

        private fun px(v: Float): Float = v * context.resources.displayMetrics.density

        override fun onDraw(canvas: android.graphics.Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val r = px(7f)
            // 外框：皮肤底色 + 描边
            pFill.color = card
            canvas.drawRoundRect(0f, 0f, w, h, r, r, pFill)
            val half = pStroke.strokeWidth / 2
            pStroke.color = stroke
            canvas.drawRoundRect(half, half, w - half, h - half, r, r, pStroke)
            // 顶栏条（模拟皮肤页头）
            pFill.color = bg
            canvas.drawRoundRect(px(5f), px(5f), w - px(5f), px(14f), px(3f), px(3f), pFill)
            // 两条文本线
            pFill.color = line
            pFill.alpha = 130
            canvas.drawRoundRect(px(5f), px(20f), w * 0.62f, px(23f), px(1.5f), px(1.5f), pFill)
            canvas.drawRoundRect(px(5f), px(28f), w * 0.45f, px(31f), px(1.5f), px(1.5f), pFill)
            pFill.alpha = 255
            // 强调点
            pFill.color = accent
            canvas.drawCircle(w - px(9f), h - px(9f), px(3.5f), pFill)
        }
    }

    /** 两列大卡网格：迷你快照 + 名称 + 介绍，点卡即切换；顶部为当前皮肤配色的应用 Logo 预览 */
    private fun buildSkinGrid() {
        val grid = findViewById<LinearLayout>(R.id.ll_skin_grid) ?: return
        grid.removeAllViews()
        val cur = AppSettings.skinIdx(this)
        // 当前皮肤配色版应用 Logo（v1.10.3）：切风格即变色
        grid.addView(
            SkinLogoView(this).apply {
                val pc = SkinKit.previewColors(this@SettingsActivity, cur)
                setColors(pc[1], pc[0])
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp8(64)
            ).apply { bottomMargin = dp8(10) }
        )
        val rows = (0..4).map { r ->
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (r > 0) topMargin = dp8(8) }
            }
        }
        (0..9).forEach { i ->
            val row = rows[i / 2]
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(dp8(9), dp8(8), dp8(9), dp8(8))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                    .apply { if (i % 2 == 1) leftMargin = dp8(8) }
                // 选中卡：强调色描边；未选：皮肤细边
                background = android.graphics.drawable.GradientDrawable().apply {
                    cornerRadius = dp8(9f).toFloat()
                    setColor(SkinKit.attrColor(this@SettingsActivity, R.attr.skinCard, 0xFFFFFFFF.toInt()))
                    setStroke(
                        dp8(if (i == cur) 1.5f else 1f),
                        if (i == cur) BrandKit.accent(this@SettingsActivity)
                        else SkinKit.attrColor(this@SettingsActivity, R.attr.skinStroke, 0xFFE5E6EB.toInt())
                    )
                }
                Anim.pressable(this)
                setOnClickListener {
                    if (AppSettings.skinIdx(this@SettingsActivity) != i) {
                        AppSettings.setSkinIdx(this@SettingsActivity, i)
                        ThemeKit.stampFromSettings = "skin"
                        // 桌面图标秒切（v1.11）：启用对应皮肤 alias
                        LauncherAlias.apply(this@SettingsActivity, i)
                        toast(getString(R.string.skin_changed, SkinKit.NAMES[i]))
                        recreate()
                    }
                }
            }
            card.addView(
                SkinPreview(this, i).apply {
                    layoutParams = LinearLayout.LayoutParams(dp8(46), dp8(38)).apply {
                        rightMargin = dp8(9)
                    }
                }
            )
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(
                TextView(this).apply {
                    text = SkinKit.NAMES[i]
                    textSize = 13f
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setTextColor(
                        if (i == cur) BrandKit.accent(this@SettingsActivity)
                        else SkinKit.text(this@SettingsActivity)
                    )
                }
            )
            col.addView(
                TextView(this).apply {
                    text = SkinKit.DESCS[i]
                    textSize = 10.5f
                    setTextColor(getColor(R.color.text_secondary))
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    alpha = if (i == cur) 1f else 0.75f
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp8(2) }
            )
            card.addView(col, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(card)
        }
        rows.forEach { grid.addView(it) }
    }

    private fun dp8(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun dp8(v: Float): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()

    // ==================== 设置页布局的皮肤差异（v1.10.11） ====================

    /**
     * 卡片间距/内边距随皮肤三档：
     *  · 紧凑（纸张/终端/墨水屏/复古/工作台）：12dp 间距 · 14dp 内边距
     *  · 宽松（禅意/奶油）：24dp 间距 · 20dp 内边距
     *  · 标准（经典白/胶片/霓虹）：16dp · 16dp
     */
    private fun applySettingsLayout() {
        val idx = AppSettings.skinIdx(this)
        val gap = when (idx) {
            1, 2, 4, 9 -> dp(12)
            5, 8 -> dp(24)
            else -> dp(16)
        }
        val pad = when (idx) {
            1, 2, 4, 9 -> dp(14)
            5, 8 -> dp(20)
            else -> dp(16)
        }
        val col = findViewById<LinearLayout>(R.id.settings_column) ?: return
        var first = true
        for (i in 0 until col.childCount) {
            val c = col.getChildAt(i)
            if (c !is LinearLayout) continue
            val lp = c.layoutParams as? LinearLayout.LayoutParams ?: continue
            if (!first) lp.topMargin = gap
            c.setPadding(pad, c.paddingTop, pad, c.paddingBottom)
            first = false
        }
    }

    // ==================== SAF 目录选择（#16） ====================

    private fun launchSafPicker() {
        try {
            startActivityForResult(
                Intent(Intent.ACTION_OPEN_DOCUMENT_TREE)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    .addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    .addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
                    .addFlags(Intent.FLAG_GRANT_PREFIX_URI_PERMISSION),
                REQ_SAF_TREE
            )
        } catch (_: Exception) {
            toast(getString(R.string.set_saf_pick_fail))
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_SAF_TREE) return
        val uri = data?.data
        if (resultCode != RESULT_OK || uri == null) {
            if (AppSettings.safTree(this) == null) swSaf.isChecked = false
            return
        }
        // 持久化授权（重启后仍可访问）
        try {
            contentResolver.takePersistableUriPermission(
                uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        } catch (_: Exception) {
        }
        AppSettings.setSafTree(this, uri.toString())
        AppSettings.setSafEngine(this, true)
        swSaf.isChecked = true
        updateSafPath()
        toast(getString(R.string.set_saf_engine_toast))
    }

    private fun updateSafPath() {
        val uriStr = AppSettings.safTree(this)
        tvSafPath.text = if (uriStr == null) getString(R.string.set_saf_none)
        else try {
            getString(
                R.string.set_saf_cur,
                SafKit.displayPath(Uri.parse(uriStr), SafKit.rootDocId(Uri.parse(uriStr)))
            )
        } catch (_: Exception) {
            getString(R.string.set_saf_none)
        }
    }

    // ==================== 分类规则（#8） ====================

    private fun rebuildRuleRows() {
        llRules.removeAllViews()
        val rules = AppSettings.customRules(this).toSortedMap()
        tvRulesEmpty.visibility = if (rules.isEmpty()) View.VISIBLE else View.GONE
        rules.forEach { (ext, cat) -> llRules.addView(buildRuleRow(ext, cat)) }
    }

    /** 单条规则：.epub → 文档 × */
    private fun buildRuleRow(ext: String, cat: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, dp(5))
        }
        row.addView(
            TextView(this).apply {
                text = getString(R.string.rules_fmt, ".$ext", cat)
                textSize = 14f
                setTextColor(SkinKit.text(this@SettingsActivity))
            },
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )
        val del = TextView(this).apply {
            text = "×"
            textSize = 18f
            setTextColor(SkinKit.textSub(this@SettingsActivity))
            setPadding(dp(10), dp(2), dp(10), dp(2))
            background = getDrawable(R.drawable.ripple_text)
            setOnClickListener {
                val m = AppSettings.customRules(this@SettingsActivity).toMutableMap()
                m.remove(ext)
                AppSettings.setCustomRules(this@SettingsActivity, m)
                rebuildRuleRows()
                toast(getString(R.string.rules_removed))
            }
        }
        row.addView(del)
        return row
    }

    /** 添加规则：扩展名输入 + 分类单选 */
    private fun showAddRuleDialog() {
        val input = EditText(this).apply {
            hint = getString(R.string.rules_ext_hint)
            background = SkinKit.input(this@SettingsActivity)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            isSingleLine = true
            textSize = 14f
        }
        var pick = CategoryUtils.CAT_DOC

        // 已收录实时提示（v1.11.1）：输入时告诉用户该扩展名是否已内置
        val hint = TextView(this).apply {
            textSize = 11f
            setTextColor(SkinKit.textMuted(this@SettingsActivity))
        }
        fun refreshHint() {
            val ext = input.text.toString().trim()
                .lowercase().removePrefix(".").replace(Regex("[^a-z0-9]"), "")
            hint.text = when {
                ext.isBlank() -> ""
                CategoryUtils.CAT_OF.containsKey(ext) ->
                    getString(R.string.rules_builtin, ext, CategoryUtils.CAT_OF[ext])
                else -> getString(R.string.rules_custom_hint)
            }
        }
        input.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) = refreshHint()
        })

        // 常用扩展名快捷 chips（v1.11.1）：点击即填入
        val chipRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val quick = listOf("heic", "webp", "mkv", "flac", "epub", "7z", "iso")
        quick.forEachIndexed { i, ext ->
            chipRow.addView(
                TextView(this).apply {
                    text = ".$ext"
                    textSize = 12f
                    setTextColor(SkinKit.text(this@SettingsActivity))
                    background = SkinKit.secondaryBtn(this@SettingsActivity)
                    setPadding(dp(10), dp(5), dp(10), dp(5))
                    Anim.pressable(this)
                    setOnClickListener {
                        input.setText(ext)
                        input.setSelection(ext.length)
                        refreshHint()
                    }
                },
                LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { if (i > 0) leftMargin = dp(6) }
            )
        }

        val pickBtn = Button(this).apply {
            text = getString(R.string.rules_pick_cat)
            background = SkinKit.secondaryBtn(this@SettingsActivity)
            minHeight = dp(40)
            stateListAnimator = null
            isAllCaps = false
            setTextColor(SkinKit.textMuted(this@SettingsActivity))
            textSize = 13f
            setOnClickListener {
                val cats = CategoryUtils.ALL_CATS.toList()
                DialogKit.choices(
                    this@SettingsActivity,
                    this@SettingsActivity.getString(R.string.rules_pick_cat),
                    cats, cats.indexOf(pick)
                ) { w -> pick = cats[w] }
            }
        }

        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), dp(4))
        }
        wrap.addView(
            input, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            )
        )
        wrap.addView(
            hint, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        wrap.addView(
            chipRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(10) }
        )
        wrap.addView(
            TextView(this).apply {
                text = getString(R.string.rules_builtin_note)
                textSize = 11f
                setTextColor(SkinKit.textMuted(this@SettingsActivity))
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        )
        wrap.addView(
            pickBtn, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(8) }
        )

        DialogKit.show(
            this, getString(R.string.rules_add), wrap,
            listOf(
                Triple(getString(R.string.btn_close), false, null),
                Triple(getString(R.string.btn_save), true) {
                    val ext = input.text.toString().trim()
                        .lowercase().removePrefix(".").replace(Regex("[^a-z0-9]"), "")
                    if (ext.isBlank()) {
                        toast(getString(R.string.rules_bad_ext))
                        false // 保持弹窗，让用户改完再存
                    } else {
                        val m = AppSettings.customRules(this).toMutableMap()
                        m[ext] = pick
                        AppSettings.setCustomRules(this, m)
                        rebuildRuleRows()
                        toast(getString(R.string.rules_added))
                        true
                    }
                }
            )
        )
        refreshHint()
    }

    // ==================== 空间统计    /** 关于与声明（开发者 / 隐私 / 开源），内置弹窗呈现 */
    private fun showAboutDialog() {
        fun h(t: String) = TextView(this).apply {
            text = t
            textSize = 13f
            setTextColor(BrandKit.accent(this@SettingsActivity))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        fun p(t: String) = TextView(this).apply {
            text = t
            textSize = 12.5f
            setTextColor(SkinKit.text(this@SettingsActivity))
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        fun sub(t: String) = TextView(this).apply {
            text = t
            textSize = 12f
            setTextColor(SkinKit.textSub(this@SettingsActivity))
            setLineSpacing(dp(3).toFloat(), 1f)
        }
        val body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        body.addView(h(getString(R.string.about_version_fmt, "1.0.0", "Spark 火花")))
        body.addView(
            sub(getString(R.string.about_p1)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4); bottomMargin = dp(10) }
        )
        body.addView(h(getString(R.string.about_dev)))
        body.addView(
            sub(getString(R.string.about_dev_name)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4) }
        )
        body.addView(
            TextView(this).apply {
                text = getString(R.string.about_email)
                textSize = 12f
                setTextColor(BrandKit.accent(this@SettingsActivity))
                background = getDrawable(R.drawable.ripple_text)
                setPadding(0, dp(3), 0, dp(3))
                Anim.pressable(this)
                setOnClickListener {
                    runCatching {
                        startActivity(
                            Intent(Intent.ACTION_SENDTO, android.net.Uri.parse(
                                "mailto:YanXi20110914@outlook.com"
                            )).putExtra(Intent.EXTRA_SUBJECT, "文件收纳盒反馈")
                        )
                    }
                }
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(10) }
        )
        body.addView(h(getString(R.string.about_h1)))
        body.addView(
            p(getString(R.string.about_p1)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4); bottomMargin = dp(10) }
        )
        body.addView(h(getString(R.string.about_h2)))
        body.addView(
            sub(getString(R.string.about_p2)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4); bottomMargin = dp(10) }
        )
        body.addView(h(getString(R.string.about_h3)))
        body.addView(
            sub(getString(R.string.about_p3)),
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(4); bottomMargin = dp(10) }
        )
        body.addView(
            TextView(this).apply {
                text = getString(R.string.about_copy)
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(SkinKit.textMuted(this@SettingsActivity))
            },
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = dp(6) }
        )
        DialogKit.message(this, getString(R.string.about_title), body)
    }

    // ==================== 空间统计（#15） ====================

    private fun showSpaceStats() {
        val dlg = DialogKit.busy(this, getString(R.string.space_scanning))
        thread {
            val byCat = HashMap<String, Long>()
            val safOn = AppSettings.useSafEngine(this) && SafKit.tree(this) != null
            if (safOn) {
                val tree = SafKit.tree(this)!!
                scanSafSizes(SafKit.rootDocId(tree), byCat, intArrayOf(0))
            } else {
                val root = File(
                    android.os.Environment.getExternalStorageDirectory(),
                    AppSettings.rootName(this)
                )
                if (root.exists()) {
                    root.walkTopDown().forEach { f ->
                        if (f.isFile) {
                            val cat = CategoryUtils.categorize(
                                f.name, null, null, AppSettings.customRules(this)
                            )
                            byCat[cat] = (byCat[cat] ?: 0L) + f.length()
                        }
                    }
                }
            }
            runOnUiThread {
                DialogKit.dismissSheet(this, dlg)
                showSpaceDialog(byCat, safOn)
            }
        }
    }

    /** SAF 递归累计（带扫描上限防卡死） */
    private fun scanSafSizes(
        dirDocId: String, byCat: HashMap<String, Long>, counter: IntArray
    ) {
        if (counter[0] > 20000) return
        SafKit.children(this, dirDocId).forEach { c ->
            counter[0]++
            if (c.isDir) scanSafSizes(c.docId, byCat, counter)
            else {
                val cat = CategoryUtils.categorize(
                    c.name, null, null, AppSettings.customRules(this)
                )
                byCat[cat] = (byCat[cat] ?: 0L) + c.size
            }
        }
    }

    private fun showSpaceDialog(byCat: Map<String, Long>, safOn: Boolean) {
        val sorted = byCat.entries.sortedByDescending { it.value }
        val total = sorted.sumOf { it.value }
        if (sorted.isEmpty()) {
            DialogKit.confirm(
                this, getString(R.string.space_title),
                getString(R.string.space_empty_state),
                okText = getString(R.string.btn_close), onOk = null
            )
            return
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(10), dp(22), dp(4))
        }
        val accent = BrandKit.accent(this)
        val accentBg = BrandKit.accentBg(this)
        val maxV = sorted.first().value.coerceAtLeast(1L)

        // 分类配色（图片红/视频紫/音频橙/文档蓝/压缩青/应用绿/字体粉/其他灰……循环取色）
        val palette = intArrayOf(
            0xFFEF5860.toInt(), 0xFF7C5CF6.toInt(), 0xFFF59C3E.toInt(), 0xFF3B82F6.toInt(),
            0xFF22C0D6.toInt(), 0xFF34B37A.toInt(), 0xFFE86FA4.toInt(), 0xFF86909C.toInt(),
            0xFFB58A5F.toInt(), 0xFF5F7A96.toInt()
        )

        // 总量行
        wrap.addView(
            TextView(this).apply {
                text = HistoryStore.fmtSize(total)
                textSize = 18f
                setTextColor(SkinKit.text(this@SettingsActivity))
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
        )

        // 容量甜甜圈饼图（v1.10.4）：中心总量，扇区扫入动画
        val pieEntries = sorted.take(10).mapIndexed { i, (cat, bytes) ->
            Triple(palette[i % palette.size], bytes, cat)
        }
        wrap.addView(
            PieView(this, pieEntries, total).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(196)
                ).apply { topMargin = dp(8); bottomMargin = dp(6) }
            }
        )

        sorted.take(10).forEachIndexed { idx, (cat, bytes) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                setPadding(0, dp(5), 0, dp(5))
            }
            // 分类色点（与饼图对应）
            row.addView(
                android.view.View(this).apply {
                    background = android.graphics.drawable.GradientDrawable().apply {
                        shape = android.graphics.drawable.GradientDrawable.OVAL
                        setColor(palette[idx % palette.size])
                    }
                },
                LinearLayout.LayoutParams(dp(9), dp(9)).apply { rightMargin = dp(9) }
            )
            row.addView(
                TextView(this).apply {
                    text = cat
                    textSize = 13f
                    setTextColor(SkinKit.text(this@SettingsActivity))
                },
                LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            )
            row.addView(
                TextView(this).apply {
                    text = HistoryStore.fmtSize(bytes) + "  " +
                            (if (total > 0) bytes * 100 / total else 0) + "%"
                    textSize = 12f
                    setTextColor(SkinKit.textSub(this@SettingsActivity))
                }
            )
            wrap.addView(row)
        }

        // 清理空文件夹（仅根目录引擎；SAF 删除依赖系统实现，不提供）
        val buttons = mutableListOf<Triple<String, Boolean, (() -> Any?)?>>()
        buttons.add(Triple(getString(R.string.btn_close), false, null))
        if (!safOn) {
            buttons.add(Triple(getString(R.string.space_clean), false) {
                DialogKit.confirm(
                    this, getString(R.string.space_clean),
                    getString(R.string.space_clean_confirm),
                    okText = getString(R.string.btn_delete)
                ) {
                    val pd = DialogKit.busy(this, getString(R.string.space_scanning))
                    thread {
                        var n = 0
                        val root = File(
                            android.os.Environment.getExternalStorageDirectory(),
                            AppSettings.rootName(this)
                        )
                        if (root.exists()) {
                            root.walkBottomUp().forEach { d ->
                                if (d.isDirectory && d != root &&
                                    d.listFiles()?.isEmpty() == true && d.delete()
                                ) n++
                            }
                        }
                        runOnUiThread {
                            DialogKit.dismissSheet(this, pd)
                            toast(getString(R.string.space_clean_done, n))
                        }
                    }
                }
                Unit
            })
        }
        DialogKit.show(
            this, getString(R.string.space_title),
            android.widget.ScrollView(this).apply { addView(wrap) },
            buttons
        )
    }

    // ==================== 容量甜甜圈饼图（v1.10.4） ====================

    private inner class PieView(
        ctx: android.content.Context,
        entries: List<Triple<Int, Long, String>>,
        private val total: Long
    ) : android.view.View(ctx) {

        private val items = entries.filter { it.second > 0 }
        private val sum = entries.sumOf { it.second }.coerceAtLeast(1L)
        private var progress = 0f

        private val pArc = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            style = android.graphics.Paint.Style.STROKE
            strokeWidth = ctx.resources.displayMetrics.density * 30
            strokeCap = android.graphics.Paint.Cap.BUTT
        }
        private val pText = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = android.graphics.Paint.Align.CENTER
            isFakeBoldText = true
        }
        private val pSub = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = android.graphics.Paint.Align.CENTER
        }

        init {
            // 扫入动画：扇区从 0° 展开，回弹前摇
            animate().apply { duration = 0 }
            val va = android.animation.ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 620L
                interpolator = android.view.animation.DecelerateInterpolator(1.6f)
                addUpdateListener { progress = it.animatedValue as Float; invalidate() }
            }
            post { va.start() }
        }

        override fun onDraw(canvas: android.graphics.Canvas) {
            val w = width.toFloat(); val h = height.toFloat()
            val cx = w / 2f; val cy = h / 2f
            val ringW = w * 0.14f
            pArc.strokeWidth = ringW
            val radius = (w.coerceAtMost(h) - ringW) / 2f - dp(6)
            val rect = android.graphics.RectF(
                cx - radius, cy - radius, cx + radius, cy + radius
            )
            // 轨道
            pArc.color = (SkinKit.attrColor(
                this@SettingsActivity, R.attr.skinDivider, 0xFFE5E6EB.toInt()
            ) and 0x00FFFFFF) or 0x14000000
            canvas.drawArc(rect, 0f, 360f, false, pArc)
            // 扇区
            var start = -90f
            items.forEach { (color, bytes, _) ->
                val sweep = bytes.toFloat() / sum * 360f * progress
                if (sweep > 0.4f) {
                    pArc.color = color
                    canvas.drawArc(rect, start, sweep - 1.2f, false, pArc)
                }
                start += sweep
            }
            // 中心：总容量
            pText.color = SkinKit.text(this@SettingsActivity)
            pText.textSize = resources.displayMetrics.density * 19
            canvas.drawText(
                HistoryStore.fmtSize((total * progress).toLong().coerceAtLeast(0)),
                cx, cy - pSub.textSize * 0.4f, pText
            )
            pSub.color = SkinKit.textSub(this@SettingsActivity)
            pSub.textSize = resources.displayMetrics.density * 11
            canvas.drawText(getString(R.string.space_total_label), cx, cy + pText.textSize * 0.7f, pSub)
        }
    }

    // ==================== 强调色（主题 UI） ====================

    private fun toast(msg: String) {
        android.widget.Toast.makeText(this, msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    // ==================== 来源记忆列表 ====================

    private fun rebuildSourceRows() {
        llSourceList.removeAllViews()
        val pkgs = AppSettings.silentSources(this).sorted()
        tvSourceEmpty.visibility =
            if (pkgs.isEmpty() || !AppSettings.sourceMemoryEnabled(this)) View.VISIBLE
            else View.GONE

        pkgs.forEach { pkg -> llSourceList.addView(buildSourceRow(pkg)) }
    }

    /** 单个来源行：应用名 + 开关 + 移除 */
    private fun buildSourceRow(pkg: String): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(4))
        }

        val label = TextView(this).apply {
            text = appLabel(pkg)
            textSize = 14f
            setTextColor(SkinKit.text(this@SettingsActivity))
            isSingleLine = true
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        row.addView(
            label, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        )

        val sw = Switch(this).apply {
            isChecked = true
            thumbTintList = getColorStateList(R.color.switch_thumb)
            trackTintList = getColorStateList(R.color.switch_track)
            setOnCheckedChangeListener { _, c ->
                if (!c) {
                    AppSettings.removeSilentSource(this@SettingsActivity, pkg)
                    rebuildSourceRows()
                }
            }
        }
        row.addView(sw)

        val del = TextView(this).apply {
            text = "×"
            textSize = 18f
            setTextColor(SkinKit.textSub(this@SettingsActivity))
            setPadding(dp(10), dp(4), dp(2), dp(4))
            Anim.pressable(this)
            setOnClickListener {
                AppSettings.removeSilentSource(this@SettingsActivity, pkg)
                rebuildSourceRows()
            }
        }
        row.addView(del)
        return row
    }

    private fun appLabel(pkg: String): String = try {
        packageManager.getApplicationLabel(
            packageManager.getApplicationInfo(pkg, 0)
        ).toString()
    } catch (_: Exception) {
        pkg
    }

    // ==================== 折叠动画 ====================

    /** 展开/收起卡片主体（高度 + 透明度 + 箭头旋转，非线性曲线） */
    private fun toggleCard(body: LinearLayout, chevron: ImageView) {
        if (body.visibility == View.VISIBLE) {
            collapse(body, chevron)
        } else {
            expand(body, chevron)
        }
    }

    private fun collapse(body: LinearLayout, chevron: ImageView) {
        val h = body.height
        if (h <= 0) {
            body.visibility = View.GONE
            return
        }
        val a = ValueAnimator.ofInt(h, 0)
        a.addUpdateListener { anim ->
            body.layoutParams.height = anim.animatedValue as Int
            body.requestLayout()
        }
        a.duration = Anim.DUR_COMPONENT
        a.interpolator = Anim.EXIT
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                body.visibility = View.GONE
                body.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                body.alpha = 1f
                body.requestLayout()
            }
        })
        body.animate().alpha(0f)
            .setDuration(200L).setInterpolator(Anim.EXIT).start()
        chevron.animate().rotation(0f)
            .setDuration(Anim.DUR_COMPONENT).setInterpolator(Anim.EXIT).start()
        a.start()
    }

    private fun expand(body: LinearLayout, chevron: ImageView) {
        body.visibility = View.VISIBLE
        body.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val h = body.measuredHeight
        val a = ValueAnimator.ofInt(0, h)
        a.addUpdateListener { anim ->
            body.layoutParams.height = anim.animatedValue as Int
            body.requestLayout()
        }
        a.duration = Anim.DUR_COMPONENT
        a.interpolator = Anim.ENTER
        a.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                body.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT
                body.requestLayout()
            }
        })
        body.alpha = 0f
        body.animate().alpha(1f)
            .setDuration(250L).setInterpolator(Anim.ENTER).start()
        chevron.animate().rotation(180f)
            .setDuration(Anim.DUR_COMPONENT).setInterpolator(Anim.ENTER).start()
        a.start()
    }

    // ==================== 工具 ====================

    private fun dp(v: Int): Int =
        (v * resources.displayMetrics.density + 0.5f).toInt()
}
